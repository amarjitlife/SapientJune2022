
package learnJava;

class Entry<K, V> {
	private K key;
	private V value;

	public Entry( K key, V value ) {
		this.key 	= key;
		this.value 	= value;
	}

	public K getKey() 	{ return key; 	}
	public V getValue() { return value; }

	public void setValue( K key, V value ) {
		 if ( this.key == key ) 
		 	this.value = value 
	}
}

//		Type Information Will Be Substituded In Type Parameters K and V At Compile Time
//		For Following Usages Are Compile Time 
//			Entry<Integer, String> entry = new Entry<Integer, String>( 10, "Good Morning!");
//		Compilerr Does All The Type Checks With Function Usages etc...

// Intermediate Level Generated Code At Compile Time For Usage Entry<Integer, String>
class Entry<Integer, String> {
	private Integer key;
	private String value;

	public Entry( Integer key, String value ) {
		this.key 	= key;
		this.value 	= value;
	}

	public Integer getKey() 	{ return key; 	}
	public String getValue() 	{ return value; }
}

//		Type Information Will Be Substituded In Type Parameters K and V At Compile Time
//		For Following Usages Are Compile Time 
//			Entry<String, Double> entryAgain = new Entry<String, Double>( "piValue", 3.1415 );

// // Intermediate Level Generated Code At Compile Time For Usage Entry<String, Double>
class Entry<String, Double> {
	private String key;
	private Double value;

	public Entry( String key, Double value ) {
		this.key 	= key;
		this.value 	= value;
	}

	public String getKey() 		{ return key; 	}
	public Double getValue() 	{ return value; }
}

//	Compiler Does All The Type Checks And Type Analysis With Above Generated Code
//  After Type Checks And Type Analysis Phase
//		Compiler Will Generate Following EXECUTABLE CODE 

// Java Compiler Will Generate Following Code For Above Entry<K,V> Generic Class
//		Type Information For Following Both Usages Are Compile Time Pheonmena
//			Entry<Integer, String> entry = new Entry<Integer, String>( 10, "Good Morning!");
//			Entry<String, Double> entryAgain = new Entry<String, Double>( "piValue", 3.1415 );
//		Type Information Is Erased/Lost After Compilation
//

class Entry {
	private Object key;
	private Object value;

	public Entry( Object key, Object value ) {
		this.key 	= key;
		this.value 	= value;
	}

	public Object getKey() 		{ return key; 	}
	public Object getValue() 	{ return value; }
}

class WordList extends ArrayList<String> {
	public boolean add(String e) {
		return isBadWord( e ) ? false : suepr.add( e );
	}

	// More Code Here...
}

// Following Code Generated For Above Code
class WordList {
	// Object ArrayList[]

	public boolean addObject(Object e) {
		return isBadWord( e ) ? false : suepr.add( e );
	}

	// Generated Bridge Methods To Create Type Safe Code
	public boolean add(Object e) { // Wrapper Method
		return addObject( (String) e ); 
	}

	// More Code Here...
}


class Lists {
	public static boolean hasNulls( List<?> elements ) {
		for ( Object e : elements ) {
			if ( e == null ) return true;
		}
		return false;
	}

	public static void swap( List<?> elements, int i, int j) {
		swapHelper( elements, i, j );
	}

	private static <?> void swapHelper( List<T> elements, int i, int j) {
		T temp = elements.get( i );
		elements.set( i, elements.get(j) )
		elements.set( j, temp )
	}
}


class JavaGenerics {

	public static void playWithGenericEntry() {
		Entry<Integer, String> entry = new Entry<Integer, String>( 10, "Good Morning!");

		// Compiler Generated Type Safe Exctuable Code
		//		Explicit Type Casting Inserted By The Compiler
		Integer key 	= (Integer ) entry.getKey()
		String value 	= (String  ) entry.getValue() 

		System.out.println( "Key 	: " + key  );
		System.out.println( "Value 	: " + value );

		Entry<String, Double> entryAgain = new Entry<String, Double>( "piValue", 3.1415 );

		// Compiler Generated Type Safe Executable Code
		//		Explicit Type Casting Inserted By The Compiler
		Integer keyAgain 	= ( String ) entryAgain.getKey()
		String valueAgain 	= ( Double ) entryAgain.getValue() 

		System.out.println( "Key 	: " + keyAgain  );
		System.out.println( "Value 	: " + valueAgain ;
	}

	public static void main(String[] args) {
		System.out.println("\nFunction : playWithGenericEntry");
		playWithGenericEntry();
	}
}

/*
javac JavaReflections.java -d ClassFiles/
java -cp ClassFiles/ learnJava.JavaReflections

*/
