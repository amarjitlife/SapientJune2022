/*
kotlinc KotlinFundamentals.kt -include-runtime -d fundamentals.jar
java -jar fundamentals.jar 
*/

// Kotlin Language Nature and Design Decisions!!!

package learnKotlin

import java.util.TreeMap

fun helloWorld() {
	println("Hello World!")
}

fun max( a: Int, b: Int ) : Int {
	return if ( a > b )  a  else  b 

	// return if ( a > b ) {
	// 	a
	// 	a +
	// }  else {
	// 	b 
	// } 
}

// Expression
//		Is A Statement With Return Value

// In Kotlin
//		if-else Construct Is An Expression

// In Java/C/C++
//		if-else Construct Is A Statement

// Can You Write Following Line Code In Java/C/C++ In Same Way???
//		Using if-else Construct
// return if ( a > b )  a  else  b 


fun playWithMax() {
	val x = 10
	val y = 30
	val result = max(x, y)

	println("Max : $result")
	println( max( 100, -900 ))

}

// Design Principles
//		Conciseness
//		Expressiveness

// Kotlin Compiler Will Generate Following Code
//		1. Memberwise Initialiser - Constructor
//				With Two Arguments
//		2. Two Gettter For Two Properties
//		3. Will Geneate Setter For isMarried Property
//				Because val Property Is Immutable Hence name Is Immutable

// class Person( val name: String, var isMarried: Boolean )

// Kotlin Compiler Will Generate Following Code
	// class Person {
	// 	String name;
	// 	Boolean isMarried;

	// 	Person(String name, Boolean isMarried) {
	// 		this.name = name;
	// 		this.isMarried = isMarried;
	// 	}

	// 	public String getName() {
	// 		return name;
	// 	}

	// 	public Boolean getIsMarried() {
	// 		return isMarried;
	// 	}

	// 	public setIsMarried(Boolean isMarried) {
	// 		this.isMarried = isMarried;
	// 	}
	// }

//____________________________________________________________
// Experiment Following Code, Moment Done, Raise Your Hands!!!

class Person( val name: String, var isMarried: Boolean )

fun playWithPerson() {
	var person0 = Person( "Alice", false )
	println( person0.name ) 		// 	person0.getName() 
	println( person0.isMarried )	// 	person0.getIsMarried() 

	var person1 = Person( "Chandan", false )
	println( person1.name )			// 	person1.getName() 
	println( person1.isMarried ) 	// 	person1.getIsMarried() 

	person1.isMarried = true  		// 	person0.setIsMarried( true ) 
	println( person1.isMarried )    // 	person1.getIsMarried() 	
}

//_______________________________________________________________
// Experiment Following Code, MOMENT DONE >>> RAISE YOUR HANDS!!!

// Design Principle
//		Design Towards Immutability Rather Than Mutability

// Kotlin Compiler Will Generate Following Code
//		1. Memberwise Initialiser - Constructor
//				With Two Arguments width And height
//		2. Two Gettter For Two Properties viz. width And height

class Rectangle( val height: Int, val width: Int ) {
	val isSquare : Boolean  // Compiler Will Not Generate Getter For isSquare Property
		get() { 			// Property With Custom Getter
			return height == width 
		}
}

fun playWithRectangle() {
	val rectangle = Rectangle( 10, 20 )
	println( rectangle.width )
	println( rectangle.height )
	println( rectangle.isSquare )

	val rectangleAgain = Rectangle( 40, 40 )
	println( rectangleAgain.width )
	println( rectangleAgain.height )
	println( rectangleAgain.isSquare )
}

//_______________________________________________________________

// Design Principles
//		1. Conciseness
//		2. Expressiveness
///		3. Type Safe Language
//		3. Type Strict Language


//  error: 'when' expression must be exhaustive, 
//		add necessary 'YELLOW' branch 
//		or 
//		'else' branch instead

// Creating Color Type
//		Range = { RED, GREEN, BLUE, YELLOW }

// Types Are Theorems
enum class Color {
	RED, GREEN, BLUE, YELLOW, ORANGE, UNKONWN
}

fun playWithColorEnums() {
	println(Color.RED)
	println(Color.GREEN)
	println(Color.BLUE)
}

// Programs Are Proof
// error: type mismatch: inferred type is String but Unit was expected
fun getStringForColor( color : Color ) : String {
	// when Is A Type Safe Expression
	//		It Has Inferred Type 
	// Respecting Type Definition Like A God!
	// 		Write Type Safe Code i.e. Driven By Type Definition
	return when( color ) { 
	// when( color ) {
		Color.RED 		-> "Red Color!"
		Color.GREEN 	-> "Green Color!"
		Color.BLUE 		-> "Blue Color!"		
		// DESIGN CHOICE 1
		Color.YELLOW 	-> "Yellow Color!"
		Color.ORANGE 	-> "Orange Color!"
		Color.UNKONWN 	-> "Unknown Color!"
		// DESIGN CHOICE 2 : BLACK HOLES IN TYPE SYSTEM
		// else  		-> "Unknown Color!"
 		// warning: 'when' is exhaustive so 'else' is redundant here
	}
}

fun playWithColorStrings() {
	println( getStringForColor( Color.RED ) )
	println( getStringForColor( Color.GREEN ) )
	println( getStringForColor( Color.BLUE) ) 
}

// Programs Are Proof
// Code In Some Other Module/File
fun getStringForColorAgain( color : Color ) : String {
	return when( color ) {
		Color.RED 		-> "Red Color!"
		Color.GREEN 	-> "Green Color!"
		Color.BLUE 		-> "Blue Color!"
		// DESIGN CHOICE 1
		Color.YELLOW 	-> "Yellow Color!"
		Color.ORANGE 	-> "Orange Color!"
		Color.UNKONWN 	-> "Unknown Color!"

		// DESIGN CHOICE 2 : BLACK HOLES IN TYPE SYSTEM
		// else  		-> "Unknown Color!"
 		// warning: 'when' is exhaustive so 'else' is redundant here
	}
}

fun getStringForColorOnceAgain( color : Color ) = when( color ) {
	Color.RED 		-> "Red Color!"
	Color.GREEN 	-> "Green Color!"
	Color.BLUE 		-> "Blue Color!"
	Color.YELLOW 	-> "Yellow Color!"
	Color.ORANGE 	-> "Orange Color!"
	Color.UNKONWN 	-> "Unknown Color!"
}

fun playWithColorStringsAgain() {
	println( getStringForColorAgain( Color.RED ) )
	println( getStringForColorAgain( Color.GREEN ) )
	println( getStringForColorAgain( Color.BLUE) ) 

	println( getStringForColorOnceAgain( Color.RED ) )
	println( getStringForColorOnceAgain( Color.GREEN ) )
	println( getStringForColorOnceAgain( Color.BLUE) ) 
}

//_______________________________________________________________
// Experiment Following Code, MOMENT DONE >>> RAISE YOUR HANDS!!!

// Creating Colour Type
//		Range 		= { RED, GREEN, BLUE, YELLOW }
//		Operations = { rgb() }

// Design Principle
//		Design Towards Immutability Rather Than Mutability

enum class Colour(val r: Int, val g: Int, val b: Int) {
	RED(255, 0, 0), GREEN(0, 255, 0), BLUE(0, 0, 255), 
	YELLOW(200, 200, 0), ORANGE(150, 150, 10) ;

	fun rgb() = ( r * 255 + g ) * 255 + b
}

fun getColourWarmth( color : Colour ) = when( color ) {
	Colour.RED, Colour.ORANGE 		-> "Warm Colors!"
	Colour.BLUE, Colour.YELLOW 		-> "Neutral Color!"
	Colour.GREEN 					-> "Cold Color!"
}

fun playWithColoursEnums() {
	println(Colour.RED)
	println(Colour.RED.r)
	println(Colour.RED.g)
	println(Colour.RED.b)
	println(Colour.RED.rgb())

	println(Colour.GREEN)
	println(Colour.GREEN.r)
	println(Colour.GREEN.g)
	println(Colour.GREEN.b)

	println(Colour.BLUE.rgb())
	println(Colour.YELLOW.rgb())

	println( getColourWarmth( Colour.RED ) )
	println( getColourWarmth( Colour.GREEN) )
	println( getColourWarmth( Colour.ORANGE) )
	println( getColourWarmth( Colour.BLUE) )
}


//_______________________________________________________________

// Exceptions Are Not That Exceptional 
//		Such That It Should Break Your Design

// enum class Color {
// 		RED, GREEN, BLUE, YELLOW, ORANGE, UNKONWN
// }


fun mixColorsDesign0( c1 : Color, c2 : Color ) : Color {
	return when ( setOf( c1, c2) ) {
		setOf( Color.RED, Color.GREEN  ) 	-> Color.YELLOW
		setOf( Color.RED, Color.YELLOW )	-> Color.ORANGE
		else 								-> throw Exception(" Dirty Color!.. ")
	}
}

fun mixColorsDesign1( c1 : Color, c2 : Color ) : String {
	return when ( setOf( c1, c2) ) {
		setOf( Color.RED, Color.GREEN  ) 	-> "YELLOW" // String(Color.YELLOW)
		setOf( Color.RED, Color.YELLOW )	-> "ORANGE" // String(Color.ORANGE)	
		// else 								-> throw Exception(" Dirty Color!.. ")
		else 								-> "Dirty Color!.. "
	}
}

// BEST DESIGN
// Cloure Law Is Followed
// Folowing Code Is Type Safe Code
fun mixColorsDesign2( c1 : Color, c2 : Color ) : Color {
	return when ( setOf( c1, c2) ) {
		setOf( Color.RED, Color.GREEN  ) 	-> Color.YELLOW
		setOf( Color.RED, Color.YELLOW )	-> Color.ORANGE
		// else 								-> throw Exception(" Dirty Color!.. ")
		else 								-> Color.UNKONWN
	}
}

// Design Principle
//		Avoid Any Or Object Types In Design
//		Use It In Rarest Rare Scenarios 
//		It Violates Type Strickness

// mixColorDesign3 And mixColorAgain Both Are Same
//		mixColorDesign3 Explicitly Annotating Return Type Any
fun mixColorsDesign3( c1 : Color, c2 : Color ) : Any {
	return when ( setOf( c1, c2) ) {
		setOf( Color.RED, Color.GREEN  ) 	-> Color.YELLOW
		setOf( Color.RED, Color.YELLOW )	-> Color.ORANGE
		else 								-> "Dirty Color!.."
	}
}

// Why Following Code Works???
//		It Doesn't Complain About Return Type???
//		Inferred Type From RHS WIll Be Any
//		Inferred Type Any Will Be Binded With LHS ( Lvalue )
fun mixColorsAgain( c1 : Color, c2 : Color ) = when ( setOf( c1, c2) ) {
	setOf( Color.RED, Color.GREEN  ) 	-> Color.YELLOW
	setOf( Color.RED, Color.YELLOW )	-> Color.ORANGE	
	// else 								-> throw Exception(" Dirty Color!.. ")
	else 								-> "Dirty Color!.."
}

fun  playWithColorMixing() {
	println( mixColorsDesign0( Color.RED, Color.GREEN ) )
	println( mixColorsDesign0( Color.RED, Color.YELLOW ) )
	// println( mixColorsDesign0( Color.GREEN, Color.BLUE ) )

	println( mixColorsDesign1( Color.RED, Color.GREEN ) )
	println( mixColorsDesign1( Color.RED, Color.YELLOW ) )
	println( mixColorsDesign1( Color.GREEN, Color.BLUE ) )

	println( mixColorsDesign2( Color.RED, Color.GREEN ) )
	println( mixColorsDesign2( Color.RED, Color.YELLOW ) )
	println( mixColorsDesign2( Color.GREEN, Color.BLUE ) )

	println( mixColorsAgain( Color.RED, Color.GREEN ) )
	println( mixColorsAgain( Color.RED, Color.YELLOW ) )
	println( mixColorsAgain( Color.GREEN, Color.BLUE ) )
}

//_______________________________________________________________


fun playWithTypeInferrencingAndBinding() {

	// error: this variable must either have a type annotation or be initialized
	// var somethingUseless

	// In Kotlin
		// Type Inferencing And Binding
		// Will Happen In Compile Time
		// 1. Type Inferencing From RHS Value
		// 2. Inferred Type Binded With LHS

	// In Python/JavaScript
		// Type Inferencing And Binding
		// 		Will Happen In Runtime
		// 1. Type Inferencing From RHS Value
		// 2. Inferred Type Binded With LHS

	var something = 90

	// error: type mismatch: inferred type is String but Int was expected
	// something = "Good Morning!"
	val somethingAgain: Int = 90

	println( something )
	println( somethingAgain )

	val something1 = "Good Morning!"
	val somethingAgain1: String = "Good Morning"

	println( something1 )
	println( somethingAgain1 )

	val something2 = true
	val somethingAgain2: Boolean = true

	println( something2 )
	println( somethingAgain2 )

	// error: the floating-point literal does not conform to the expected type Float
	// val something3: Float = 99.9890

	val something3: Float = 99.9890F
	println( something3 )

	val something4  = 99.9890
	val somethingAgain4: Double = 99.9890

	println( something4 )
	println( somethingAgain4 )
}


//_______________________________________________________________


fun fizzBuzz( value: Int ) = when {
	value % 15 == 0 	-> "FizzBuzz  "
	value %  5 == 0 	-> "Fizz  "
	value %  3 == 0 	-> "Buzz  "
	else 				-> "$value"
}


// Mathematics Close Interval [1, 100]
// 	In Kotlin 1..100

fun playWithFizzBuzz() {
	for( index in 1..100 ) {
		print( fizzBuzz( index ) )
	}

	for( index in 100 downTo 1 step 2 ) {
		print( fizzBuzz( index ) )
	}
}

//_______________________________________________________________
// Experiment Following Code, MOMENT DONE >>> RAISE YOUR HANDS!!!
// import java.util.TreeMap
fun playWithIteratingOverMap() {
	// error: unresolved reference: TreeMap
	// Calling Java Code Inside Kotlin Code
	val binaryReps = TreeMap<Char, String>()

	// For Loop Will Be Generating Values Based On Close Interval Type
	// Close Interval ['A', 'F']
	for( character in 'A'..'F' ) {
		var binary = Integer.toBinaryString( character.code )
		binaryReps[ character ] = binary
	}

	// For Loop Will Be Generating Values Based On Close Interval Type
	//		Items Picked From Map Are Tuples
	//		Tuple Is Getting Unpacked To ( letter, binary )
	for( (letter, binary) in binaryReps ) {
		println("$letter Binary Representation : $binary")
	}
}

//_______________________________________________________________
// Experiment Following Code, MOMENT DONE >>> RAISE YOUR HANDS!!!

fun isLetter( character : Char ) 	= character in 'a'..'z' || character in 'A'..'Z'
fun isNotDigit( character : Char )	= character !in '0'..'9'
fun isDigit( character : Char )		= character in '0'..'9'

fun playWithInChecks() {
	println( isLetter('A') )
	println( isLetter('a') )
	println( isLetter('#') )

	println( isDigit( 'A' ))
	println( isDigit( '9' ))
	println( isNotDigit( 'A' ))
	println( isNotDigit( '9' ))
}

fun recogniseCharacter( character : Char ) = when( character ) { // Pattern Matching...
	in 'a'..'z', in 'A'..'Z' -> "It's Alphabet"
	in '0'..'9'				 -> "It's Digit"
	else 					 ->  "Unknown Character"
}

fun playWithRecogniseCharacter() {
	println( recogniseCharacter('A') )
	println( recogniseCharacter('a') )
	println( recogniseCharacter('#') )

	println( recogniseCharacter( 'A' ))
	println( recogniseCharacter( '9' ))
	println( recogniseCharacter( 'A' ))
	println( recogniseCharacter( '9' ))	
}

//_______________________________________________________________
//_______________________________________________________________
//_______________________________________________________________
//_______________________________________________________________
//_______________________________________________________________
// Experiment Following Code, MOMENT DONE >>> RAISE YOUR HANDS!!!

fun main() {
	println("\nFunction : helloWorld")
	helloWorld()

	println("\nFunction : playWithMax")
	playWithMax()

	println("\nFunction : playWithPerson")
	playWithPerson()

	println("\nFunction : playWithRectangle")
	playWithRectangle()

	println("\nFunction : playWithColorEnums")
	playWithColorEnums()

	println("\nFunction : playWithColorStrings")
	playWithColorStrings()

	println("\nFunction : playWithColorStringsAgain")
	playWithColorStringsAgain()

	println("\nFunction : playWithColoursEnums")
	playWithColoursEnums()

	println("\nFunction : playWithColorMixing")
	playWithColorMixing()

	println("\nFunction : playWithTypeInferrencingAndBinding")
	playWithTypeInferrencingAndBinding()

	println("\nFunction : playWithFizzBuzz")
	playWithFizzBuzz()

	println("\nFunction : playWithIteratingOverMap")
	playWithIteratingOverMap()

	println("\nFunction : playWithInChecks")
	playWithInChecks()

	println("\nFunction : playWithRecogniseCharacter")
	playWithRecogniseCharacter()

	// println("\nFunction : ")	
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")	
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")	
}
