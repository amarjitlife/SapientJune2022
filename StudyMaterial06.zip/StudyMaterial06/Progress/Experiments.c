#include <stdio.h>
#include <stdlib.h>
#include <limits.h>

//_______________________________________________________________

typedef struct human_type {
	int id;
	char name[100];
	void (*dance)();
} Human;

void doBhangara() {
	printf("Doing Bhagra!!!");	
}

void doBharatnatayam() {
	printf("Doing Bharatnatayam!!!");	
}

int playWithHuman() {
	// What Is The Difference Between Variables And Objects

	// h Is A Object Of Human Type????
	//		   Constructor 
	Human h = { 100, "Alice ", doBhangara };

	printf("Human ID: %d\n", h.id );
	printf("Human Name: %s\n", h.name );
	h.dance();
}

//_______________________________________________________________


int playWithIfElseConstruct() {
	int a = 10;
	int b = 20;
	int x = 0;

	// if-else Is A Statement
	// Code 1
	// x = if ( a == 10 ) {
	if ( a == 10 ) {
		a;
	} else {
		b;
	}

	// Ternary Operator
	// ( ) ? : ;
	// Code 2
	// Expression
	x = ( a == 10 ) ? a : b ;
}

//_______________________________________________________________

// BAD CODE - BAD DESIGN
int sumOld(int x, int y) {
	return x + y;
}

// BAD CODE
// int factorial( int n ) {
// 	int result = 1;

// 	if ( n < 0 ) {
// 		printf("\nFactorial Doesn't Exists For Negative Integers!");
// 		return;
// 	}
	
// 	if ( n == 0 or n == 1 ) return 1;
// 	else n * factorial( n - 1 );
// }

//_______________________________________________________________
// Experiment Following Code, MOMENT DONE >>> RAISE YOUR HANDS!!!

// VALID ARITHEMATIC SUM
// #include <limits.h>

// Platform Indepent Code
// Type Safe Code  
signed int summation( signed int a, signed int b ) {
	signed int result = 0;
	
	// Respecting Type Definition
	if (((b > 0) && (a > (INT_MAX - b))) ||
	  	((b < 0) && (a < (INT_MIN - b)))) {
	
		/* Handle error */
  		printf("\nCan't Calcualate Arithmatic Sum Of Given Values");
  		exit( 1 );
  	} else {  // Result Is Closed In int Type Range
		result = a + b;
  	}

	return result;
  	/* ... */
}


//_______________________________________________________________
// Experiment Following Code, MOMENT DONE >>> RAISE YOUR HANDS!!!

int playWithSum() {
	int result;

	result = sumOld(100, 200);
	printf("\nResult : %d", result );

	result = sumOld( 30000, 30000 );
	printf("\nResult : %d", result );

	result = sumOld( 2147483647, 2 );
	printf("\nResult : %d", result );

	result = sumOld( -2147483647, -2 );
	printf("\nResult : %d", result );

	result = sumOld(  2147000000, 2147000000 );
	printf("\nResult : %d", result );

	result = summation( 2147483647, 2147483647);
	printf("\nResult : %d", result );

	// Result : 300
	// Result : 60000
	// Result : -2147483647
	// Result : 2147483647
}

//_______________________________________________________________
// Experiment Following Code, MOMENT DONE >>> RAISE YOUR HANDS!!!

void playWithScopes() {
	int i = 10;
	printf("\n %d", i);

	{
		int i = 22;
		printf("\n %d", i);
		i = 222;
		printf("\n %d", i);
	}
}

//_______________________________________________________________
// Experiment Following Code, MOMENT DONE >>> RAISE YOUR HANDS!!!

// Function Type
// (int, int) -> int 
int sum( int x, int y ) 	 { return x + y; }
int sub( int x, int y ) 	 { return x - y; }
int mul( int x, int y ) 	 { return x * y; }
int division( int x, int y ) { return x / y; }

// Function Type
// (int, int, int) -> int 
int sum3( int x, int y, int z ) { return x + y + z ; }

// What Is Function Type Of calculator Function ????

// Type Of Type Relationship
// (int, int, (int, int) -> int ) -> int 

// Polymorphism
// calculator Is Polymorphic
int calculator(int x, int y, int (*operation)(int, int) ) {
	return operation( x, y );
}

void playWithCalculator() {
	int xx = 40, yy = 10;
	int result = 0;

	result = calculator( xx, yy, sum );
	printf("\nResult : %d", result );

	result = calculator( xx, yy, sub );
	printf("\nResult : %d", result );

	result = calculator( xx, yy, mul );
	printf("\nResult : %d", result );

	result = calculator( xx, yy, division );
	printf("\nResult : %d", result );
}

//_______________________________________________________________


int addition(int x, int y) {
	int total = 0;
	total = x + y;
	return total;
}

void playWithReferences() {
	// Name Of Array Is Pointer To Starting Location Of Contigious Memory Location
	// 5 * sizeof( int )
	// Refererences Are In Stack

	int numbers[] = { 10, 20, 30, 40, 50 }; 
	int number = 0;

	// 
	int *pointerToArray = numbers;

	// Pointer/Reference To A Function Of Type (int, int) -> int
	int ( *pointerToFunction )(int, int);
	int result = 0;

	printf("\n\nlay With Arrays...");
	//Play With Arrays And Pointers;
	for( int index = 0 ; index < 5 ; index++ ) {
		number = numbers[ index ];
		printf("\n\t Number At Index %d = %d", index,  number );
	}

	// pointerToArray + sizeof(int) 
	printf("\n\nPlay With Arrays And Pointers...");
	for( int index = 0 ; index < 5 ; index++ ) {
		number = *( pointerToArray + index ); // // pointerToArray + sizeof(int) 
		printf("\n\t Number At Index %d = %d", index,  number );
	}

	
	printf("\n\nPlay With Function Pointers...");
	pointerToFunction = addition ;

	result = pointerToFunction(900, 90);
	printf("\nResult : %d\n", result );
}

//_______________________________________________________________
//_______________________________________________________________
//_______________________________________________________________
//_______________________________________________________________
// Experiment Following Code, MOMENT DONE >>> RAISE YOUR HANDS!!!

int main() {
	// printf("\nFunction : ");
	printf("\nFunction : playWithScopes");
	playWithScopes();

	printf("\nFunction : playWithCalculator");
	playWithCalculator();

	printf("\n\nFunction : playWithReferences");
	playWithReferences();

	// printf("\nFunction : ");
	// printf("\nFunction : ");
}
