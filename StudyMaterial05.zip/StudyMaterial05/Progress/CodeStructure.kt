
fun f11 () {
	
}

fun f12 () {
	
}

fun f21 () {
	
}

fun f22 () {
	
}

fun f23 () {
	
}

fun f1 () {
	f11()
	f12()
}

fun f2 () {
	f21()
	f22()
	f23()
}

fun main() {
	f1()
	f2()
}

//______________________________________________________________


fun main() {
	// f1()

	fun f1 () {
		// f11()
		fun f11 () {
			
		}

		// f12()
		fun f12 () {
			
		}
	}

	// f2()
	fun f2 () {
		// f21()
		fun f21 () {
			
		}

		// f22()
		fun f22 () {
			
		}

		// f23()
		fun f23 () {
			
		}
	}
}

//______________________________________________________________
// SYSTEM DESIGN

{ // Lambda L
	// f1()
	{ // Lamdba L1
		// f11()
		{ // Lamdba L12
			
		}

		// f12()
		{ // Lamdba L12
			
		}
	}

	// f2()
	{ // Lamdba L2
		// f21()
		{ // Lamdba L21
			
		}

		// f22()
		{ // Lamdba L22
			
		}

		// f23()
		{ // Lamdba L23
			
		}
	}
}



