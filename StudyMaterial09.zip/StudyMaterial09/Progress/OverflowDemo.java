
package learnJava;

class OverflowDemo {
  public static void main(String[] args) {
    System.out.println("*** Signed 32 bit integers ***\n");
    System.out.println(-(-2147483647 - 1));
    System.out.println(  2000000000 + 2000000000 );
    System.out.println( -2147483647 - 2147483647 );
    System.out.println( 46341 * 46341 );
    System.out.println(( -2147483647 - 1 ) / -1);

// *** Signed 32 bit integers ***

// -2147483648
// -294967296
// 2
// -2147479015
// -2147483648

    // System.out.println("\n*** Signed 64 bit integers ***\n");
    // System.out.println(-(-9223372036854775807 - 1));
    // System.out.println(5000000000000000000 + 5000000000000000000);
    // System.out.println(-9223372036854775807 - 9223372036854775807);
    // System.out.println(3037000500 * 3037000500);
    // System.out.println((-9223372036854775807 - 1) / -1);

    // // Simulated unsigned computations, 
    // // no overflow warnings as we're using the Long type
    // System.out.println("\n*** Unsigned 32 bit integers ***\n");
    // System.out.println((-4294967295L).toUInt());
    // System.out.println((3000000000L.toUInt() + 3000000000L.toUInt()).toUInt());
    // System.out.println((2147483647L - 4294967295L.toUInt()).toUInt());
    // System.out.println((65537L * 65537L).toUInt());
    }
}
