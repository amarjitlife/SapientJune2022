
/*
kotlinc KotlinLambdasAndHoFs.kt -include-runtime -d lambdas.jar
java -jar lambdas.jar 
*/

package learnKotlin

//_______________________________________________________________

data class Person( val name: String, val age : Int )

fun findTheOldest( persons : List<Person> ) : Person {
	var maxAge = 0
	var theOldest: Person? = null

	for ( person in persons ) {
		if ( person.age > maxAge ) {
			maxAge = person.age
			theOldest = person
		}
	}
	
	return if ( theOldest != null ) theOldest else Person(name = "Unspecified", age = 0 )
}

fun playWithTheOldest() {
	val persons = listOf( Person("Alice", 20), Person( "Martin", 60), Person("Bon", 40) )

	println( findTheOldest( persons ) )
}

//_______________________________________________________________

fun playWithLocalScopesUsingLambdas() {
	var something = 10
	println( something )

	val ding = { // Lambda Expression
		@Suppress("NAME_SHADOWING")
		var something = 22 ;
		println( something ) ;
	
		something = 222 ;
		println( something ) ;
	}
	ding()	
}

//_______________________________________________________________
// Experiment Following Code, MOMENT DONE >>> RAISE YOUR HANDS!!!

fun playWithLambdaExpressions() {
	val sum = { x : Int, y : Int -> x + y }

	println( sum(10, 30) )
	println( sum(100, 2000) )

	var simpleLambda = { println(44) }
	simpleLambda()

	val persons = listOf( Person("Alice", 20), Person( "Martin", 60), Person("Bon", 40),
						Person("Chandan", 30), Person("Shubhra", 28) )

	val names = persons.joinToString( separator = " ", 
										transform = { person: Person -> person.name } )
	val ages = persons.joinToString( separator = " ", 
										transform = { person: Person -> person.age.toString() } )
	println("Names : $names")
	println("Ages  : $ages")

	// maxBy Function Taking One Argument i.e. Lambda
	var maxAge = persons.maxBy( { person: Person -> person.age } )
	println("Max Age  : $maxAge")

	// maxBy Function Taking One Argument i.e. Lambda. It's Called Trailing Lambda
	maxAge = persons.maxBy { person: Person -> person.age } 
	println("Max Age  : $maxAge")

	maxAge = persons.maxBy { 
		person: Person -> person.age 
	} 
	println("Max Age  : $maxAge")

	// maxBy Function Taking One Argument i.e. Lambda. It's Called Trailing Lambda
	// Type Of The Lambda Arguemnt Can Be Inferred From Collections
	maxAge = persons.maxBy { person -> person.age } 
	println("Max Age  : $maxAge")

	// maxBy Function Taking One Argument i.e. Lambda. It's Shortcut Syntax
	// Lamdba Taking One Argument Can Be Accessed Using Predefined Term i.e. it
	maxAge = persons.maxBy { it.age } 
	println("Max Age  : $maxAge")

	val getAge = { person: Person -> person.age }
	maxAge = persons.maxBy( getAge ) 
	println("Max Age  : $maxAge")

	val nameToAge = listOf("Alice" to 42, "Bob" to 28, "Carol" to 51)
	val oldestPerson = nameToAge.maxByOrNull { it.second }
	println(oldestPerson) // (Carol, 51)

	val emptyList = emptyList<Pair<String, Int>>()
	val emptyMax  = emptyList.maxByOrNull { it.second }
	println(emptyMax) // null
}

//_______________________________________________________________
// Experiment Following Code, MOMENT DONE >>> RAISE YOUR HANDS!!!

// Higer Order Functions
//		HoF Are Functions Which Can Take Functions As Arguments
//				AND/OR
//		Can Return Functions From Function
// Function Type (Int) -> Int
fun moveForward( start : Int ) : Int {
	return start + 1 
}
// Function Type (Int) -> Int
fun moveBackward( start : Int ) : Int {
	return start - 1 
}

// Higher Order Function : Function Returning Function
// Function Type : (Boolean) -> (Int) -> Int
fun chooseSteps( forwards : Boolean ) : (Int) -> Int  {
	return if ( forwards ) ::moveForward else ::moveBackward
} 

fun playWithChooseSteps() {
	var start = 100

	// What Is Type Of move???
	//			RHS Return Type Is (Int) -> Int 
	var move: (Int) -> Int = chooseSteps( forwards = true )
	start = move( start )
	println( start ) 

	start = move( start )
	println( start ) 

	start = move( start )
	println( start ) 

	start = 100

	move = chooseSteps( forwards = false )
	start = move( start )
	println( start ) 

	start = move( start )
	println( start ) 

	start = move( start )
	println( start ) 

	val something : (Int) -> Int = ::moveForward
	println(something)

	// What Is Type Of somethingAgain???
	val somethingAgain: (Boolean) -> (Int) -> Int = ::chooseSteps
	println(somethingAgain)
}


//_______________________________________________________________
// Experiment Following Code, MOMENT DONE >>> RAISE YOUR HANDS!!!

// Higher Order Function : Function Returning Function
// Function Type : (Boolean) -> (Int) -> Int

fun chooseStepsAgain( forwards : Boolean ) : (Int) -> Int  {
	fun moveForward( start : Int )  : Int {  return start + 1  }
	fun moveBackward( start : Int ) : Int {  return start - 1  }

	return if ( forwards ) ::moveForward else ::moveBackward
} 

fun playWithChooseStepsAgain() {
	var start = 100

	// What Is Type Of move???
	//			RHS Return Type Is (Int) -> Int 
	var move: (Int) -> Int = chooseStepsAgain( forwards = true )
	start = move( start )
	println( start ) 

	start = move( start )
	println( start ) 

	start = move( start )
	println( start ) 

	start = 100

	move = chooseStepsAgain( forwards = false )
	start = move( start )
	println( start ) 

	start = move( start )
	println( start ) 

	start = move( start )
	println( start ) 

	// What Is Type Of somethingAgain???
	val somethingAgain: (Boolean) -> (Int) -> Int = ::chooseStepsAgain
	println(somethingAgain)
}

//_______________________________________________________________
// Experiment Following Code, MOMENT DONE >>> RAISE YOUR HANDS!!!

fun chooseStepsOnceAgain( forwards : Boolean ) : (Int) -> Int  {
	val moveForward  = {  start : Int -> start + 1  }
	val moveBackward = {  start : Int -> start - 1  }

	return if ( forwards ) moveForward else moveBackward
} 

fun playWithChooseStepsOnceAgain() {
	var start = 100

	// What Is Type Of move???
	//			RHS Return Type Is (Int) -> Int 
	var move: (Int) -> Int = chooseStepsOnceAgain( forwards = true )
	start = move( start )
	println( start ) 

	start = move( start )
	println( start ) 

	start = move( start )
	println( start ) 

	start = 100

	move = chooseStepsOnceAgain( forwards = false )
	start = move( start )
	println( start ) 

	start = move( start )
	println( start ) 

	start = move( start )
	println( start ) 

	// What Is Type Of somethingAgain???
	val somethingAgain: (Boolean) -> (Int) -> Int = ::chooseStepsOnceAgain
	println(somethingAgain)
}

//_______________________________________________________________
// Experiment Following Code, MOMENT DONE >>> RAISE YOUR HANDS!!!

// Code Blocks 
fun sum(x : Int, y : Int ) : Int  { return  x + y }
fun sub(x : Int, y : Int ) : Int  { return  x - y }
fun mul(x : Int, y : Int ) : Int  { return  x * y }
fun div(x : Int, y : Int ) : Int  { return  x / y }

// Polymorphism
// Polymorphic Function

// Higer Order Functions
//		HoF Are Functions Which Can Take Functions As Arguments
//				AND/OR
//		Can Return Functions From Function
fun calculator(x : Int, y : Int, operation: (Int, Int) -> Int ) : Int {
	return operation( x, y )
}

fun playWithCalculator() {
	val xx = 40
	val yy = 10
	var result: Int 

	result = calculator( xx, yy, ::sum ) // ::sum Is Reference Of Function sum
	println( "Result : $result" )

	result = calculator( xx, yy, ::sub ) // ::sub Is Reference Of Function sub
	println( "Result : $result" )

	result = calculator( xx, yy, ::mul ) // ::mul Is Reference Of Function mul
	println( "Result : $result" )

	result = calculator( xx, yy, ::div ) // ::div Is Reference Of Function div
	println( "Result : $result" )

	// What Is The Type Of something
	val something = ::sum 	// Type Inferred From RHS Is (Int, Int)-> Int 
	result = something( 900, 90 )
	println( "Result : $result" )

	// What Is The Type Of somethingMore
	// 	Type Inferred From RHS Is (Int, Int, (Int, Int)-> Int ) -> Int
	// ::calculator Is Reference Of Function calculator
	val somethingMore: (Int, Int, (Int, Int)-> Int ) -> Int = ::calculator
	result = somethingMore( 900, 90, ::sum )
	println( "Result : $result" )
}


//_______________________________________________________________
// Experiment Following Code, MOMENT DONE >>> RAISE YOUR HANDS!!!

fun sum(x : Int, y : Int ) : Int  { return  x + y }
fun sub(x : Int, y : Int ) : Int  { return  x - y }
fun mul(x : Int, y : Int ) : Int  { return  x * y }
fun div(x : Int, y : Int ) : Int  { return  x / y }


// Design Principle
//		Design Towards Abstract Type Rather Than Types

// Corollary : Deducing Best Practices From Fundamental Principle
	// SOLID 
	// S : Single Responisbility Design
	// O : Open-Close Design

// Immmergent Properties Of System
	// Polymorphism
	// Polymorphic Function

// Higer Order Functions
//		HoF Are Functions Which Can Take Functions As Arguments
//				AND/OR
//		Can Return Functions From Function
// Function Type : (Int, Int, (Int, Int) -> Int ) -> Int 
fun calculatorAgain(x : Int, y : Int, operation: (Int, Int) -> Int ) : Int {
	return operation( x, y )
}

fun playWithCalculatorAgain() {
	val xx = 40
	val yy = 10
	var result: Int 

	//				Lambda Is An Object Of Function Type (Int, Int) -> Int
	val sumLambda = { x: Int, y: Int -> x + y }
	// result = calculatorAgain( xx, yy, ::sum )
	result = calculatorAgain( xx, yy, sumLambda )
	println( "Result : $result" )

	val subLambda = { x: Int, y: Int -> x - y }
	// result = calculatorAgain( xx, yy, ::sub )
	result = calculatorAgain( xx, yy, sumLambda )
	println( "Result : $result" )

	val mulLambda = { x: Int, y: Int -> x * y }
	result = calculatorAgain( xx, yy, mulLambda )
	println( "Result : $result" )

	val divLambda = { x: Int, y: Int -> x / y }
	result = calculatorAgain( xx, yy, divLambda )
	println( "Result : $result" )

	// What Is The Type Of something
	val something = ::sum 	// Type Inferred From RHS Is (Int, Int)-> Int 
	result = something( 900, 90 )
	println( "Result : $result" )

	// What Is The Type Of somethingMore
	// 	Type Inferred From RHS Is (Int, Int, (Int, Int)-> Int ) -> Int
	val somethingMore: (Int, Int, (Int, Int)-> Int ) -> Int = ::calculatorAgain
	result = somethingMore( 900, 90, ::sum )
	println( "Result : $result" )
}

//_______________________________________________________________
// Experiment Following Code, MOMENT DONE >>> RAISE YOUR HANDS!!!

fun chooseStepsOnceMore( forwards : Boolean, starts : Int ) : (Int) -> Int  { // Enclosing Context
	var something = starts
	// Enclosed Context Captures The Enclosing Context In An Object
	//		This Object Will Created And Initailsed To Local State Of Enclosing Context
	//		Captured Context Object Will Be Moved To Heap.
	///		Lambad Objects In Heap Will Have Pointer To This Captured Context Object\

	val moveForwardLambda: (Int) -> Int  = {  start : Int -> something = something + 1 ; something } // Enclosed Context
	val moveBackwardLamda: (Int) -> Int  = {  start : Int -> something = something - 1 ; something }

	// val moveForwardLambda: (Int) -> Int  = {  start : Int -> starts  + 1  } // Enclosed Context
	// val moveBackwardLamda: (Int) -> Int  = {  start : Int -> starts  - 1  }

	return if ( forwards ) moveForwardLambda else moveForwardLambda
} 

fun playWithChooseStepsOnceMore() {
	var start = 100
	// What Is Type Of move???
	//			RHS Return Type Is (Int) -> Int 
	var move: (Int) -> Int = chooseStepsOnceMore( forwards = true, starts = start )
	var moveAgain = chooseStepsOnceMore( forwards = false, starts = start )
	
	start = move( start )
	println( start ) 

	start = move( start )
	println( start ) 

	start = moveAgain( start )
	println( start ) 

	start = move( start )
	println( start ) 

	start = move( start )
	println( start ) 
	
	start = moveAgain( start )
	println( start ) 
}

// Function : playWithChooseStepsOnceMore
// 101
// 102
// 101
// 102
// 103
// 102

//_______________________________________________________________
// Experiment Following Code, MOMENT DONE >>> RAISE YOUR HANDS!!!

fun countErrorResponse( responses: Collection<String> ) {
	var clientErrors = 0 
	var serverErrors = 0

	responses.forEach {
		if ( it.startsWith("4") ) {
			clientErrors++
		} else if ( it.startsWith("5") ) {
			serverErrors++
		}
	} 

	println("Client Errors = $clientErrors, Server Errors = $serverErrors" )
}

fun playWithResponsesCounting() {
	var responses = listOf( "200 OK", "404 Not Found", "500 Server Internal Error", 
		"505 Server Down", "400 Balleee Baleee", "410 Ding Dong" )

	countErrorResponse( responses )
}


//_______________________________________________________________
// Experiment Following Code, MOMENT DONE >>> RAISE YOUR HANDS!!!

var currentStudentName : String? = null

val studentName = {
										// Elvis Operator Followed By Default Value
	val nameToPrint = currentStudentName ?: "Our Favorite Student!!"
	// val nameToPrint =  if ( currentStudentName != null ) currentStudentName else "Our Favorite Student!!"

	println( "Welcome $nameToPrint!")
}

fun playWithStudentName() {
	studentName()
	currentStudentName = "Aravindhan Asokan"
	studentName()	
}

// Function : playWithStudentName
// Welcome Our Favorite Student!!!
// Welcome Aravindhan Asokan!

//_______________________________________________________________
// Experiment Following Code, MOMENT DONE >>> RAISE YOUR HANDS!!!

fun makeIncrementor( amount: Int ) : () -> Int {
	// Local Variable - Default Life Is Function.Stack Frame
	var runningTotal = 0

	// Local Function
	fun incrementor() : Int {
		// Immutable Copy Enclosing State As ReadOnly
		runningTotal = runningTotal + amount
		return runningTotal
	}

	// incrementor()
	// Visibility
	return ::incrementor
}

fun playWithIncrementor() {
	var result : Int 

	val incrementByTen = makeIncrementor( amount = 10 )
	result = incrementByTen()
	println("Result incrementByTen : $result")

	result = incrementByTen()
	println("Result incrementByTen : $result")

	result = incrementByTen()
	println("Result incrementByTen : $result")

	val incementBySeven = makeIncrementor( amount = 7 )
	result = incementBySeven()
	println("Result incementBySeven : $result")

	result = incementBySeven()
	println("Result incementBySeven : $result")

	result = incrementByTen()
	println("Result incrementByTen : $result")

	// Closures Are Reference Types 
	// i.e. Following Is Reference Assignment
	val alsoIncrementByTen = incrementByTen
	result = alsoIncrementByTen()
	println("Result alsIncrementByTen : $result")
}

//_______________________________________________________________
// Experiment Following Code, MOMENT DONE >>> RAISE YOUR HANDS!!!

fun makeIncrementorAgain( amount: Int ) : () -> Int {
	var runningTotal = 0

	val incrementorLambda : () ->  Int = {
		runningTotal = runningTotal + amount
		runningTotal
	}

	return incrementorLambda
}

fun playWithIncrementorAgain() {
	var result : Int 

	val incrementByTen = makeIncrementorAgain( amount = 10 )
	result = incrementByTen()
	println("Result incrementByTen : $result")

	result = incrementByTen()
	println("Result incrementByTen : $result")

	result = incrementByTen()
	println("Result incrementByTen : $result")

	val incementBySeven = makeIncrementorAgain( amount = 7 )
	result = incementBySeven()
	println("Result incementBySeven : $result")

	result = incementBySeven()
	println("Result incementBySeven : $result")

	result = incrementByTen()
	println("Result incrementByTen : $result")

	// Closures Are Reference Types 
	//i.e. Following Is Reference Assignment
	val alsoIncrementByTen = incrementByTen
	result = alsoIncrementByTen()
	println("Result alsIncrementByTen : $result")
}

//_______________________________________________________________


// PURE FUNCTION
//		Mathematical Functions i.e. The Way Mathematics Defines Function
//			In mathematics, a function from a set X to a set Y assigns to each element of X 
//			exactly one element of Y.[1] 
//			The set X is called the domain of the function and 
//			the set Y is called the codomain of the function

//		For Same Input Tuple Function Will Give Same Output Tuple All The Times
//		i.e. Function Will Not Create Side Effects
//			Function Will Not Print Or Scan Values
//			Function WIll Not Change Argument Values
//			Function Will Not Access Global State
//			Function Will Not Throw Exceptions
//			Function Does Changes To Something Internal That Will Not Be Exposed Outside Of The Function

// Corollary
// 		In Functional Paradigm State Is Immutable
//			You Transform One State To Another State By Creating New State
// e.g.

	val value = 4 
	val newValue = value * value

var somethingGlobal = 10

// Is doSquare A Pure Function???
// Is NOT A Pure Function
fun doSquareNotPure( number : Int  ) : Int {
	println( "Doing Square..." )
	var square = number * number
	somethingGlobal = somethingGlobal + square
	return square
}


// Is NOT A Pure Function
fun doSquareAgainNotPure( number : Int  ) : Int {
	// Because println Writes To Global Variable stdout
	println( "Doing Square..." )
	var square = number * number
	return square
}

fun doCubeNotPure( number : Int  ) : Int {
	var cube = number * number * number
	if (somethingGlobal == 89 ) {
		cube = somethingGlobal + cube
	}
	return cube
}

//_______________________________________________________________

// THIS A PURE FUNCTION
//		For Same Input Tuple Function Will Give Same Output Tuple All The Times
fun doSquarePure( number : Int  ) : Int {
	var square = number * number
	return square
}

fun doCubePure( number : Int  ) : Int {
	var cube = number * number * number
	return cube
}

//_______________________________________________________________

fun playWithDoSquare() {
	var number = 10
	var square = doSquarePure( number )
	println(" Square Of $number = $square ")

	number = 25
	square = doSquarePure( number )
	println(" Square Of $number = $square ")
}


//_______________________________________________________________
// Example To Show Implementation Of Higher Order Function
//		Taking Lambda As Last Argument
//		and Passing Argument As Trailing Lambda

fun twoAndThree( operation : (Int, Int) -> Int )  : Int {
	val x = 2
	val y = 3
	// Assingment Is Statement In Kotlin Not Expression
	// return result = operation(x, y) 
	return operation(x, y)
}

fun playWithTwoAndThree() {
	var result: Int

	result = twoAndThree( { x: Int, y: Int -> x + y } )
	println("Result : $result")

	result = twoAndThree( { x: Int, y: Int -> x - y } )
	println("Result : $result")

	// Passing Argument As Trailing Lambda 
	result = twoAndThree { x: Int, y: Int -> x + y } 
	println("Result : $result")
	
	// Passing Argument As Trailing Lambda 
	result = twoAndThree { x: Int, y: Int -> x - y } 
	println("Result : $result")
}


//_______________________________________________________________

// Predicate Definition
// https://en.wikipedia.org/wiki/Predicate_(mathematical_logic)

// IS Following Function PURE FUNCTION ???
fun filterString( string: String, predicate: ( Char ) -> Boolean ) : String {
	val stringBuild = StringBuilder()

	for ( index in 0 until string.length ) {
		val element = string.get( index )
	
		if ( predicate( element ) ) stringBuild.append( element )
	}
	return stringBuild.toString()
}

// Design Evolution
//		1. First Write Ordinary Function
//			Which Will Filter On Fix Logic
//			e.g. Write Function filterUpperCaseLetters( string String ) : String
//			e.g. Write Function filterLowerCaseLetters( string String ) : String
// 		2. Classify Lines Of Code Into Invariant Code and Variant Code 
//		3. Extract Out Variant Code Into Seperate Function And Use This Function
//				e.g. FiteringCrieteria\
//		4. Evolve Your Ordinary Function To Higher Order Function
//				By Passing General Filtering Criteria		
//		5. Is This HoF Can Be Made Extension Function?
//				To Make Standard API Accessible Across Code Base
//		6. Make This Extension Function As Pure Function

// filter Is Polymorphic
// Example of filter Pure Function Implmentation
fun String.filter( predicate: ( Char ) -> Boolean ) : String {
	val stringBuild = StringBuilder()

	for ( index in 0 until this.length ) {
		val element = this.get( index )
	
		if ( predicate( element ) ) stringBuild.append( element )
	}
	return stringBuild.toString()
}

fun playWithFilterString() {
	println( filterString( "abcABC$6756uuuMMvvNN65%", { element -> element in 'a'..'z' } ) ) 
	println( filterString( "abcABC$6756uuuMMvvNN65%", { element -> element in '0'..'9' } ) ) 
	
	println( filterString( "abcABC$6756uuuMMvvNN65%", { element -> 
		element in 'a'..'z' || element in 'A'.. 'Z'
	} ) ) 

	println( "abcABC$6756uuuMMvvNN65%".filter( { element -> element in 'a'..'z' } ) )  
	println( "abcABC$6756uuuMMvvNN65%".filter( { element -> element in '0'..'9' } ) )
	
	println( "abcABC$6756uuuMMvvNN65%".filter( { element -> 
		element in 'a'..'z' || element in 'A'.. 'Z'
	}  ) )

	println( "abcABC$6756uuuMMvvNN65%".filter {  // Trailing Lambda
			element -> 
			element in 'a'..'z' || element in 'A'.. 'Z'
		} 
	) 

}

// Function :playWithFilterString
// abcuuuvv
// 675665
// abcABCuuuMMvvNN

//_______________________________________________________________


fun <T> Collection<T>.joinToStringFinal(
	separator: String = ", ",
	prefix: String = "",
	postfix: String = "",
	transform: (T) -> String = { it.toString() }
) : String {

	val result = StringBuilder( prefix ) 
	for( (index, element) in this.withIndex() ) {
		if ( index > 0 ) result.append( separator )
		result.append( transform(element) )
	}

	result.append( postfix )
	return result.toString()
}

fun playWithJoinToStringFinal() {
	// Type Inferencing and Binding Happening
	val list = listOf( 10, 20, 30, 40, 50 ) // ArrayList<Integer>
	println( list.joinToStringFinal( " ; ", "( ", " )" ) )
	println( list.joinToStringFinal( ) )
	println( list.joinToStringFinal( " : ") )
	println( list.joinToStringFinal( " : ", "[ " ) )
	println( list.joinToStringFinal( " : ", "[ ", " ]" ) )

	// Type Inferencing and Binding Happening
	val names = listOf("Alice", "Martin", "Chandan", "Ashish" ) // ArrayList<String>
	println( names.joinToStringFinal( " ; ", "( ", " )" ) )
	println( names.joinToStringFinal(  ) )	
	println( names.joinToStringFinal( " : " ) )	
	println( names.joinToStringFinal( " : ", "[ " ) )	
	println( names.joinToStringFinal( " : ", "[ ", " ]" ) )	
}

//_______________________________________________________________

// Composing Pure Functions
fun playWithFilterMap() {
    val numbers = listOf(1, 2, 3, 4, 6, 7, 8, 9, 10)

    //	f o g 
    var result = numbers.map { it * it }
            			.filter { it % 2 == 0 }
    println( "Result : $result" )

    // Following Code Is Far More Efficient
    //	g o f 
    result = numbers.filter { it % 2 == 0 }
    				.map { it * it }    
    println( "Result : $result" )            
}

// Function : playWithFilterMap
// Result : [4, 16, 36, 64, 100]
// Result : [4, 16, 36, 64, 100]

//_______________________________________________________________

// Some Java Design Commentory

// // SAM : Single Abstract Method Interfaces
// public interface onClickLister {
// 	void onClick( View v );
// }

// public class Button {
// 	public void setOnClickLister( onClickLister listener ) {

// 	}
// }

// // Using Code As Follows : Style 1

// //						Anonyomous Classes
// button.setOnClickLister( new onClickLister {
// 	@Override
// 	public void onClick( View v ) {
// 		// Your Action Logic
// 	}
// } )

// // Compiler Will Generate Following Code For Above Lines....

// class TemporaryClickListerClass implements onClickLister {
// 	@Override
// 	public void onClick( View v ) {
// 		// Your Action Logic
// 	}	
// }

// onClickLister temporaryClickObject = new TemporaryClickListerClass()
// button.setOnClickLister( temporaryClickObject )

// // Using Code As Follows : Style 2

// // Wherever You Can Pass Anyonmous Class Implementing SAM Interfaces
// // There You Can Pass Lambda
// button.setOnClickLister( { /* Lambda Action Logic To Be Executed On Button Click */ } )

// // Compiler Will Generate Following Code For Above Lines....

// class TemporaryClickListerClass implements onClickLister {
// 	@Override
// 	public void onClick( View v ) {
// 		// Your Action Logic
// 		{ /* Lambda Action Logic To Be Executed On Button Click */ }()
// 	}	
// }

// onClickLister temporaryClickObject = new TemporaryClickListerClass()
// button.setOnClickLister( temporaryClickObject )

//_______________________________________________________________

// @FunctionalInterface
// public interface ShortToByteFunction {

//     byte applyAsByte(short s);

// }

// Now we can write a method that transforms an array of short to an array of byte using a rule defined by a ShortToByteFunction:

// public byte[] transformArray(short[] array, ShortToByteFunction function) {
//     byte[] transformedArray = new byte[array.length];
//     for (int i = 0; i < array.length; i++) {
//         transformedArray[i] = function.applyAsByte(array[i]);
//     }
//     return transformedArray;
// }

// Here’s how we could use it to transform an array of shorts to an array of bytes multiplied by 2:

// short[] array = {(short) 1, (short) 2, (short) 3};
// byte[] transformedArray = transformArray(array, s -> (byte) (s * 2));

// byte[] expectedArray = {(byte) 2, (byte) 4, (byte) 6};
// assertArrayEquals(expectedArray, transformedArray);

//_______________________________________________________________
// Experiment Following Code, MOMENT DONE >>> RAISE YOUR HANDS!!!

fun alphabets() : String {
	val stringBuild = StringBuilder()

	for ( letter in 'A'..'Z' ) {
		stringBuild.append( letter )
	}
	stringBuild.append("\nNow I Know Alphabets!")
	return stringBuild.toString()
}

fun alphabetsWith() : String {
	val stringBuild = StringBuilder()
	
	// with Is Scoping Functions
	return with( stringBuild ) {
		for ( letter in 'A'..'Z' ) {
			this.append( letter )
		}
		// this.append("\nNow I Know Alphabets!")
		append("\nNow I Know Alphabets!")
		this.toString()		
	}
}

fun alphabetsWithAgain() = with( StringBuilder() ) {
	for ( letter in 'A'..'Z' ) {
		append( letter )
	}
	// this.append("\nNow I Know Alphabets!")
	append("\nNow I Know Alphabets!")
	toString()		
}

fun alphabetsApply() = StringBuilder().apply {
	for ( letter in 'A'..'Z' ) {
		this.append( letter )
	}
	// this.append("\nNow I Know Alphabets!")
	append("\nNow I Know Alphabets!")
}.toString()

fun playWithAlpabets() {
	println( alphabets() )
	println( alphabetsWith() )
	println( alphabetsWithAgain() )
	println( alphabetsApply() )
}


// Here is a short guide for choosing scope functions depending on the intended purpose:
	// Executing a lambda on non-null objects: let
	// Introducing an expression as a variable in local scope: let
	// Object configuration: apply
	// Object configuration and computing the result: run
	// Running statements where an expression is required: non-extension run
	// Additional effects: also
	// Grouping function calls on an object: with

// Context object: this or it﻿
// 		Inside the lambda of a scope function, the context object is available 
//		by a short reference instead of its actual name. 
//		Each scope function uses one of two ways to access the context object: 
//			as a lambda receiver (this) or as a lambda argument (it)

//_______________________________________________________________

// applyThenReturn Is Extension Function On Type Place Holder <T> and Return T Type Object
//		Take One Argument Which Is Lamdba
//		This Lamdba Argumnent Takes One Argument Of Type Place Holder T and Return Unit Type

fun <T> T.applyThenReturn( lambdaExprn : (T) -> Unit ) : T {
    lambdaExprn( this )
    return this
}

// Lambda With Receiver 
// 										// T Place Holder Act As Receiver For Lambda
fun <T> T.applyThenReturnAgain( lambdaExprnWithReceier : T.() -> Unit ): T {
    lambdaExprnWithReceier() // or this.lambdaExprnWithReceier()
    return this
}

fun playWithExtensionFunction() {
	var name: String

	name = "Baeldung".applyThenReturn { n -> println(n.toUpperCase()) }
	println( name )

	name = "Baeldung".applyThenReturn { println( it.toUpperCase() ) }
	println( name )

	var nameAgain = "Baeldung".applyThenReturnAgain { 
		println( toUpperCase() ) 
	}
	println( nameAgain )
}


//_______________________________________________________________
//_______________________________________________________________
//_______________________________________________________________
//_______________________________________________________________
//_______________________________________________________________
//_______________________________________________________________
// Experiment Following Code, MOMENT DONE >>> RAISE YOUR HANDS!!!

fun main() {	
	println("\nFunction : playWithTheOldest")
	playWithTheOldest()

	println("\nFunction : playWithLocalScopesUsingLambdas")
	playWithLocalScopesUsingLambdas()

	println("\nFunction : playWithLambdaExpressions")
	playWithLambdaExpressions()

	println("\nFunction : playWithCalculator")
	playWithCalculator()

	println("\nFunction : playWithChooseSteps")
	playWithChooseSteps()

	println("\nFunction : playWithChooseStepsAgain")
	playWithChooseStepsAgain()

	println("\nFunction : playWithChooseStepsOnceAgain")
	playWithChooseStepsOnceAgain()

	println("\nFunction : playWithCalculatorAgain")
	playWithCalculatorAgain()

	println("\nFunction : playWithChooseStepsOnceMore")
	playWithChooseStepsOnceMore()

	println("\nFunction : playWithResponsesCounting")
	playWithResponsesCounting()

	println("\nFunction : playWithStudentName")
	playWithStudentName()

	println("\nFunction : playWithIncrementor")
	playWithIncrementor()

	println("\nFunction : playWithIncrementorAgain")
	playWithIncrementorAgain()

	println("\nFunction : playWithTwoAndThree")
	playWithTwoAndThree()

	println("\nFunction :playWithFilterString")
	playWithFilterString()

	println("\nFunction : playWithJoinToStringFinal")
	playWithJoinToStringFinal()

	println("\nFunction : playWithFilterMap")
	playWithFilterMap()

	println("\nFunction : playWithAlpabets")
	playWithAlpabets()

	println("\nFunction : playWithExtensionFunction")
	playWithExtensionFunction()

	// println("\nFunction : ")
	// println("\nFunction : ")	
	// println("\nFunction : ")
	// println("\nFunction : ")
}

/*
kotlinc KotlinLambdasAndHoFs.kt -include-runtime -d lambdas.jar
java -jar lambdas.jar 
*/