
import Foundation

// Modelling WhatsApp Message

struct Messaage {
	let userID : String
	let contents: String?
	let date: Date

	let hasJoined: Bool
	let hasLeft : Bool
	let isMessageDrafted: Bool
	let isSendingBalloons: Bool
}


let joinMessage = Messaage( userID: "100",
	contents: nil,
	date: Date(),
	hasJoined: true,
	hasLeft: false,
	isMessageDrafted: false,
	isSendingBalloons: false
);

let textMessage = Messaage( userID: "100",
	contents: "Good Afternoon!!!",
	date: Date(),
	hasJoined: true,
	hasLeft: false,
	isMessageDrafted: false,
	isSendingBalloons: false
);

let badMessage = Messaage( userID: "100",
	contents: "Good Afternoon!!!",
	date: Date(),
	hasJoined: true,
	hasLeft: true,
	isMessageDrafted: false,
	isSendingBalloons: true
);


// Remodelled Message
enum Message {
	case text(userID: String, contents: String, date: Date)
	case draft(userID: String, date: Date)
	case join(userID: String, date: Date)
	case leave(userID: String, date: Date)
	case balloon(userID: String, date: Date)
}




