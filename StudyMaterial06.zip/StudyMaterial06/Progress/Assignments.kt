
__________________________________________________________________________

DAY 05
__________________________________________________________________________

	ASSSIGNMENT A1 : READING ASSIGNMENTS
	
		Java Serialisation Pitfalls
			https://github.com/pmd/pmd/issues/2992
			https://docs.oracle.com/javase/tutorial/java/javaOO/nested.html#Serialization

	ASSSIGNMENT A2 : READING ASSIGNMENTS

		The C Programming Language, 2nd Edition
			By Kernigham and Dennis Ritchie

		1. Arrays and Pointers Chapter [ MUST READ ]
		2. Rest All Chapters Depends On Your Interest


	ASSSIGNMENT A3 : KOTLIN CODE REVISION AND EXPERIMENTATION

		Revise and Experiment Kotlin Code Done Till Now


__________________________________________________________________________

FUTURE REFERENCES
__________________________________________________________________________


		Structure And Interpretation Of Computer Program [ SICP BOOK ]
		Link : https://mitpress.mit.edu/sites/default/files/sicp/full-text/book/book.html

