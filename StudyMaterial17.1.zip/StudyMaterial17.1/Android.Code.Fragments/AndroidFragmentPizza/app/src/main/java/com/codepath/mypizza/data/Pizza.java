package com.codepath.mypizza.data;

/**
 * Created by Shyam Rokde on 8/5/16.
 */
public class Pizza {

  public static String[] pizzaMenu = {
      "ALL MEAT PIZZA",
      "CALIFORNIA VEGGIE",
      "GARLIC CHICKEN"
  };

  public static String[] pizzaDetails = {
      "Premium Crushed Tomato Sauce made of 100% California grown vine ripened tomatoes topped with premium salami, pepperoni, all-natural Italian sausage and seasoned pork.",
      "Premium crushed tomato sauce, fresh green peppers, fresh red onions, fresh mushrooms, diced Roma tomatoes and fresh spinach—flavored up with our Hut Favorite on the crust edge and a balsamic sauce drizzle. Best on our Thin 'N Crispy crust.",
      "Creamy garlic Parmesan sauce, grilled chicken, applewood smoked bacon and diced Roma tomatoes—flavored up with toasted Parmesan on the crust edge. Best on our Hand Tossed crust."
  };
}
