
// Class name must be "Main"
// Libraries included:
// json simple, guava, apache commons lang3, junit, jmock

 void playWithChooseFov() {
        List<Cat> cat = new ArrayList<>();
        cat.add(new Cat("Abc", "abc"));
        cat.add(new Cat("Abc1", "abc1"));
        cat.add(new Cat("Abc2", "abc2"));
       // System.out.printf("Size:- " + chooseFavorite(pet));
        System.out.printf("Size:- " + chooseFavorite(cat));//Not Ac
    }


    Pet chooseFavorite(List<Pet> list) {
        Random random = new Random();
        Pet fav = (Pet) list.get(random.nextInt(list.size()));
        System.out.printf("Fav" + fav);
        return fav;
    }

public class Pet extends Animal {
    Pet(String name, String type) {
        super(type);
    }
}

public class Cat extends Pet {
    Cat(String name, String type) {
        super(name, type);
    }
}

class Main {
    public static void main(String[] args) {
        System.out.println("Hello, world!");
    }
}

