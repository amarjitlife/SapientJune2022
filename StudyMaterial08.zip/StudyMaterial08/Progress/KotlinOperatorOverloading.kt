
package learnKotlin;

import java.util.Date
import java.time.LocalDate

//_______________________________________________________________


data class Point( val x: Int, val y : Int )  {
	operator fun plus( other: Point ) : Point {
		return Point( x + other.x, y + other.y )
	}

	// operator fun component1() = x
	// operator fun component2() = y	
}

operator fun Point.minus( other: Point ) : Point {
	return Point( this.x - other.x, this.y - other.y )
}

operator fun Point.times( scale: Int ) : Point {
	return Point( x * scale, y *scale )
}

// operator fun Point.plusAssign( other: Point ) {
// 	x = x + other.x
// 	y = y + other.y
// }

operator fun Point.unaryMinus() : Point {
	return Point( -x, -y )
}

fun playWithPoint() {
	val point1 = Point(100, 200)
	val point2 = Point(10, 20)

	val point3 = Point( point1.x + point2.x, point1.y + point2.y )
	println( point1 )
	println( point2 )
	println( point3 )

	// Using Overloaded + Operator
	val point4 = point1 + point2 	// Compiler Will Generate point1.plus( point2 )
	println( point4 )

	val point5 = point1 - point2 	// Compiler Will Generate point1.minus( point2 )
	println( point5 )

	val point6 = point1 * 3 		// Compiler Will Generate point1.times( 3 )
	val point7 = point2 * 10        // Compiler Will Generate point2.times( 10 )
	println( point6 )
	println( point7 )

	var point8 = Point(10, 20)

	point8 += point2 				// Compiler Will Generate point1.plusAssign( point2 )
	println( point8 )
}

//_______________________________________________________________

// Expressions 		Operator Function Name
// a * b 				times
// a + b 				plus
// a - b  				minus
// a / b   				div
// a % b   				mod 

// -a 					unaryMinus
// +a 					unaryPlus
// !a 					not
// ++a, a++ 			inc
// --a. a-- 			dec

// a >= b 				a.compareTo( b ) >= 0

// Bit Wise Operations Functions Used In Infix Notation
// shl  - Signed Shift Left
// shr  - Signed Shift Right
// ushr - Unsighned Shift Right
// and 	- Bitwise and
// or   - Bitwise or
// xor  - Bitwise xor
// inv 	- Bitwise Inversion

// plusAssign
// minusAssign
// timesAssign and so on...


fun playWithBitwiseOperators() {
			// Infix Notation
	println( 0x0F and 0xF0 )
	println( 0x0F or 0xF0 )
}

//_______________________________________________________________

data class PointAgain( var x: Int, var y : Int )

operator fun PointAgain.get( index : Int ) : Int {
	return when( index ) {
		0  ->  x
		1  ->  y 
		// else Part Simutlates Java Behaviour
		else -> throw IndexOutOfBoundsException("Invalid Index : $index")
	}
}

operator fun PointAgain.set( index : Int, value: Int ) {
	when( index ) {
		0  ->  x = value 
		1  ->  y = value
		// else Part Simutlates Java Behaviour
		else -> throw IndexOutOfBoundsException("Invalid Index : $index")
	}
}

fun playWithSubscriptOperator() {
	val point = PointAgain(100, 200)

	// Using Subscript Operator To Access point Coordinates
	val xCoordinate = point[0]  	// Compiler Will Generate point.get( index = 0 )
	val yCoordinate = point[1] 		// Compiler Will Generate point.get( index = 1 )

	println( xCoordinate )
	println( yCoordinate )

	// Using Subscript Operator To Change point Coordinates
	point[0] = 111  				// Compiler Will Generate point.set( index = 0, value = 111 )
	point[1] = 222 					// Compiler Will Generate point.set( index = 0, value = 222 )

	println( point )

	// val (x, y) = point  // Decluttering Or Unpacking  x = point.component1() ,  y = point.component2()
}


//_______________________________________________________________

// data class Point( val x: Int, val y : Int )

data class Rectangle( val upperLeft: Point, val lowerRight: Point )

operator fun Rectangle.contains( point: Point ) : Boolean {
	return point.x in upperLeft.x until lowerRight.x &&
		   point.y in upperLeft.y until lowerRight.y
}

fun playWithPointInsideRectangle() {
	val point = Point( 25, 50)
	val pointAgain = Point( -25, -50)

	val rectangle = Rectangle( Point( 0, 0 ), Point( 100, 100) )

	println( point in rectangle ) 			// Compiler Will Generate rectangle.contains( point )
	println( pointAgain in rectangle )      // Compiler Will Generate rectangle.contains( pointAgain )

}

//_______________________________________________________________

fun playWithRangeOperator() {
	val n = 9

	println( 0..(n+1) )

	(0..n).forEach { println( "Number : $it" ) }
}

//_______________________________________________________________
// Experiment Following Code, MOMENT DONE >>> RAISE YOUR HANDS!!!

// import java.util.Date
// import java.time.LocalDate

operator fun ClosedRange<LocalDate>.iterator() : Iterator<LocalDate> =
	object : Iterator<LocalDate> {
		var current = start

		override fun hasNext() = current <= endInclusive
		
		override fun next() = current.apply {
			current = plusDays( 1 )
		}
	}

fun playWithDateRange() {
	val newYear = LocalDate.ofYearDay( 2022, 1 )

	val daysOff = newYear.minusDays(10)..newYear

	for ( dayOff in daysOff ) {
		println( dayOff ) 
	}

	for ( dayOff in newYear.minusDays(10)..newYear ) {
		println( dayOff ) 
	}

	// Best Practice : Use for-in Loop Rather Than Indexing Loop

	// int a[10] = { 10, 20, 30, 40, 50, 60, 70, 80, 90, 100}; 
	// // Indexing Loop
	// for ( int index = 0 ; index < length ; index++ ) {
	// 		//Accessing Elements
	// 		// Specific Logic 
	// 	// Exposing Internal Implementation Of Array
	// 	// 		i.e. Breaking Encapsualtion
	// 		a[ index ]	
	// }

}	


//_______________________________________________________________
//_______________________________________________________________
//_______________________________________________________________
//_______________________________________________________________
// Experiment Following Code, MOMENT DONE >>> RAISE YOUR HANDS!!!

fun main() {
	println("\nFunction : playWithPoint")
	playWithPoint()

	println("\nFunction : playWithBitwiseOperators")
	playWithBitwiseOperators()

	println("\nFunction : playWithSubscriptOperator")
	playWithSubscriptOperator()

	println("\nFunction : playWithPointInsideRectangle")
	playWithPointInsideRectangle()

	println("\nFunction : playWithRangeOperator")
	playWithRangeOperator()

	println("\nFunction : playWithDateRange")
	playWithDateRange()

	// println("\nFunction : ")
	// println("\nFunction : ")	
	// println("\nFunction : ")
	// println("\nFunction : ")
}

/*
kotlinc KotlinOperatorOverloading.kt -include-runtime -d operators.jar
java -jar operators.jar 
*/