
package learnKotlin;

fun makeIncrementor( amount: Int ) : () -> Int {
    var runningTotal = 0
    
    fun incrementor() : Int {
        runningTotal = runningTotal + amount
        return runningTotal
    }
    
    return ::incrementor
}

fun playWithMakeIncrementor() {
    var result : Int

    val incrementByTen = makeIncrementor( amount = 10 )
    result = incrementByTen()
    println("Result incrementByTen: $result")

    result = incrementByTen()
    println("Result incrementByTen: $result")

    result = incrementByTen()
    println("Result incrementByTen: $result")

    val incrementBySeven = makeIncrementor( amount = 7)
    result = incrementBySeven()
    println("Result incrementBySeven: $result")

    result = incrementBySeven()
    println("Result incrementBySeven: $result")

    result = incrementBySeven()
    println("Result incrementBySeven: $result")

    result = incrementByTen()
    println("Result incrementByTen: $result")

    // Closures are Reference Types
    val alsoIncrementByTen = incrementByTen
    result = alsoIncrementByTen()
    println("Result alsoIncrementByTen: $result")
}

fun main() {
    playWithMakeIncrementor()
}

/*
kotlinc Experiments.kt -include-runtime -d experiment.jar
java -jar experiment.jar 
*/