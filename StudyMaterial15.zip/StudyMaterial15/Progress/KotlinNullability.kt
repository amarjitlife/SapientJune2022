
package learnKotlin;

// DESIGN PRINCIPLE
// 		Design Towards NON Nullability Rather Than Nullability

// In Java
//		Every Reference In Java Is Nullable By Default
//		It Can Store null Value
//		It Can Becone null Any Time In Code
//		null and Exeptions Break Type Definitions
///		NullPointerException Is RunTime Error

// Human h = new Human();
// Person p = new Person();

// h.fly();

// //Defensive Programming
// // 		Nested Hell It Becomes Ugly
// if ( h != null ) {
// 	if( h.address != null ) {
// 		h.address.city
// 		if( h.address.city != null ) {
// 			h.address.city.pinCode
// 		}
// 	}


// 	h.fly();
// 	h.dance();
// }

// if ( h != null ) {
// 	p.eat();
// 	p.drink();
// }


//_______________________________________________________________
// Experiment Following Code, MOMENT DONE >>> RAISE YOUR HANDS!!!

fun stringLength( string: String? ) : Int = if ( string != null ) string.length else 0

// Elvis Operator ( ?: ) 
//		Synxtax : 
//			Operand ?: DefaultValue
// 		Evlis Operator Returns Default Values If Operand Becomes null
//		Ohterwise Operand Value
fun stringLengthAgain( string: String? ) : Int = string?.length ?: 0


fun playWithStringLength() {
	var s : String? = null

	println( stringLength( s ) )
	println( stringLength( "Good Morning!" ) )

	val someFlag = false
	if( someFlag ) s = "Good Morning!" else s = null

	// error: only safe (?.) or non-null asserted (!!.) calls are allowed 
	// 		on a nullable receiver of type String?
	// val upperString = s.uppercase() // BAD CODE
	
	// For Nullable Objects Use Safe Access Operator i.e. ?.
	// Inferred Type Of upperString From RHS Will Be String?
	// val upperString = s?.uppercase() 

	// !! Fallback To Java Behaviour
	// !! Operator WIll Be Used In Rarest Rare Scenrious
	//		Interfacing With Java API
	//		Backward Compatibility With Java
	// val upperString = s!!.uppercase()  // java.lang.NullPointerException

	val upperString = s?.uppercase()
	//Compiler Will Generate Following Code For Above Line
	// val upperString  = if ( s != null ) s.uppercase() else null
	println( upperString )
}

// Design Your Kotlin API with Kotlin Mindset and Design Principles
// 		Migrate Old Java Code To Kotin Mindset 
//			By Using Annotations e.g @NotNull and @Nullable				

//_______________________________________________________________
// Experiment Following Code, MOMENT DONE >>> RAISE YOUR HANDS!!!

class Employee( val name: String, val manager: Employee? )

// Inferred Return Type Of Function
//		Will Be String?
//		Because employee.manager?.name Can Be String Or null Value

fun managerName( employee: Employee ) = employee.manager?.name 
// fun managerName( employee: Employee ) : String? = employee.manager?.name 


fun playWithManagerName() {
	val ceo = Employee("Elon Musk", null)
	val developer = Employee("Ashish Rawat", Employee("Sapient Manager", null ) )

	println( managerName( ceo ) )
	println( managerName( developer ) )
}

//_______________________________________________________________
// Experiment Following Code, MOMENT DONE >>> RAISE YOUR HANDS!!!

class Address( val streetName: String, val city: String, val country: String, val zipCode: Int)

class Company( val name: String, val address: Address? )

class Person(val name: String, val company: Company? )

fun Person.countryName() : String {
	// Optionals Chaining
	// In The Expression this.company?.address?.country If Any Part Becomes null
	//		Then Expression Evaluates To null
	
	// Hence Inferred Type For country Will Be String?
	val country = this.company?.address?.country 
	
	// return if ( country != null ) country else "Unkown"
	return country ?: "Unkown"
}

fun playWithPersonCompanyName() {
	val alice = Person("Alice Carol", null) 
	val martin = Person("Martin", Company("Sapient", null)) 
	val address = Address("MG Road", "Bangalore", "India", 500001 )
	val martinSecond = Person("Martin II", Company("Sapient", address )) 

	println( alice.countryName() )
	println( martin.countryName() )
	println( martinSecond.countryName() )

	val person : Any = alice

	// Inferred Type Will Be Person?
	// as? Will Try To Convert To Type 
	//		If Type Conversion Successful Then Return TypeCast Object
	//		If Type Conversion Fails Then Return null
	val somePerson = person as? Person
	println( somePerson )
}

//_______________________________________________________________

// DESIGN PRINCIPLE
//		Always Prefer Nullabe Types Rather Than Exceptions Throwing

fun summation( a : Int , b: Int ) : Int? {
	if (((b > 0) && (a > ( Int.MAX_VALUE - b))) ||
	  	((b < 0) && (a < ( Int.MIN_VALUE - b)))) {
		return null;
  	} else {  // Result Is Closed In int Type Range
		val result = a + b;
	  	return result;	
  	}
}

fun playWithSummation() {
	val result = summation( 10, 30 )

	println( result )
}

//_______________________________________________________________
// Experiment Following Code, MOMENT DONE >>> RAISE YOUR HANDS!!!

fun playWithLetScopingFunction() {
	var person: Person? // Nullable Types Objects Always Initialised To null

	val someFlag = false	
	person = if( someFlag ) Person( "Alice", null ) else null

	// warning: elvis operator (?:) always returns the left operand of non-nullable type Unit
	val something0 =  person.let {  println("Person Name: ${ person?.name }") } 
	println( something0 )

	// warning: elvis operator (?:) always returns the left operand of non-nullable type String
	// Elvis Operator Doesn't Make Sense Here...
	val something1 =  person.let {  "Person Name: ${ person?.name }" }  ?: "Something"
	println( something1 )

	val something2 =  person.let {  "Person Name: ${ person?.name }" ; null }  ?: "Something"
	println( something2 )
	
	val somethingAgain0 =  person.let { println("Person Name: ${ person?.name }" ) } 
	println( somethingAgain0 )

 	// warning: unnecessary safe call on a non-null receiver of type Person?
	val somethingAgain1 =  person?.let { println("Person Name: ${ it.name }" ) } 
	println( somethingAgain1 )
}

// foo?.let {
//	 	it...
// } 

// foo != null Than 'it' Will Not Null Inside Lambda
// Otherwise If foo == null Than Whole Expression Becomes null 


// foo.let {
//	 	it...
// } 

// foo != null Than 'it' Will Not Be Null Inside Lambda
// Otherwise If foo == null Than 'it' Will Becomes null 

//_______________________________________________________________
//_______________________________________________________________
//_______________________________________________________________
//_______________________________________________________________
// Experiment Following Code, MOMENT DONE >>> RAISE YOUR HANDS!!!

fun main() {
	println("\nFunction : playWithStringLength")
	playWithStringLength()

	println("\nFunction : playWithManagerName")
	playWithManagerName()

	println("\nFunction : playWithPersonCompanyName")
	playWithPersonCompanyName()

	println("\nFunction : playWithSummation")
	playWithSummation()

	println("\nFunction : playWithLetScopingFunction")
	playWithLetScopingFunction()

	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")

}

/*
kotlinc KotlinNullability.kt -include-runtime -d nullability.jar
java -jar nullability.jar
*/