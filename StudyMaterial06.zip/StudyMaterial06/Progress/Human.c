
#include <stdio.h>

typedef struct human_type {
	int id;
	char name[100];
	void (*dance)();
} Human;

void doBhangara() {
	printf("Doing Bhagra!!!");	
}

void doBharatnatayam() {
	printf("Doing Bharatnatayam!!!");	
}


int main() {
	// What Is The Difference Between Variables And Objects

	// h Is A Object Of Human Type????
	Human h = { 100, "Alice ", doBhangara };

	printf("Human ID: %d\n", h.id );
	printf("Human Name: %s\n", h.name );
	h.dance();
}

