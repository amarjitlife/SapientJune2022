package learnCoroutines

import kotlinx.coroutines.*
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.channels.*

import java.lang.Thread.sleep
import kotlin.system.*

// DESIGN PRINCIPLE
//      DESIGN TOWARDS CONCURRENCY RATHER THAN PARALLELISM
//      i.e. Model System At Abstract Level
//      As A Set Of Concurrent Tasks i.e Coroutines
/*

> A _coroutine_ is an instance of suspendable computation.

It is conceptually similar to a thread, in the sense that it
takes a block of code to run that works concurrently with
the rest of the code.

However, a coroutine is not bound to any particular thread.
It may suspend its execution in one thread and resume in another one.

Coroutines can be thought of as light-weight threads,
but there is a number of important differences that make
their real-life usage very different from threads.

# COROUTINE BUILDER

[launch] is a _coroutine builder_.
It launches a new coroutine concurrently with
the rest of the code, which continues to work independently

[runBlocking] is also a coroutine builder
that bridges the non-coroutine world of a regular `fun main()` and
the code with coroutines inside of `runBlocking { ... }` curly braces.

[delay] is a special _suspending function_.
It _suspends_ the coroutine for a specific time.

>   Suspending a coroutine does not _block_ the underlying thread, but allows
>   other coroutines to run and use the underlying thread for their code.

The name of `runBlocking` means that the thread that runs it
(in this case the main thread) gets _blocked_ for
the duration of the call, until all the
coroutines inside `runBlocking { ... }` complete their execution.

// BEST PRACTICE
`runBlocking` used like that at the very top-level of the application
 and quite rarely inside the real code, as threads are expensive resources
 and blocking them is inefficient and is often not desired.

// STRUCTURED CONCURRENCY

Coroutines follow a principle of **structured concurrency** which
means that new coroutines can be only launched in a specific
[CoroutineScope] which delimits the lifetime of the coroutine.

In a real application, you will be launching a lot of coroutines.
Structured concurrency ensures that they are not lost and do not leak.

>   An outer scope cannot complete until all its children coroutines complete.

Structured concurrency also ensures that
any errors in the code are properly reported and
are never lost.

// RESOURCES Managed By Operating System
//      Files, Threads, Processes, Sockets, Pipes, Semaphores, Mutexes etc...
    FILE fileDescriptor = fopen("FileName.txt", "r");
    // In Finally Block You Must Free Up Resources
    fclose();
    Thread thread = new Thread()

*/

//-------------------------------------------------------------------------
//-------------------------------------------------------------------------

// Created Two Concurrent Coroutines
// In this case main Is Just Function Call
//fun main() {

// main Assigned A Coroutine Returned By runBlocking Coroutine Builder
//     Hence main itself becomes Coroutine
//fun main() = runBlocking {
//    // launch Will Create A New Coroutine
//    println("runBlocking Created Coroutine!")
//
//    // launch Coroutine Builder Is An Extension Function On CoroutineScope
//    launch {
//        println("launch Created Coroutine!")
//        delay( 1000L )
//        println( "World!" )
//    }
//
////    delay( 1000L )
//    println("Hello!")
//    // It Will Be Blocked Till Other Coroutine Completes It!
//    //       Because That Is The Nature Of Coroutine
//    //       Created By runBlocking Coroutine Builder
//}

//-------------------------------------------------------------------------
//-------------------------------------------------------------------------

/*
When you perform "Extract function" refactoring on this code,
you get a new function with the `suspend` modifier.
Suspending functions can be used inside coroutines
just like regular functions, but their additional feature
is that they can, in turn, use other suspending functions
*/

//fun main() = runBlocking {
//    println("runBlocking Created Coroutine!")
//    launch {
//        doWorld()
//    }
//    println("Hello!")
//}
//
//suspend fun doWorld() {
//    println("launch Created Coroutine!")
//    delay(1000L)
//    println("World!")
//}

//-------------------------------------------------------------------------
//-------------------------------------------------------------------------

/*
// SCOPE BUILDER

In addition to the coroutine scope provided by different builders,
it is possible to declare your own scope using the [coroutineScope]
builder.

It creates a coroutine scope and does not complete until
all launched children complete.

[runBlocking] and coroutineScope builders may look similar
because they both wait for their body and all its children to complete.

The main difference is that the [runBlocking] method _blocks_ the
current thread for waiting, while [coroutineScope][_coroutineScope]
just suspends, releasing the underlying thread for other usages.

Because of that difference, [runBlocking] is a regular function and
[coroutineScope][_coroutineScope] is a suspending function.

You can use `coroutineScope` from any suspending function.
*/

//fun main() = runBlocking {
//    doWorld()
//}
//
//suspend fun doWorld() = coroutineScope {
//    launch {
//        delay(1000L )
//        println( "World!")
//    }
//    println("Hello")
//}


//-------------------------------------------------------------------------
//-------------------------------------------------------------------------

/*
A [coroutineScope] builder can be used inside any
suspending function to perform multiple concurrent operations.
*/
//
//fun main() = runBlocking {
//    doWorld()
//    println("Done...")
//}
//
//suspend fun doWorld() = coroutineScope {
//    launch {
//        delay( 2000L )
//        println( "World 2...")
//    }
//    launch {
//        delay( 3000L )
//        println( "World 1...")
//    }
//    println("World")
//}

/*
A coroutineScope in doWorld completes only after both coroutines completes
and so doWorld() returns.
*/

//-------------------------------------------------------------------------
//-------------------------------------------------------------------------

// Job Using Coroutine
/*
A [launch] coroutine builder returns a [Job] object
that is a handle to the launched coroutine and can be
used to explicitly wait for its completion.
*/

//fun main() = runBlocking {
//    val job = launch {
//        delay( 1000L )
//        println("World!")
//    }
//
//    println("Hello")
//    job.join() // Wait Until Child Coroutine Completes
//    println("Done")
//}

//fun main() {
//    val job = GlobalScope.launch {
//        delay( 1000L )
//        println("World!")
//    }
//
//    println("Hello")
////    job.join() // Wait Until Child Coroutine Completes
//    println("Done")
////    sleep( 2000L )
//}

//-------------------------------------------------------------------------
//-------------------------------------------------------------------------

//Coroutines are less resource-intensive than JVM threads. Code that exhausts the
//JVM's available memory when using threads can be expressed using coroutines
//without hitting resource limits

// Coroutines Are Cheap!
//fun main() = runBlocking {
//    repeat(1000_000 ) {
//        launch {
////            delay(1000L)
//            print(".")
//        }
//    }
//    println("Done With One Million Coroutines...")
//}

//fun main() = runBlocking {
//    repeat(1000_000 ) {
//        doSomething()
//    }
//    println("Done With One Million Coroutines...")
//}
//
//fun doSomething() {
////   delay(1000L)
//    val thread = Thread {
//        println("${Thread.currentThread()} has run.")
//        print(".")
//    }
//    thread.start()
//}

//-------------------------------------------------------------------------
//-------------------------------------------------------------------------

/*
// CANCELLING COROUTINES EXECUTION

In a long-running application you might need fine-grained control
on your background coroutines.
*/

//fun main() = runBlocking {
//    val job = launch {
//        repeat( 1000 ) { i ->
//            delay( 500L )
//            println("Job : Going To Sleep $i...")
//        }
//    }
//    delay( 1300L )
//    println("Main Coroutine Tired Of Waiting...")
//    job.cancel()
//    println("Main Waiting Coroutine To Join...")
//    job.join()
//    println("Main Coroutine Completing...")
//}

//-------------------------------------------------------------------------
//-------------------------------------------------------------------------

/*
## Cancellation is cooperative

Coroutine cancellation is _cooperative_.
A coroutine code has to cooperate to be cancellable.

> All the suspending functions in `kotlinx.coroutines` are _cancellable_.

They check for cancellation of  coroutine and throw [CancellationException]
when cancelled.

However, if a coroutine is working in
a computation and does not check for cancellation, then it cannot be cancelled
*/

//fun main() = runBlocking {
//    val startTime = System.currentTimeMillis()
//
//    val job = launch( Dispatchers.Default ) {
//        var nextPrintTime = startTime
//        var i = 0
//        while ( i < 5 ) {
//            if ( System.currentTimeMillis() >= nextPrintTime ) {
//                println("Job: Going For Sleep ${i++} ...")
//                nextPrintTime += 500L
//            }
//        }
//    }
//    println("Main: Tired Of Waiting...")
//    job.cancelAndJoin()
//    println("Main Coroutine Completing...")
//    delay( 500L )
//}

//-------------------------------------------------------------------------
//-------------------------------------------------------------------------

// Making Coroutine Cancellable
// isActive Is An Extension Property Of coroutineScope

// DESIGN PRINCIPLE
//      Explicitly Check Coroutine Is Marked For Cancellation
//          Don't Do Any Heavy Calculations/Processing When Coroutine Marked For Cancellation

//fun main() = runBlocking {
//    val startTime = System.currentTimeMillis()
//
//    val job = launch( Dispatchers.Default ) {
//        var nextPrintTime = startTime
//        var i = 0
//        while( isActive ) {
//            // Coroutine Have To Cooperate To Be Cancellable
//            // Coroutine Checking Marked For Cancellation.
//            //      Coroutine isActive Flag Set To False On Receive Of Cancellation Request
//            if ( System.currentTimeMillis() >= nextPrintTime ) {
//                println("Job: Going For Sleep ${i++} ...")
//                nextPrintTime += 500L
//            }
//        }
//    }
//    println("Main: Tired Of Waiting...")
//    job.cancelAndJoin()
//    println("Main Coroutine Completing...")
//    delay( 500L )
//}

//-------------------------------------------------------------------------
//-------------------------------------------------------------------------

// DESIGN PRINCIPLE

// PRIMARY DESIGN PRINCIPLE IN MODERN DESIGN
// Special cases aren't special enough to break the Design.
//      Corollary: Exceptions Are Not That Exceptional Such That
//          It Should Break Your Design

// SECONDARY DESIGN PRINCIPLE IN MODERN DESIGN
// Errors/Exceptions should never pass silently.
//      Unless explicitly silenced.

/* FINALLY, BLOCK BEST PRACTICES IN COROUTINE
Any attempt to use a suspending function in the finally block
causes [CancellationException], because the coroutine running this code is cancelled.

Usually, this is not a problem, since all well-behaving closing operations
(closing a file, cancelling a job, or closing any communication channel)
are usually non-blocking and do not involve any suspending functions.

However, in the rare case when you need to suspend in a cancelled coroutine
you can wrap the corresponding code in withContext(NonCancellable) {...}
using [withContext] function and [NonCancellable] context
*/

//fun main() = runBlocking {
//    val startTime = System.currentTimeMillis()
//    val job = launch( Dispatchers.Default ) {
//        var nextPrintTime = startTime
//        var i = 0
//        repeat(5 ) { i ->
//            try {
//                println("Job: Going For Sleep $i ...")
//                delay(500L)
////            } catch( e: Exception ) { // BAD PATTERN
////                // Catching TOPMOST "Exception" Is BAD PATTERN
////                //      It Will Catch All Exceptions
////                //      Always Catch Narrow Exception Rather Than Broad Exception Class
////                //          i.e. Start From Leaf Node In Exception Hierarchy
////                println( e )
////            }
//            } catch (e: CancellationException ) { // GOOD PATTERN
//                // Your Custom Handler...
//                // Catching TOPMOST "Exception" Is GOOD PATTERN
//                //      It Will Catch All Exceptions
//                //      Always Catch Narrow Exception Rather Than Broad Exception Class
//                //          i.e. Start From Leaf Node In Exception Hierarchy
//                println(e)
//            } finally {
//                // Deallocate All The Resources
//                // Make Sure It's Atomic Operation
//                withContext( NonCancellable ) {
//                    println("Finally Block:  Execution Started...")
//                    delay( 1000L )
//                    println("Finally Block Is Execution Completing...")
//                }
//            }
//        }
//        println( "To Remove Warnings: $nextPrintTime $i ")
//    }
//    delay( 1300L )
//    println("Main: Tired Of Waiting...")
////    job.cancelAndJoin()
//    println("Main Coroutine Completing...")
//    delay( 500L )
//}

//kotlinx.coroutines.JobCancellationException: StandaloneCoroutine was cancelled

//-------------------------------------------------------------------------
//-------------------------------------------------------------------------

// DESIGN PRINCIPLE
//      Design Towards Determinism Rather Than Non-Determinism
//      Corollary: Design Towards Hard Real-Time Rather Than Towards Soft-Real-Time

// Real-Time Systems???
// Hard Real-time Systems Vs. Soft Real-time Systems
//      1. Order Of Execution
//      2. Time Of Completion

/*
// Coroutine With Timeout
The most obvious practical reason to cancel execution of a coroutine is
because its execution time has exceeded some timeout.

/// DESIGN 1
While you can manually track the reference to the corresponding [Job]
and launch a separate coroutine to cancel the tracked one after delay,

/// DESIGN 2
there is a ready to use [withTimeout] function that does it.
*/

//fun main() = runBlocking {
//    // withTimeout Is Coroutine Builder
//    //      It Will Launch A Coroutine with Time As Hard Upper Bound
//
////  withTimeoutOrNull( 1300L ) {
//    val result = withTimeoutOrNull( 1300L ) {
//        repeat(1000) { i ->
//            println("Going For Sleep : $i")
//            delay( 500L )
//        }
//    }
//    println("Result : $result")
//}

/*
The TimeoutCancellationException that is thrown by [withTimeout]
is a subclass of [CancellationException].
We have not seen its stack trace printed on the console before.
That is because inside a cancelled coroutine CancellationException
is considered to be a normal reason for coroutine completion.
However, in this example we have used withTimeout right inside the main function.

Since cancellation is just an exception, all resources are closed in the usual way.
You can wrap the code with timeout in a
try {...} catch (e: TimeoutCancellationException) {...} block
if you need to do some additional action specifically on any kind of timeout
or use the [withTimeoutOrNull] function that is similar
to [withTimeout] but returns null on timeout instead of throwing an exception:
*/

//-------------------------------------------------------------------------
//-------------------------------------------------------------------------

/*
// Asynchronous timeout and resources
The timeout event in [withTimeout] is asynchronous with respect to the code running
in its block and may happen at any time, even right before
the return from inside of the timeout block.

>>>> Keep this in mind if you open or acquire
>>>> some resource inside the block that needs closing or release outside of the block

*/

//-------------------------------------------------------------------------
//-------------------------------------------------------------------------
//
//var acquired = 0
//
//class Resource {
//    init { acquired++ }
//    fun close() { acquired-- }
//}
//
//fun main() {
//    runBlocking {
//        repeat( 100_000 ) {
//            launch {
//                val result = withTimeout( 60 ) {
//                    delay( 30 )
//                    Resource()
//                }
//                result.close()
//            }
//        }
//    }
//    println( acquired )
//}

//-------------------------------------------------------------------------
//-------------------------------------------------------------------------

/*
Note that incrementing and decrementing acquired counter here from 100K coroutines
is completely Thread safe, since it always happens from the same main thread.
More on that will be explained in the chapter on coroutine context.
*/

//var acquired = 0
//
//class Resource {
//    init { acquired++ }
//    fun close() { acquired-- }
//}
//
//fun main() {
//    runBlocking {
//        repeat( 100_000 ) {
//            launch {
//                // Better To Store Resource In Your Resource Reference
//                //      Rather Than Returning From withTimeout Block
//                //      And Close Explicitly In finally Block
//                var resource: Resource? = null
//                try {
//                    withTimeout(60) {
//                        delay(30)
//                        resource = Resource()
//                    }
//                } finally {
//                    resource?.close()
//                }
//            }
//        }
//    }
//    println( acquired )
//}


//-------------------------------------------------------------------------
//-------------------------------------------------------------------------

/*
Conceptually, [async] is just like [launch].
It starts a separate coroutine which is a light-weight thread
that works concurrently with all the other coroutines.

The difference is that launch returns a [Job] and does not carry any resulting value,
while async returns a [Deferred] — a light-weight non-blocking future
that represents a promise to provide a result later.

You can use .await() on a deferred value to get its eventual result,
but Deferred is also a Job, so you can cancel it if needed.
*/

//fun main() = runBlocking<Unit>{
//    val time = measureTimeMillis {
//        // async Launches Separate Coroutine And Returns Differed Object
//        val one = async { doSomethingUsefulOne() }
//        val two = async { doSomethingUsefulTwo() }
//        println("The Answer Is: ${ one.await() + two.await() }")
//    }
//    println("runBlock Completed In Time: $time ms")
//}
//
////The Answer Is: 42
////runBlock Completed In Time: 1023 ms
//suspend fun doSomethingUsefulOne() : Int {
//    println("Called: doSomethingUsefulOne")
//    delay( 500L )
//    return 13
//}
//
//suspend fun doSomethingUsefulTwo() : Int {
//    println("Called: doSomethingUsefulTwo")
//    delay( 1000L )
//    return 29
//}

//-------------------------------------------------------------------------
//-------------------------------------------------------------------------

/*
Optionally, [async] can be made lazy by setting its start parameter to
[CoroutineStart.LAZY]. In this mode it only starts the coroutine when
its result is required by await, or if its Job's start function is invoked.
*/

//fun main() = runBlocking<Unit>{
//    val time = measureTimeMillis {
//        // async Launches Separate Coroutine And Returns Differed Object
////        val one = async( start = CoroutineStart.LAZY ) { doSomethingUsefulOne() }
////        val two = async { doSomethingUsefulTwo() }
//        val one = async( start = CoroutineStart.LAZY ) { doSomethingUsefulOne() }
//        val two = async( start = CoroutineStart.LAZY ) { doSomethingUsefulTwo() }
//
//        one.start() // Starting On Demand
//        two.start() // Starting On Demand
//
//        println("The Answer Is: ${ one.await() + two.await() }")
//    }
//    println("runBlock Completed In Time: $time ms")
//}
//
////The Answer Is: 42
////runBlock Completed In Time: 1023 ms
//suspend fun doSomethingUsefulOne() : Int {
//    println("Called: doSomethingUsefulOne")
//    delay( 500L )
//    return 13
//}
//
//suspend fun doSomethingUsefulTwo() : Int {
//    println("Called: doSomethingUsefulTwo")
//    delay( 1000L )
//    return 29
//}

/*
Note that if we just call await in println without first calling start on
individual coroutines, this will lead to sequential behavior,
since await starts the coroutine execution and waits for its finish,
which is not the intended use-case for laziness.

The use-case for async(start = CoroutineStart.LAZY) is a replacement for
the standard lazy function in cases when computation of the value
involves suspending functions.
*/

//-------------------------------------------------------------------------
//-------------------------------------------------------------------------

/*
Consider what happens if between the val one = somethingUsefulOneAsync() line
and one.await() expression there is some logic error in the code, and
the program throws an exception, and the operation that was being performed by
the program aborts. Normally, a global error-handler could catch this exception,
log and report the error for developers, but the program could otherwise
continue doing other operations. However, here we have somethingUsefulOneAsync
still running in the background, even though the operation that initiated it
was aborted
*/

//fun main() {
//    val time = measureTimeMillis {
//        // Initiated async Actions Outside of Coroutine
//        val one = somethingUsefulOneAsync()
//        val two = somethingUsefulTwoAsync()
//
//        // waiting for a result must involve either suspending or blocking.
//        // here we use `runBlocking { ... }` to block the main thread
//        // while waiting for the result
//        runBlocking {
//            println("The Answer Is: ${ one.await() + two.await() }")
//        }
//    }
//    println("runBlock Completed In Time: $time ms")
//}
//

// // BAD PATTERN
//@OptIn(DelicateCoroutinesApi::class)
//fun somethingUsefulOneAsync() = GlobalScope.async {
//    doSomethingUsefulOne()
//}
//
//@OptIn(DelicateCoroutinesApi::class)
//fun somethingUsefulTwoAsync() = GlobalScope.async {
//    doSomethingUsefulTwo()
//}
//
////The Answer Is: 42
////runBlock Completed In Time: 1023 ms
//suspend fun doSomethingUsefulOne() : Int {
//    println("Called: doSomethingUsefulOne")
//    delay( 1000L )
//    return 13
//}
//
//suspend fun doSomethingUsefulTwo() : Int {
//    println("Called: doSomethingUsefulTwo")
//    delay( 1000L )
//    return 29
//}


//-------------------------------------------------------------------------
//-------------------------------------------------------------------------

//fun main() = runBlocking {
//    val time = measureTimeMillis {
//            println("The Answer Is: ${ concurrentSum() }")
//    }
//    println("runBlock Completed In Time: $time ms")
//}
//
//// GOOD PATTERN
//suspend fun concurrentSum() : Int = coroutineScope {
//    val one = async { doSomethingUsefulOne() }
//    val two = async { doSomethingUsefulTwo() }
//    one.await() + two.await()
//}
//
//suspend fun doSomethingUsefulOne() : Int {
//    println("Called: doSomethingUsefulOne")
//    delay( 1000L )
//    return 13
//}
//
//suspend fun doSomethingUsefulTwo() : Int {
//    println("Called: doSomethingUsefulTwo")
//    delay( 1000L )
//    return 29
//}

//-------------------------------------------------------------------------
//-------------------------------------------------------------------------

//fun main() = runBlocking {
//    val time = measureTimeMillis {
//        try { failedConcurrentSum() }
//        catch( e: ArithmeticException ) {
//            println("Caught Exception ArithmeticException ")
//        }
//    }
//    println("runBlock Completed In Time: $time ms")
//}
//
//// GOOD PATTERN
//suspend fun failedConcurrentSum() : Int = coroutineScope {
//    val one = async<Int> {
//        println("UsefulOne Called...")
//        try {
//            delay( Long.MAX_VALUE )
//            println("UsefulOne After Delay ...")
//            42
//        } finally {
//            println("UsefulOne Cancelling It...")
//        }
//    }
//
//    val two = async<Int> {
//        println("UsefulTwo Called : Throwing Exception...")
////        doSomethingUsefulTwo()
//        // Simulation Of Exception Happened In This Code
//        throw ArithmeticException()
//    }
//    one.await() + two.await()
//}

/*
Note how both the first async and the awaiting parent are cancelled
on failure of one of the children (namely, two):
*/

//-------------------------------------------------------------------------
//-------------------------------------------------------------------------

//COROUTINE DISPATCHER AND THREADS

/*
Coroutines always execute in some context represented by a value of the
CoroutineContext type, defined in the Kotlin standard library.

The coroutine context includes a coroutine dispatcher (see [CoroutineDispatcher])
that determines what thread or threads the corresponding coroutine uses
for its execution.

The coroutine dispatcher can confine coroutine execution to a specific thread,
dispatch it to a thread pool, or let it run unconfined.

All coroutine builders like [launch] and [async] accept an optional CoroutineContext
parameter that can be used to explicitly specify the dispatcher for the
new coroutine and other context elements.

When launch { ... } is used without parameters, it inherits the context (and thus
dispatcher) from the [CoroutineScope] it is being launched from. In this case,
it inherits the context of the main runBlocking coroutine which runs in the main thread.

[Dispatchers.Unconfined] is a special dispatcher that also appears to run in
the main thread with different Mechanism

The default dispatcher is used when no other dispatcher is explicitly specified
in the scope. It is represented by [Dispatchers.Default] and uses a shared
background pool of threads.

[newSingleThreadContext] creates a thread for the coroutine to run.
A dedicated thread is a very expensive resource.

// BEST PRACTICE
In a real application it must be either released, when no longer needed,
using the close function, or stored in a top-level variable and reused
throughout the application.
*/

//fun main() = runBlocking<Unit> {
//    launch {
//        println("Launch runBlocking ${Thread.currentThread().name} ")
//    }
//
//    launch( Dispatchers.Unconfined ) {
//        println("Unconfined ${Thread.currentThread().name} ")
//    }
//
//    launch( Dispatchers.Default ) {
//        println("Default ${Thread.currentThread().name} ")
//    }
//
//    launch( newSingleThreadContext("MyOwnThread") ) {
//        println("newSingleThreadContext ${Thread.currentThread().name} ")
//    }
//
//    launch( Dispatchers.IO ) {
//        println("IO ${Thread.currentThread().name} ")
//    }
//
//    println("Main runBlocking ${Thread.currentThread().name} ")
//}

//-------------------------------------------------------------------------
//-------------------------------------------------------------------------

/*
The [Dispatchers.Unconfined] coroutine dispatcher starts a coroutine in the
caller thread, but only until the first suspension point.

After suspension, it resumes the coroutine in the thread that is fully
determined by the suspending function that was invoked.

// BEST PRACTICE
The unconfined dispatcher is appropriate for coroutines which neither
consume CPU time nor update any shared data (like UI) confined to a specific thread.

On the other side, the dispatcher is inherited from the outer [CoroutineScope] by default.

The default dispatcher for the [runBlocking] coroutine, in particular,
is confined to the invoker thread. so inheriting it has the effect of
confining execution to this thread with predictable FIFO scheduling.
*/

//kotlinx.coroutines.DefaultExecutor

//fun main() = runBlocking<Unit> {
//    launch( Dispatchers.Unconfined ) {
//        println("Unconfined Before Delay: ${ Thread.currentThread().name }")
//        delay( 500L )
//        println("Unconfined After  Delay: ${ Thread.currentThread().name }")
//    }
//
//    launch {
//        println("Launch Before Delay: ${ Thread.currentThread().name }")
//        delay( 500L )
//        println("Launch After  Delay: ${ Thread.currentThread().name }")
//    }
//
//    println("runBlocking Before Delay: ${ Thread.currentThread().name }")
//    delay( 500L )
//    println("runBlocking After  Delay: ${ Thread.currentThread().name }")
//}

/*
So, the coroutine with the context inherited from runBlocking {...} continues
to execute in the main thread, while the unconfined one resumes in the
default executor thread that the [delay] function is using.
*/

//-------------------------------------------------------------------------
//-------------------------------------------------------------------------

//fun main() = runBlocking<Unit> {
//    launch( Dispatchers.Unconfined ) {
//        println("Unconfined Before Delay: ${ Thread.currentThread().name }")
//        delay( 500L )
//        println("Unconfined After  Delay: ${ Thread.currentThread().name }")
//    }
//
//    launch {
//        println("Launch Before Delay: ${ Thread.currentThread().name }")
//        delay( 500L )
//        println("Launch After  Delay: ${ Thread.currentThread().name }")
//    }
//
//    println("runBlocking Before Delay: ${ Thread.currentThread().name }")
//    delay( 500L )
//    println("runBlocking After  Delay: ${ Thread.currentThread().name }")
//}


//-------------------------------------------------------------------------
//-------------------------------------------------------------------------

/*
using [runBlocking] with an explicitly specified context, and the other one
is using the [withContext] function to change the context of a coroutine
while still staying in the same coroutine

 the use function from the Kotlin standard library to release threads created
 with [newSingleThreadContext] when they are no longer needed.
*/

//fun log(msg: String) = println("[${Thread.currentThread().name}] $msg")
//
//fun main() {
////sampleStart
//    newSingleThreadContext("Context01").use { Context01 ->
//        newSingleThreadContext("Context02").use { Context02 ->
//            runBlocking(Context01) {
//                log("Started in Context01")
//                withContext(Context02) {
//                    log("Working in Context02")
//                }
//                log("Back to Context01")
//            }
//        }
//    }
////sampleEnd
//}

//-------------------------------------------------------------------------
//-------------------------------------------------------------------------

//fun main() = runBlocking<Unit> {
//    println("Job : ${ coroutineContext[Job] } ")
//}

/*
Note that [isActive] in [CoroutineScope] is just a convenient shortcut for
coroutineContext[Job]?.isActive == true.
*/

//-------------------------------------------------------------------------
//-------------------------------------------------------------------------

/*
When a coroutine is launched in the [CoroutineScope] of another coroutine,
it inherits its context via [CoroutineScope.coroutineContext] and

The [Job] of the new coroutine becomes a child of the parent coroutine's job.
When the parent coroutine is cancelled, all its children are recursively cancelled, too.

However, this parent-child relation can be explicitly override in one of two ways:

// BEST PRACTICE: FOLLOWING TWO CHOICES TO BE USED IN THE RAREST RARE SCENARIOS
1. When a different scope is explicitly specified when launching a coroutine
        (for example, GlobalScope.launch), then it does not inherit a Job
        from the parent scope.

2. When a different Job object is passed as the context for the new coroutine
        then it overrides the Job of the parent scope.

    In both cases, the launched coroutine is not tied to the scope it was launched
    from and operates independently.
*/

//  mainJob
//fun main() = runBlocking {
//    val requestJob = launch {
//        launch( Job() ) {
//            println("Job1 New: Running")
//            delay( Long.MAX_VALUE )
//            println("Job1 New: Completing")
//        }
//
//        launch( ) {
////            delay(100)
//            println("Job2: Running")
//            delay( 500 )
//            println("Job2: Cancelling")
//        }
//    }
//    delay( 1000 )
//    println("Job runBlocking Requesting Cancellation")
//    requestJob.cancel()
//    println("Job runBlocking After Cancellation...")
//    delay( 5000 )
//}


//-------------------------------------------------------------------------
//-------------------------------------------------------------------------

/*
A parent coroutine always waits for completion of all its children.
A parent does not have to explicitly track all the children it launches,
and it does not have to use [Job.join] to wait for them at the end:
*/

//fun main() = runBlocking<Unit> {
////sampleStart
//    // launch a coroutine to process some kind of incoming request
//    val request = launch {
//        repeat(3) { i -> // launch a few children jobs
//            launch  {
//                delay((i + 1) * 200L) // variable delay 200ms, 400ms, 600ms
//                println("Coroutine $i is done")
//            }
//        }
//        println("request: I'm done and I don't explicitly join my children that are still active")
//    }
//    request.join() // wait for completion of the request, including all its children
//    println("Now processing of the request is complete")
////sampleEnd
//}

//-------------------------------------------------------------------------
//-------------------------------------------------------------------------

// NAMING COROUTINES
//fun log(msg: String) = println("[${Thread.currentThread().name}] $msg")
//
//fun main() = runBlocking( CoroutineName("Main") )  {
////sampleStart
//    log("Main Coroutine Started")
//    // run two background value computations
//    val v1 = async( CoroutineName("Coroutine01") ) {
//        delay(500)
//        log("Coroutine01")
//        252
//    }
//    val v2 = async(CoroutineName("Coroutine02")) {
//        delay(1000)
//        log("Coroutine02")
//        6
//    }
//    log("Result : v1 / v2 = ${v1.await() / v2.await()}")
////sampleEnd
//}

//-------------------------------------------------------------------------
//-------------------------------------------------------------------------

//Combining context elements
// Sometimes we need to define multiple elements for a coroutine context.
// We can use the + operator for that

//fun main() = runBlocking<Unit> {
////sampleStart
//    launch( Dispatchers.Default + CoroutineName("test") ) {
//        println("I'm working in thread ${Thread.currentThread().name}")
//    }
////sampleEnd
//}

//-------------------------------------------------------------------------
//-------------------------------------------------------------------------

/*
We manage the lifecycles of our coroutines by creating an instance of [CoroutineScope]
tied to the lifecycle of our activity. A CoroutineScope instance can be created by
the [CoroutineScope()] or [MainScope()] factory functions.

The former creates a general-purpose scope, while the latter creates a scope
for UI applications and uses [Dispatchers.Main] as the default dispatcher
*/

//class Activity {
//    private val mainScope = CoroutineScope( Dispatchers.Default )
//
//    fun destroy() {
//        mainScope.cancel()
//    }
//
//    fun doSomething() {
//        repeat( 10 ) { i ->
//            mainScope.launch {
//                delay( ( i + 1 ) * 200L )
//                println("Coroutine $i Done!")
//            }
//        }
//    }
//}
//
//fun main() = runBlocking<Unit> {
//    val activity = Activity()
//    activity.doSomething()
//    println("Launching Coroutines...")
//    delay( 500L )
//    println("Destroying Activity!...")
//    activity.destroy()
//    delay( 1000 )
//}

//-------------------------------------------------------------------------
//-------------------------------------------------------------------------

/*
// Thread-local data
Ability to pass some thread-local data to or between coroutines

For ThreadLocal, the [asContextElement] extension function.

It creates an additional context element which keeps the value of the
given ThreadLocal and restores it every time the coroutine switches its context.

ThreadLocal has first-class support and can be used with any primitive
kotlinx.coroutines provides.

>> It has one key limitation, though:
>> when a thread-local is mutated, a new value is not propagated to the coroutine caller
>> (because a context element cannot track all ThreadLocal object accesses),
>> and the updated value is lost on the next suspension.

Use [withContext] to update the value of the thread-local in a coroutine,
see [asContextElement] for more details.

Alternatively, a value can be stored in a mutable box like

class Counter(var i: Int),

which is, in turn, stored in a thread-local variable.
However, in this case you are fully responsible to synchronize potentially concurrent
modifications to the variable in this mutable box.

*/
//
//val threadLocal = ThreadLocal<String?>()
//
//fun main() = runBlocking {
//    threadLocal.set("Main")
//    println("Thread Starting..: ${Thread.currentThread().name } ${ threadLocal.get() }")
//    val job = launch( Dispatchers.Default + threadLocal.asContextElement( value = "Launch")) {
//        println("Launching...: ${Thread.currentThread().name } ${ threadLocal.get() }")
//        yield()
//        println("After Yield Thread: ${Thread.currentThread().name } ${ threadLocal.get() }")
//    }
//
//    job.join()
//    println("Thread Ending...: ${Thread.currentThread().name } ${ threadLocal.get() }")
//}

//-------------------------------------------------------------------------
//-------------------------------------------------------------------------

/*
A suspending function asynchronously returns a single value, but
how can we return multiple asynchronously computed values?

This is where Kotlin Flows come in.
*/

//fun simple() : List<Int> = listOf(10, 20, 30, 40, 50)
//
//fun simpleSequence() : Sequence<Int> = sequence {
//    for ( i in 1..5 ) {
//        Thread.sleep( 100 )
//        yield( i )
//    }
//}
//
//fun main() {
//    simple().forEach { value ->
//        println(value)
//    }
//
//    simpleSequence().forEach { value ->
//        println(value)
//    }
//}

/*
However, this computation blocks the main thread that is running the code.
*/

//-------------------------------------------------------------------------
//-------------------------------------------------------------------------

/*
When these values are computed by asynchronous code we can mark the
simple function with a suspend modifier, so that it can perform its
work without blocking and return the result as a list:
*/
//
//suspend  fun simple() : List<Int> {
//    delay( 1000L )
//    return listOf(10, 20, 30, 40, 50)
//}
//
//fun main() = runBlocking {
//    simple().forEach { value ->
//        println(value)
//    }
//}

/*
Using the List<Int> result type, means we can only return all the values at once.
*/

//-------------------------------------------------------------------------
//-------------------------------------------------------------------------

/*
// Flows
Using the List<Int> result type, means we can only return all the values at once.
To represent the stream of values that are being asynchronously computed,
we can use a Flow<Int> type just like we would use the Sequence<Int> type
for synchronously computed values:

*/

//fun simple(): Flow<Int> = flow {
//    println("Flow Started...")
//     for ( i in 1..5 ){
//         delay( 100 )
////        Thread.sleep(100)
//         emit( i )
//     }
//}
//
////This code waits 100ms before printing each number without blocking the main thread.
////This is verified by printing "Coroutine Not Blocked" every 100ms from a separate coroutine
////that is running in the main thread:
//
//fun main() = runBlocking {
//    launch {
//        for ( k in 1..3) {
//            println("Coroutine Not Blocked $k")
//            delay( 100 )
//        }
//    }
//    simple().collect{
//        value -> println( value )
//    }
//}

//Notice the following differences in the code with the [Flow] from the earlier examples:
//
//  A builder function for [Flow] type is called flow.
//  Code inside the flow { ... } builder block can suspend.
//  The simple function is no longer marked with suspend modifier.
//  Values are emitted from the flow using emit function.
//  Values are collected from the flow using collect function

//-------------------------------------------------------------------------
//-------------------------------------------------------------------------

// Flows are cold streams similar to sequences — the code inside a flow builder
// does not run until the flow is collected.

//fun simpleFlow(): Flow<Int> = flow {
//    println("Flow Started...")
//    for ( i in 1..5 ){
//        delay( 100 )
////        Thread.sleep(100)
//        emit( i )
//    }
//}
//
////This code waits 100ms before printing each number without blocking the main thread.
////This is verified by printing "Coroutine Not Blocked" every 100ms from a separate coroutine
////that is running in the main thread:
//
//fun main() = runBlocking {
//    println("Calling Simple Flow Function...")
//
//    val flow = simpleFlow()
//
//    println("Collecting Flow...")
//    flow.collect{
//            value -> println( value )
//    }
//
//    println("Collecting Flow...")
//    flow.collect{
//            value -> println( value )
//    }
//}

// This is a key reason the simple function (which returns a flow) is not marked with suspend
// modifier. By itself, simple() call returns quickly and does not wait for anything.
// The flow starts every time it is collected, that is why we see "Flow started"
// when we call collect again.

//-------------------------------------------------------------------------
//-------------------------------------------------------------------------

// Flow Cancellation Basics

/*
Flow adheres to the general cooperative cancellation of coroutines.
As usual, flow collection can be cancelled when the flow is suspended
in a cancellable suspending function (like [delay]).
*/

//fun simpleFlow(): Flow<Int> = flow {
//    println("Flow Started...")
//    for ( i in 1..5 ) {
//        delay( 100 )
//        println("Emitting $i")
//        emit( i )
//    }
//}
//
//fun main() = runBlocking {
//    println("Calling Simple Flow Function...")
//
//    println("Collecting Flow With Timeout...")
//
////    Flow gets cancelled on a timeout when running in a [withTimeoutOrNull] block and
////    stops executing its code:
//    withTimeoutOrNull(250) {
//        simpleFlow().collect { value ->
//            println(value)
//        }
//    }
//    println("Done!!!")
//}

//-------------------------------------------------------------------------
//-------------------------------------------------------------------------

/*
The flow { ... } builder from the previous examples is the most basic one.
There are other builders for easier declaration of flows:

-    [flowOf] builder that defines a flow emitting a fixed set of values.
-    Various collections and sequences can be converted to flows using .asFlow()
        extension functions.
*/

//fun main() = runBlocking<Unit> {
//    (1..3).asFlow().collect { value -> println( value ) }
//}
//
//-------------------------------------------------------------------------
//-------------------------------------------------------------------------

//suspend fun performRequest( request : Int ) : String {
//    delay( 1000 )
//    // Adding Prefix To The String...
//    return "Response $request"
//}
//
//fun main() = runBlocking {
//    (1..3).asFlow()
//        .map { request -> performRequest(request) }
//        .collect { response -> println( response ) }
//}

//-------------------------------------------------------------------------
//-------------------------------------------------------------------------

// TRANSFORM OPERATOR

/*
Among the flow transformation operators, the most general one is called [transform].
It can be used to imitate simple transformations like [map] and [filter],
as well as implement more complex transformations.
Using the transform operator, we can emit arbitrary values an arbitrary number of times.
*/

//suspend fun performRequest( request : Int ) : String {
//    delay( 1000 )
//    // Adding Prefix To The String...
//    return "Response $request"
//}
//
//fun main() = runBlocking {
//    (1..3).asFlow()
//        .transform { request ->
//            emit("Making Request : $request")
//            emit( performRequest(request) )
//        }
//        .collect { response -> println( response ) }
//}

//-------------------------------------------------------------------------
//-------------------------------------------------------------------------

// Size-limiting operators

/*
Size-limiting intermediate operators like [take] cancel the execution of the flow
when the corresponding limit is reached. Cancellation in coroutines is always
performed by throwing an exception, so that all the resource-management functions
(like try { ... } finally { ... } blocks) operate normally in case of cancellation:
*/

//sampleStart
//fun numbers(): Flow<Int> = flow {
//    try {
//        emit(1)
//        emit(2)
//        println("This line will not execute")
//        emit(3)
//    } finally {
//        println("Finally in numbers")
//    }
//}
//
//fun main() = runBlocking<Unit> {
//    numbers()
//        .take(2) // take only the first two
//        .collect { value -> println(value) }
//}

//-------------------------------------------------------------------------
//-------------------------------------------------------------------------

// TERMINAL FLOW OPERATORS

/*
Terminal operators on flows are suspending functions that start a collection of the flow.
The [collect] operator is the most basic one, but there are other terminal operators,
which can make it easier:

- Conversion to various collections like [toList] and [toSet].
- Operators to get the [first] value and to ensure that a flow emits a [single] value.
- Reducing a flow to a value with [reduce] and [fold].
 */

//fun main() = runBlocking<Unit> {
//    val sum = (1..5).asFlow()
//        .map { it * it }
//        .reduce { a, b -> a + b }
//
//    println("Sum Value: $sum")
//}

//-------------------------------------------------------------------------
//-------------------------------------------------------------------------

/*
Each individual collection of a flow is performed sequentially
unless special operators that operate on multiple flows are used.

The collection works directly in the coroutine that calls a terminal operator.
No new coroutines are launched by default.

Each emitted value is processed by all the intermediate operators from upstream
to downstream and is then delivered to the terminal operator after.
*/

//fun main() = runBlocking {
//    (1..5).asFlow()
//        .filter {
//            println("Filter $it")
//            it % 2 == 0
//        }
//        .map {
//            println("Map $it")
//            "Value $it"
//        }
//        .collect {
//            println("Collected $it")
//        }
//}

//-------------------------------------------------------------------------
//-------------------------------------------------------------------------

// FLOW CONTEXT

// Collection of a flow always happens in the context of the calling coroutine.
// This property of a flow is called context preservation.
// So, by default, code in the flow { ... } builder runs in the context that is
// provided by a collector of the corresponding flow

//fun log(message: String) = println("${ Thread.currentThread().name } $message")
//
//fun simpleFlow() : Flow<Int> = flow {
//    log("Started Simple Flow...")
//    for( i in 1..3 ) {
//        emit( i )
//    }
//}
//
//fun main() = runBlocking {
//    simpleFlow().collect { value -> log("Collected $value")}
//}

//-------------------------------------------------------------------------
//-------------------------------------------------------------------------

/*
// Wrong emission withContext

However, the long-running CPU-consuming code might need to be executed in
the context of [Dispatchers.Default] and UI-updating code might need to be executed
in the context of [Dispatchers.Main].

>> Usually, [withContext] is used to change the context in the code using
>> Kotlin coroutines, but code in the flow { ... } builder has to honor
>> the context preservation property and is not allowed to emit from
>> a different context.
*/

//fun simple() : Flow<Int> = flow {
//    //java.lang.IllegalStateException: Flow invariant is violated:
//    kotlinx.coroutines.withContext( Dispatchers.Default ) {
//        for( i in 1..3 ) {
//            Thread.sleep(100 )
//            emit( i )
//        }
//    }
//}
//
//fun main() = runBlocking {
//    simple().collect{ value -> println( value ) }
//}

//-------------------------------------------------------------------------
//-------------------------------------------------------------------------

// flowOnOperator

/*
The exception refers to the [flowOn] function that
shall be used to change the context of the flow emission.
*/

//fun log(message: String) = println("${ Thread.currentThread().name } $message")
//
//fun simple() : Flow<Int> = flow {
//    //java.lang.IllegalStateException: Flow invariant is violated:
////    kotlinx.coroutines.withContext( Dispatchers.Default ) {
//        for( i in 1..3 ) {
//            Thread.sleep(100 )
//            log("Emitting $i")
//            emit( i )
//        }
////    }
//
////The correct way to change the context of a flow is
//}.flowOn( Dispatchers.Default )
//
//fun main() = runBlocking {
//    simple().collect{ value -> log("Collecting $value") }
//}

/*
>> The [flowOn] operator creates another coroutine for an upstream flow when
>>      it has to change the [CoroutineDispatcher] in its context.

Notice how flow { ... } works in the background thread,
while collection happens in the main thread:

Another thing to observe here is that

>> The [flowOn] operator has changed the default sequential nature of the flow.
Now collection happens in one coroutine ("coroutine#1") and emission happens in
another coroutine ("coroutine#2") that is running in another thread concurrently
with the collecting coroutine.

*/

//-------------------------------------------------------------------------
//-------------------------------------------------------------------------


//fun simple() : Flow<Int> = flow {
//    for( i in 1..3 ) {
//        delay (100 )
//        emit( i )
//    }
//}
//
//fun main() = runBlocking {
//   val time = measureTimeMillis {
//       simple().collect{ value ->
//           delay(300)
//           println( value )
//       }
//   }
//    println("Collecting In $time ms")
//}


//-------------------------------------------------------------------------
//-------------------------------------------------------------------------

// We can use a [buffer] operator on a flow to run emitting code of
// flow concurrently with collecting code, as opposed to running them sequentially:

/*
Running different parts of a flow in different coroutines can be helpful
from the standpoint of the overall time it takes to collect the flow,
especially when long-running asynchronous operations are involved.
*/

//fun simple() : Flow<Int> = flow {
//    for( i in 1..3 ) {
//        delay (100 )
//        emit( i )
//    }
//}
//
//fun main() = runBlocking {
//    val time = measureTimeMillis {
//        simple()
//            .buffer()
//            .collect{ value ->
//            delay(300)
//            println( value )
//        }
//    }
//    println("Collecting In $time ms")
//}


//-------------------------------------------------------------------------
//-------------------------------------------------------------------------

// Conflation
/*
When a flow represents partial results of the operation or operation status updates,
it may not be necessary to process each value, but instead, only most recent ones.

In this case, the [conflate] operator can be used to skip intermediate values
when a collector is too slow to process them
*/

//fun simple() : Flow<Int> = flow {
//    for( i in 1..3 ) {
//        delay (100 )
//        emit( i )
//    }
//}
//
//fun main() = runBlocking {
//    val time = measureTimeMillis {
//        simple()
//            .conflate()
//            .collect{ value ->
//                delay(300)
//                println( value )
//            }
//    }
//    println("Collecting In $time ms")
//}


//-------------------------------------------------------------------------
//-------------------------------------------------------------------------

// Processing the latest value

/*
Conflation is one way to speed up processing when both the emitter and collector are slow.
It does it by dropping emitted values. The other way is to cancel a slow collector and
restart it every time a new value is emitted.

There is a family of xxxLatest operators that perform the same essential logic of
a xxx operator, but cancel the code in their block on a new value.
*/

//fun simple() : Flow<Int> = flow {
//    for( i in 1..3 ) {
//        delay (100 )
//        emit( i )
//    }
//}
//
//fun main() = runBlocking {
//    val time = measureTimeMillis {
//        simple()
//            .collectLatest { value ->
//                println("Collecting $value")
//                delay(300)
//                println("Done $value" )
//            }
//    }
//    println("Collecting In $time ms")
//}


//-------------------------------------------------------------------------
//-------------------------------------------------------------------------


//Composing multiple flows
//There are lots of ways to compose multiple flows.

// Zip
// Just like the [Sequence.zip] extension function in the Kotlin standard library,
// flows have a [zip] operator that combines the corresponding values of two flows:

//fun main() = runBlocking<Unit> {
////sampleStart
//    val numbers = (1..3).asFlow() // numbers 1..3
//    val strings = flowOf("one", "two", "three") // strings
//    numbers.zip( strings ) { a, b -> "$a -> $b" } // compose a single string
//        .collect { println(it) } // collect and print
////sampleEnd
//}


//-------------------------------------------------------------------------
//-------------------------------------------------------------------------

//fun main() = runBlocking<Unit> {
////sampleStart
//    val numbers = (1..3).asFlow().onEach { delay(300) } // numbers 1..3 every 300 ms
//    val strings = flowOf("one", "two", "three").onEach { delay(400) } // strings every 400 ms
//    val startTime = System.currentTimeMillis() // remember the start time
//    numbers.zip(strings) { a, b -> "$a -> $b" } // compose a single string with "zip"
//        .collect { value -> // collect and print
//            println("$value at ${System.currentTimeMillis() - startTime} ms from start")
//        }
////sampleEnd
//}

// Combine Operator
/*
When flow represents the most recent value of a variable or operation
it might be needed to perform a computation that depends on the most recent values
of the corresponding flows and to recompute it whenever any of the upstream flows
emit a value. The corresponding family of operators is called [combine].
*/

//fun main() = runBlocking<Unit> {
////sampleStart
//    val numbers = (1..3).asFlow().onEach { delay(300) } // numbers 1..3 every 300 ms
//    val strings = flowOf("one", "two", "three").onEach { delay(400) } // strings every 400 ms
//    val startTime = System.currentTimeMillis() // remember the start time
//    numbers.combine(strings) { a, b -> "$a -> $b" } // compose a single string with "zip"
//        .collect { value -> // collect and print
//            println("$value at ${System.currentTimeMillis() - startTime} ms from start")
//        }
////sampleEnd
//}

//-------------------------------------------------------------------------
//-------------------------------------------------------------------------

//Flow exceptions


// Flow collection can complete with an exception when an emitter or code
// inside the operators throw an exception.
// There are several ways to handle these exception

//Collector try and catch
//A collector can use Kotlin's try/catch block to handle exceptions:

//fun simple(): Flow<Int> = flow {
//    for (i in 1..3) {
//        println("Emitting $i")
//        emit(i) // emit next value
//    }
//}
//

// // catches any exception happening in the emitter or in any intermediate or
// // terminal operators.

//fun main() = runBlocking<Unit> {
//    try {
//        simple().collect { value ->
//            println(value)
//            check(value <= 1) { "Collected $value" }
//        }
//    } catch (e: Throwable) {
//        println("Caught $e")
//    }
//}

//-------------------------------------------------------------------------
//-------------------------------------------------------------------------

// //This exception is still caught and collection is stopped:

//fun simple(): Flow<String> = flow {
//        for (i in 1..3) {
//            println("Emitting $i")
//            emit(i) // emit next value
//        }
//    }
//    .map { value ->
//        check(value <= 1) { "Crashed on $value" }
//        "string $value"
//    }
//
//fun main() = runBlocking<Unit> {
//    try {
//        simple().collect { value -> println(value) }
//    } catch (e: Throwable) {
//        println("Caught $e")
//    }
//}

//-------------------------------------------------------------------------
//-------------------------------------------------------------------------

// Exception Transparency

/*
Flows must be transparent to exceptions and it is a violation of the exception transparency
to emit values in the flow { ... } builder from inside of a try/catch block.
This guarantees that a collector throwing an exception can always catch it
using try/catch as in the previous example.

The emitter can use a [catch] operator that preserves this exception transparency and
allows encapsulation of its exception handling. The body of the catch operator can
analyze an exception and react to it in different ways depending on which exception was caught:

- Exceptions can be rethrown using throw.
- Exceptions can be turned into emission of values using emit from the body of [catch].
- Exceptions can be ignored, logged, or processed by some other code.
*/

//fun simple(): Flow<String> =
//    flow {
//        for (i in 1..3) {
//            println("Emitting $i")
//            emit(i) // emit next value
//        }
//    }
//        .map { value ->
//            check(value <= 1) { "Crashed on $value" }
//            "string $value"
//        }
//
//fun main() = runBlocking<Unit> {
//    simple()
//        .catch { e -> emit("Caught $e") } // emit on exception
//        .collect { value -> println(value) }
//}

//-------------------------------------------------------------------------
//-------------------------------------------------------------------------

// Transparent Catch

// >> The [catch] intermediate operator, honoring exception transparency, catches
// only upstream exceptions (that is an exception from all the operators above catch,
// but not below it). If the block in collect { ... } (placed below catch) throws
// an exception then it escapes:

//fun simple(): Flow<Int> = flow {
//    for (i in 1..3) {
//        println("Emitting $i")
//        emit(i)
//    }
//}
//
//fun main() = runBlocking<Unit> {
//    simple()
//        .catch { e -> println("Caught $e") } // does not catch downstream exceptions
//        .collect { value ->
//            check(value <= 1) { "Collected $value" }
//            println(value)
//        }
//}


//-------------------------------------------------------------------------
//-------------------------------------------------------------------------

// Catching Declaratively

/*
We can combine the declarative nature of the [catch] operator with a desire to
handle all the exceptions, by moving the body of the [collect] operator into
[onEach] and putting it before the catch operator.
Collection of this flow must be triggered by a call to collect() without parameters:
*/

//fun simple(): Flow<Int> = flow {
//    for (i in 1..3) {
//        println("Emitting $i")
//        emit(i)
//    }
//}
//
//fun main() = runBlocking<Unit> {
//    simple()
//        .onEach { value ->
//            check(value <= 1) { "Collected $value" }
//            println(value)
//        }
//        .catch { e -> println("Caught $e") }
//        .collect()
//}

// we can catch all the exceptions without explicitly using a try/catch block:

//-------------------------------------------------------------------------
//-------------------------------------------------------------------------

// Declarative Handling

// For the declarative approach, flow has [onCompletion] intermediate operator
// that is invoked when the flow has completely collected

//fun simple(): Flow<Int> = (1..3).asFlow()
//
//fun main() = runBlocking<Unit> {
//    simple()
//        .onCompletion { println("Done") }
//        .collect { value -> println(value) }
//}

// >> The key advantage of [onCompletion] is a nullable Throwable parameter of
// >> the lambda that can be used to determine whether the flow collection was
// >> completed normally or exceptionally

//fun simple(): Flow<Int> = flow {
//    emit(1)
//    throw RuntimeException()
//}
//
//fun main() = runBlocking<Unit> {
//    simple()
//        .onCompletion { cause -> if (cause != null) println("Flow completed exceptionally") }
//        .catch { cause -> println("Caught Exception: $cause") }
//        .collect { value -> println(value) }
//}

// NOTE
// The [onCompletion] operator, unlike [catch], does not handle the exception.
// As we can see from the above example code, the exception still flows downstream.
// It will be delivered to further onCompletion operators and can be handled with
// a catch operator.


//-------------------------------------------------------------------------
//-------------------------------------------------------------------------

// Successful Completion
// Another difference with [catch] operator is that [onCompletion] sees all exceptions and
// receives a null exception only on successful completion of the upstream flow
// (without cancellation or failure).

//fun simple(): Flow<Int> = (1..3).asFlow()
//
//fun main() = runBlocking<Unit> {
//    simple()
//        .onCompletion { cause -> println("Flow completed with $cause") }
//        .collect { value ->
//            check(value <= 1) { "Collected $value" }
//            println(value)
//        }
//}


//-------------------------------------------------------------------------
//-------------------------------------------------------------------------

// Launching Flow
// It is easy to use flows to represent asynchronous events that are
// coming from some source. In this case, we need an analogue of the
// addEventListener function that registers a piece of code with
// a reaction for incoming events and continues further work.
//
// The [onEach] operator can serve this role.
// However, onEach is an intermediate operator.
// We also need a terminal operator to collect the flow.
// Otherwise, just calling onEach has no effect.

// If we use the [collect] terminal operator after onEach, then
// the code after it will wait until the flow is collected:

//fun events() : Flow<Int> = (1..5).asFlow().onEach{ delay(100) }
//
//fun main() = runBlocking {
//    events()
//        .onEach { event -> println("Event Received: $event ") }
//        .collect()
//
//    println("DONE!!!")
//}


//The [launchIn] terminal operator comes in handy here.
// By replacing collect with launchIn we can launch a collection of
// the flow in a separate coroutine, so that execution of further code
// immediately continues:

//fun events() : Flow<Int> = (1..5).asFlow().onEach{ delay(100) }
//
//fun main() = runBlocking {
//    events()
//        .onEach { event -> println("Event Received: $event ") }
//        .launchIn( this ) // Launching Flow In A Separate Coroutine
//    println("DONE!!!")
//}

/*
The required parameter to launchIn must specify a [CoroutineScope] in which
the coroutine to collect the flow is launched. In the above example this scope comes
from the [runBlocking] coroutine builder, so while the flow is running,
this [runBlocking] scope waits for completion of its child coroutine and
keeps the main function from returning and terminating this example.

In actual applications a scope will come from an entity with a limited lifetime.
As soon as the lifetime of this entity is terminated the corresponding scope is cancelled,
cancelling the collection of the corresponding flow. This way the pair of
onEach { ... }.launchIn(scope) works like the addEventListener.
However, there is no need for the corresponding removeEventListener function,
as cancellation and structured concurrency serve this purpose.

Note that [launchIn] also returns a [Job], which can be used to cancel the
corresponding flow collection coroutine only without cancelling the whole scope or
to join it.
*/

//-------------------------------------------------------------------------
//-------------------------------------------------------------------------

// Flow Cancellation Checks
// For convenience, the flow builder performs additional [ensureActive] checks
// for cancellation on each emitted value. It means that a busy loop emitting from
// a flow { ... } is cancellable:
//

//fun foo(): Flow<Int> = flow {
//    for (i in 1..5) {
//        println("Emitting $i")
//        emit(i)
//    }
//}
//
//fun main() = runBlocking<Unit> {
//    foo().collect { value ->
//        if (value == 3) cancel()
//        println(value)
//    }
//}


// However, most other flow operators do not do additional cancellation checks on
// their own for performance reasons. For example, if you use [IntRange.asFlow]
// extension to write the same busy loop and don't suspend anywhere, then there
// are no checks for cancellation:

//fun main() = runBlocking<Unit> {
//    (1..5).asFlow().collect { value ->
//        if (value == 3) cancel()
//        println(value)
//    }
//}

//-------------------------------------------------------------------------
//-------------------------------------------------------------------------

// Making Busy Flow Cancellable

// In the case where you have a busy loop with coroutines you must explicitly
// check for cancellation. You can add .onEach { currentCoroutineContext().ensureActive() },
// but there is a ready-to-use [cancellable] operator provided to do that:

//fun main() = runBlocking<Unit> {
//    (1..5).asFlow().cancellable().collect { value ->
//        if (value == 3) cancel()
//        println(value)
//    }
//}

//fun main() = runBlocking<Unit> {
//    (1..5).asFlow().take(2).collect { value ->
//        if (value == 3) cancel()
//        println(value)
//    }
//}

//-------------------------------------------------------------------------
// CHANNELS
//-------------------------------------------------------------------------

// send And receive Are Suspending Function

//fun main() = runBlocking {
//    val channel = Channel<Int>()
//
//    launch {
//        for( x in 1..5 ) channel.send(x * x )
//    }
//    repeat( 5 ) { println( channel.receive() ) }
//}

//-------------------------------------------------------------------------
//-------------------------------------------------------------------------

/*
Closing and iteration over channels
Unlike a queue, a channel can be closed to indicate that no more elements are coming.
On the receiver side it is convenient to use a regular for loop to receive elements
from the channel.

Conceptually, a close is like sending a special close token to the channel.
The iteration stops as soon as this close token is received,
so there is a guarantee that all previously sent elements
before the close are received:
*/

////           Consumer Coroutine
//fun main() = runBlocking {
//    val channel = Channel<Int>()
//
//    //       Producer Coroutine
//    launch {
//        for( x in 1..5 ) channel.send(x * x )
//        channel.close()
//    }
//    for ( y in channel ) { println( y ) }
//    println("DONE!!")
//}


//-------------------------------------------------------------------------
//-------------------------------------------------------------------------

//// Producer Coroutine
//fun CoroutineScope.produceSquares() : ReceiveChannel<Int> = produce {
//    for( x in 1..10) send( x * x)
//}
//
////          Consumer Coroutine
//fun main() = runBlocking() {
//    val squares = produceSquares()
//    squares.consumeEach { println( it ) }
//    println("DONE")
//}

//-------------------------------------------------------------------------
//-------------------------------------------------------------------------

// Producer Coroutine

//fun CoroutineScope.produceNumbers() = produce<Int> {
//    var x = 1
//    while( true) send( x++ )
//}
//
//fun CoroutineScope.square( numbers:  ReceiveChannel<Int> ) : ReceiveChannel<Int> = produce {
//    for( x in numbers ) send( x * x)
//}
//
////          Consumer Coroutine
//fun main() = runBlocking() {
//    val numbers = produceNumbers()
//    val squares = square( numbers )
//
//    for ( square in squares ) { println( square ) }
//    println("DONE")
//    coroutineContext.cancelChildren()
//}


//-------------------------------------------------------------------------
//-------------------------------------------------------------------------

//fun main() = runBlocking {
//    var numbers = numbersFrom(2)
//    repeat(10) {
//        val prime = numbers.receive()
//        println(prime)
//        numbers = filter(numbers, prime)
//    }
//    coroutineContext.cancelChildren() // cancel all children to let main finish
//}
//
//fun CoroutineScope.numbersFrom(start: Int) = produce<Int> {
//    var x = start
//    while (true) send(x++) // infinite stream of integers from start
//}
//
//fun CoroutineScope.filter(numbers: ReceiveChannel<Int>, prime: Int) = produce<Int> {
//    for (x in numbers) if (x % prime != 0) send(x)
//}

/*
Note that you can build the same pipeline using iterator coroutine builder
from the standard library. Replace produce with iterator, send with yield,
receive with next, ReceiveChannel with Iterator, and get rid of the coroutine scope.
You will not need runBlocking either. However, the benefit of a pipeline that
uses channels as shown above is that it can actually use multiple CPU cores
if you run it in [Dispatchers.Default] context.

In practice, pipelines do involve some other suspending invocations
(like asynchronous calls to remote services) and these pipelines cannot be built
using sequence/iterator, because they do not allow arbitrary suspension,
unlike produce, which is fully asynchronous.
*/

//-------------------------------------------------------------------------
//-------------------------------------------------------------------------

// FAN OUT

// 1 Producer and 5 Consumer Coroutines

fun CoroutineScope.produceNumbers() = produce<Int> {
    var x = 1
    while (true) {
        send(x++)
        delay( 100 )
    } // infinite stream of integers from start
}

fun CoroutineScope.launchConsumers(id: Int, channel: ReceiveChannel<Int> ) = launch {
    for ( number in channel ) println("Consumer #$id Received $number")
}

fun main() = runBlocking {
    var producer = produceNumbers()
    repeat(5) { launchConsumers(it, producer) }
    delay( 1000 )
    producer.cancel()
}


//-------------------------------------------------------------------------
//-------------------------------------------------------------------------


//-------------------------------------------------------------------------
//-------------------------------------------------------------------------


//-------------------------------------------------------------------------
//-------------------------------------------------------------------------


//-------------------------------------------------------------------------
//-------------------------------------------------------------------------


//-------------------------------------------------------------------------
//-------------------------------------------------------------------------


//-------------------------------------------------------------------------
//-------------------------------------------------------------------------


//-------------------------------------------------------------------------
//-------------------------------------------------------------------------

