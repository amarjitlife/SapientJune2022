
package learnKotlin;

//_______________________________________________________________

data class Point( val x: Int, val y : Int )  {
	operator fun plus( other: Point ) : Point {
		return Point( x + other.x, y + other.y )
	}
}

operator fun Point.minus( other: Point ) : Point {
	return Point( this.x - other.x, this.y - other.y )
}

operator fun Point.times( scale: Int ) : Point {
	return Point( x * scale, y *scale )
}

fun playWithPoint() {
	val point1 = Point(100, 200)
	val point2 = Point(10, 20)

	val point3 = Point( point1.x + point2.x, point1.y + point2.y )
	println( point1 )
	println( point2 )
	println( point3 )

	// Using Overloaded + Operator
	val point4 = point1 + point2 	// Compiler Will Generate point1.plus( point2 )
	println( point4 )

	val point5 = point1 - point2 	// Compiler Will Generate point1.minus( point2 )
	println( point5 )

	val point6 = point1 * 3 		// Compiler Will Generate point1.times( 3 )
	val point7 = point2 * 10        // Compiler Will Generate point2.times( 10 )
	println( point6 )
	println( point7 )
}

//_______________________________________________________________
//_______________________________________________________________
//_______________________________________________________________
//_______________________________________________________________
//_______________________________________________________________
// Experiment Following Code, MOMENT DONE >>> RAISE YOUR HANDS!!!

fun main() {
	println("\nFunction : playWithPoint")
	playWithPoint()

	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")	
	// println("\nFunction : ")
	// println("\nFunction : ")
}

/*
kotlinc KotlinOperatorOverloading.kt -include-runtime -d operators.jar
java -jar operators.jar 
*/