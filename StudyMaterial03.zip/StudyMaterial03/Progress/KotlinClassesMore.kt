/*
kotlinc KotlinClassesMore.kt -include-runtime -d classesMore.jar
java -jar classesMore.jar 
*/

package learnKotlin;

					// Primary Constructor
data class Subject( val name: String, val grade: Char,  val points: Double, var credits: Double )

				// Primary Constructor
data class Game( val name : String, var grade : Char, var points: Double )

			// Primary Constructor
// class Person( var firstName: String, var lastName: String ) {
open class Person constructor( var firstName: String, var lastName: String ) {
	fun fullName(): String {
		return "$firstName $lastName"
	}
}

fun playWithPerson() {
	val alice = Person("Alice", "Carol")
	println( alice.fullName() ) 

	val martin = Person("Matrin", "Gupta")
	println( martin.fullName() ) 
}

//_______________________________________________________________

// New Things...
// 		1. Parent Constructor Called With Arguments
//		2. MutableList<Subject>
//		3. Student Constructor Defines Constructor Signature Only
//				Doesn't Define New Properies
//				Doesn't Redefine Properies Form Parent Type i.e. Person
//				Resuing Person Properties
//				Propeties Initialiation Is Delegated To Parent Constructor

// error: 'firstName' hides member of supertype 'Person' and needs 'override' modifier
// error: 'lastName' hides member of supertype 'Person' and needs 'override' modifier
// class Student( val firstName : String, val lastName: String ) : Person( firstName, lastName ) {

open class Student( firstName : String, lastName: String ) : Person( firstName, lastName ) {
 	val passedSubjects: MutableList<Subject> = mutableListOf<Subject>()
 	val failedSubjects: MutableList<Subject> = mutableListOf<Subject>()

 	fun recordGrades( subject : Subject ) {
 		if ( subject.grade == 'F' ) {
 			failedSubjects.add( subject )
 		} else {
 			passedSubjects.add( subject )
 		}
 	}

 	open fun printGrades() {
 		for ( subject in passedSubjects ) {
 			println("\t $subject")
 		}

 		for ( subject in failedSubjects ) {
 			println("\t $subject")
 		}
 	}	
}


// data class Subject( val name: String, val grade: Char,  val points: Double, var credits: Double )

fun playWithStudent() {

	val martin 	= Student("Martin", "Gupta")
	val pravin 	= Student("Pravin", "Bhole")

	println( martin )
	println( pravin )

	val alice 	= Student("Alice", "Carols")
	val gabbar  = Student("Gabbar", "Singh")

	val aliceEnglish = Subject( name = "English", grade = 'A', points = 9.0, credits = 3.0 )
	val aliceDance 	= Subject( name = "Dance", grade = 'B', points = 7.0, credits = 2.0 )
	val aliceKotlin = Subject( name = "Koltin", grade = 'C', points = 6.0, credits = 3.0 )

	alice.recordGrades( aliceEnglish )
	alice.recordGrades( aliceDance )
	alice.recordGrades( aliceKotlin )

	val gabbarDecoit = Subject( name = "Decoit", grade = 'A', points = 9.0, credits = 3.0 )
	val gabbarShooting 	= Subject( name = "Shooting", grade = 'B', points = 8.0, credits = 3.0 )
	val gabbarLooting = Subject( name = "Looting", grade = 'D', points = 5.0, credits = 0.0 )
	
	gabbar.recordGrades( gabbarDecoit )
	gabbar.recordGrades( gabbarShooting )
	gabbar.recordGrades( gabbarLooting )

	alice.printGrades()
	gabbar.printGrades()
}


//_______________________________________________________________

// data class Game( val name : String, var grade : Char, var points: Double )

class StudentAthlete( firstName: String, lastName: String ) : Student( firstName, lastName ) {
	val gamesPlayed = mutableListOf<Game>()

	fun recordGames( game: Game ) {
		gamesPlayed.add( game )
	}

	override fun printGrades() {
		super.printGrades()

		for ( game in gamesPlayed ) {
			println("\t $game")
		}
	}
}

fun playWithStudentAtheletes() {
	val martin 	= StudentAthlete("Martin", "Gupta")
	val pravin 	= StudentAthlete("Pravin", "Bhole")

	// data class Game( val name : String, var grade : Char, var points: Double )
	val martinChess 	= Game( name = "Chess", grade = 'A', points = 9.0 )
	val martinBadminton = Game( name = "Badminton", grade = 'D', points = 5.0 )

	martin.recordGames( martinChess )
	martin.recordGames( martinBadminton )

	val pravinChess 	= Game( name = "Chess", grade = 'B', points = 8.0 )
	val pravinKabbadi 	= Game( name = "Kabbadi", grade = 'A', points = 10.0 )
	
	pravin.recordGames( pravinChess )
	pravin.recordGames( pravinKabbadi )

	martin.printGrades()
	pravin.printGrades()
}

//_______________________________________________________________
//_______________________________________________________________
//_______________________________________________________________
//_______________________________________________________________
// Experiment Following Code, MOMENT DONE >>> RAISE YOUR HANDS!!!

fun main() {	
	println("\nFunction : playWithPerson")
	playWithPerson()

	println("\nFunction : playWithStudent")
	playWithStudent()

	println("\nFunction : playWithStudentAtheletes")
	playWithStudentAtheletes()

	// println("\nFunction : ")	
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")	
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")	
}
