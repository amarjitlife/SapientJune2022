
package learnJava;

import java.lang.reflect.Method;
import java.lang.reflect.ParameterizedType;
import java.lang.reflect.Type;
import java.lang.reflect.TypeVariable;
import java.lang.reflect.WildcardType;
import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Arrays;
import java.lang.reflect.Array;

// import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
// import java.util.Arrays;
import java.util.Scanner;



// Types In Java Have A Type
//      i.e. All Types In Java Are of Class Type

// class A {

// }

// class ClassA {
//   public static void playWithClassA() {
//      try {
       
//         Class cls = Class.forName("A");
       
//         boolean b1 = cls.isInstance( new Integer(37) );
//         System.out.println(b1);
        
//         boolean b2 = cls.isInstance(new A());
//         System.out.println(b2);

//      } catch (Throwable e) {
//         System.err.println(e);
//      }
//   }
// }

class Person {
    private String name;
    private int age;
}

class PersonDemo {

    public static void playWithFieldNamesAtRuntime() {
        Object personObject = new Person();

        Class classObject = personObject.getClass();

        Field[] fields = classObject.getDeclaredFields();
        // Field[] fields = person.getClass().getDeclaredFields();

        List<String> actualFieldNames = getFieldNames(fields);
        System.out.println( actualFieldNames );
    }

    private static List<String> getFieldNames(Field[] fields) {
        List<String> fieldNames = new ArrayList<>();
        for (Field field : fields) {
            fieldNames.add(field.getName());
            System.out.println( field );        
        }
    
        return fieldNames;
    }
}


class MethodPrinter {

    public static void playWithClassMethods() throws ReflectiveOperationException {
        System.out.print("Class Name: ");
        Scanner in = new Scanner(System.in);
        String className = in.nextLine();

        Class<?> classObject = Class.forName( className );

        while (classObject != null) {
            for (Method m : classObject.getDeclaredMethods()) { 
                System.out.println(
                    Modifier.toString(m.getModifiers()) + " " +
                    m.getReturnType().getCanonicalName() + " " +
                    m.getName() +
                    Arrays.toString( m.getParameters() ));                    
            }
            classObject = classObject.getSuperclass();
        }
    }
}

class ArrayReflection {

    public static Object[] badCopyOf(Object[] array, int newLength) { // Not useful
        Object[] newArray = new Object[newLength];
        for (int i = 0; i < Math.min(array.length, newLength); i++)
            newArray[i] = array[i];
        return newArray;
    }
    
    public static Object goodCopyOf(Object array, int newLength) {
        Class<?> cl = array.getClass();
        
        if (!cl.isArray()) return null;
        Class<?> componentType = cl.getComponentType();
        
        int length = Array.getLength(array);

        Object newArray = Array.newInstance(componentType, newLength);
        
        for (int i = 0; i < Math.min(length, newLength); i++)
            Array.set(newArray, i, Array.get(array,  i));

        return newArray;
    }
    
    public static void playWithArrayRelections() {
        int[] primes = { 2, 3, 5, 7, 11 };
        primes = (int[]) goodCopyOf(primes, 10);
        System.out.println(Arrays.toString(primes));
    }
}

class JavaReflections {
    public static void main( String[] args ) {
        System.out.println("\n\nFunction : PersonDemo.playWithFieldNamesAtRuntime\n\n");
        PersonDemo.playWithFieldNamesAtRuntime();

        System.out.println("\n\nFunction : MethodPrinter.playWithClassMethods\n\n");

        try {  MethodPrinter.playWithClassMethods(); } catch( Exception e) { }

        System.out.println("\n\nFunction :ArrayReflection.playWithArrayRelections \n\n");
        ArrayReflection.playWithArrayRelections();

        // System.out.println("\n\nFunction : \n\n");
        // System.out.println("\n\nFunction : \n\n");
        // System.out.println("\n\nFunction : \n\n");
    }
}


/*
javac JavaReflections.java -d ClassFiles/
java -cp ClassFiles/ learnJava.JavaReflections
*/
