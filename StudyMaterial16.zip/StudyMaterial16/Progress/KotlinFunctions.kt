
/*
kotlinc KotlinFunctions.kt -include-runtime -d functions.jar
java -jar functions.jar 
*/

package learnKotlin;

fun playWithKotlinCollections() {
	val set 	= hashSetOf(10, 20, 30, 400)
	val list	= arrayListOf(10, 20, 30, 400)
	val map 	= hashMapOf( 1 to "One", 7 to "Seven", 10 to "Ten" )

	println( set.javaClass ) 	// class java.util.HashSet
	println( list.javaClass ) 	// class java.util.ArrayList
	println( map.javaClass ) 	// class java.util.HashMaps

	val strings = listOf( "First", "Second", "Third", "Last Value" )
	println( strings )
	println( strings.last() )
	println( strings.javaClass ) // class java.util.Arrays$ArrayList

	val numbers = setOf(10, 10, 20, 30, 40)
	println( numbers.javaClass ) // class java.util.LinkedHashSet
	println( numbers.maxOrNull() )
}

// Function : playWithKotlinCollections
// [First, Second, Third, Last Value]
// Last Value
// 40

//_______________________________________________________________
// Experiment Following Code, MOMENT DONE >>> RAISE YOUR HANDS!!!

// T Is Type Place Holders
fun <T> joinToString(
	collection: Collection<T>,
	separator: String,
	prefix: String,
	postfix: String
) : String {

	val result = StringBuilder( prefix ) // Java StringBuilder

	// collections.withIndex() Will Generate List Of Tuples
	//		Where Tuple (index, Value), index belongs to [ 0, length( collection ) - 1 ]
	for( (index, element) in collection.withIndex() ) {
		if ( index > 0 ) result.append( separator )
		result.append( element )
	}

	result.append( postfix )
	return result.toString()
}

fun playWithJoinToString() {
	// Type Inferencing and Binding Happening
	val list = listOf( 10, 20, 30, 40, 50 ) // ArrayList<Integer>
	println( joinToString( list, " ; ", "( ", " )" ) )
	println( joinToString( list, " : ", "[ ", " ]" ) )

	// Type Inferencing and Binding Happening
	val names = listOf("Alice", "Martin", "Chandan", "Ashish" ) // ArrayList<String>
	println( joinToString( names, " ; ", "( ", " )" ) )
	println( joinToString( names, " : ", "[ ", " ]" ) )	
}

// Function : playWithJoinToString
// ( 10 ; 20 ; 30 ; 40 ; 50 )
// [ 10 : 20 : 30 : 40 : 50 ]
// ( Alice ; Martin ; Chandan ; Ashish )
// [ Alice : Martin : Chandan : Ashish ]

// Compiler Will Generate Following Code After Substiting T Placeholder

// fun <Integer> joinToStringInteger(
// 	collection: Collection<Integer>,
// 	separator: String,
// 	prefix: String,
// 	postfix: String
// ) : String {

// 	val result = StringBuilder( prefix )

// 	// collections.withIndex() Will Generate List Of Tuples
// 	//		Where Tuple (index, Value), index belongs to [ 0, length( collection ) - 1 ]
// 	for( (index, element) in collection.withIndex() ) {
// 		if ( index > 0 ) result.append( separator )
// 		result.append( element )
// 	}

// 	result.append( postfix )
// 	return result.toString()
// }

// fun <String> joinToStringString(
// 	collection: Collection<String>,
// 	separator: String,
// 	prefix: String,
// 	postfix: String
// ) : String {

// 	val result = StringBuilder( prefix )

// 	// collections.withIndex() Will Generate List Of Tuples
// 	//		Where Tuple (index, Value), index belongs to [ 0, length( collection ) - 1 ]
// 	for( (index, element) in collection.withIndex() ) {
// 		if ( index > 0 ) result.append( separator )
// 		result.append( element )
// 	}

// 	result.append( postfix )
// 	return result.toString()
// }


//_______________________________________________________________
// Experiment Following Code, MOMENT DONE >>> RAISE YOUR HANDS!!!

fun lastChar( string : String ) : Char {
	return string.get( string.length - 1 ) 
}

// Adding Functionality To Existing Type
//		Using Extention Functions

// Extension Function On Type String
fun String.lastCharacter() : Char {
	return this.get( this.length - 1 ) 
}


// error: platform declaration clash: The following declarations 
//	have the same JVM signature (lastChar(Ljava/lang/String;)C):
//     fun lastChar(string: String): Char defined in learnKotlin
//     fun String.lastChar(): Char defined in learnKotlin
// fun lastChar( string : String ) : Char {

// fun String.lastChar() : Char {
// 	return this.get( this.length - 1 ) 
// }

fun playWithLastCharacter() {
	println( lastChar("Hello World") )
	println( lastChar("Good Morning!") )

	println( "Hello World".lastCharacter() )
	println( "Good Morning!".lastCharacter() )
}

//_______________________________________________________________
// Experiment Following Code, MOMENT DONE >>> RAISE YOUR HANDS!!!

val String.lastChar : Char 
	get() = get( length - 1 ) 


var StringBuilder.lastChar : Char 
	get() = get( length - 1 ) 
	set( value : Char ) {
		this.setCharAt( length -1 , value )
	}

fun playWithLastCharacterProperties() {
	println( "Hello World".lastChar )
	println( "Good Morning!".lastChar )

	val sb = StringBuilder("Good Afternoon!")
	println( sb )
	println( sb.lastChar )
	
	sb.lastChar = '#'
	println( sb )
	println( sb.lastChar )
}

//_______________________________________________________________
// Experiment Following Code, MOMENT DONE >>> RAISE YOUR HANDS!!!


fun <T> Collection<T>.joinToStringExtension(
	separator: String,
	prefix: String,
	postfix: String
) : String {

	val result = StringBuilder( prefix ) // Java StringBuilder
	// collections.withIndex() Will Generate List Of Tuples
	//		Where Tuple (index, Value), index belongs to [ 0, length( collection ) - 1 ]
	for( (index, element) in this.withIndex() ) {
		if ( index > 0 ) result.append( separator )
		result.append( element )
	}

	result.append( postfix )
	return result.toString()
}

fun playWithJoinToStringExtension() {
	// Type Inferencing and Binding Happening
	val list = listOf( 10, 20, 30, 40, 50 ) // ArrayList<Integer>
	println( list.joinToStringExtension( " ; ", "( ", " )" ) )
	println( list.joinToStringExtension( " : ", "[ ", " ]" ) )

	// Type Inferencing and Binding Happening
	val names = listOf("Alice", "Martin", "Chandan", "Ashish" ) // ArrayList<String>
	println( names.joinToStringExtension( " ; ", "( ", " )" ) )
	println( names.joinToStringExtension( " : ", "[ ", " ]" ) )	
}

//_______________________________________________________________
// Experiment Following Code, MOMENT DONE >>> RAISE YOUR HANDS!!!

// Polymorphic Function
// 		Function With Default Arguments
fun <T> Collection<T>.joinToStringFinal(
	separator: String = ", ",
	prefix: String = "",
	postfix: String = ""
) : String {

	val result = StringBuilder( prefix ) // Java StringBuilder
	// collections.withIndex() Will Generate List Of Tuples
	//		Where Tuple (index, Value), index belongs to [ 0, length( collection ) - 1 ]
	for( (index, element) in this.withIndex() ) {
		if ( index > 0 ) result.append( separator )
		result.append( element )
	}

	result.append( postfix )
	return result.toString()
}

fun playWithJoinToStringFinal() {
	// Type Inferencing and Binding Happening
	val list = listOf( 10, 20, 30, 40, 50 ) // ArrayList<Integer>
	println( list.joinToStringFinal( " ; ", "( ", " )" ) )
	println( list.joinToStringFinal( ) )
	println( list.joinToStringFinal( " : ") )
	println( list.joinToStringFinal( " : ", "[ " ) )
	println( list.joinToStringFinal( " : ", "[ ", " ]" ) )

	// Type Inferencing and Binding Happening
	val names = listOf("Alice", "Martin", "Chandan", "Ashish" ) // ArrayList<String>
	println( names.joinToStringFinal( " ; ", "( ", " )" ) )
	println( names.joinToStringFinal(  ) )	
	println( names.joinToStringFinal( " : " ) )	
	println( names.joinToStringFinal( " : ", "[ " ) )	
	println( names.joinToStringFinal( " : ", "[ ", " ]" ) )	
}

//_______________________________________________________________
// API Mapping Files
//		Create Your Own APIs With Your Own Conventions
//		Hide Third Party Libaries/API
//		It's Will Create Loose Coupling

fun  Collection<String>.join(
	separator: String = ", ",
	prefix: String = "",
	postfix: String = ""
) = joinToStringFinal( separator, prefix, postfix )


fun playWithJoinAPI() {
	// Type Inferencing and Binding Happening
	val names = listOf("Alice", "Martin", "Chandan", "Ashish" ) // ArrayList<String>
	println( names.join( " ; ", "( ", " )" ) )
	println( names.join(  ) )	
	println( names.join( " : " ) )	
	println( names.join( " : ", "[ " ) )	
	println( names.join( " : ", "[ ", " ]" ) )	
}

//_______________________________________________________________

class User(val id: Int, val name: String, val address: String) 

fun saveUser( user: User ) {
	// Validation Logic
	if ( user.name.isEmpty() ) {
		throw IllegalArgumentException("Can't Save User: ${user.id} - Empty Name...")
	}

	if ( user.address.isEmpty() ) {
		throw IllegalArgumentException("Can't Save User: ${user.id} - Empty Address...")
	}

	// Save User To The Database...
		// Logic To Save The User Data...

	println("Saving User: ${user.id}, ${user.name}")
}

fun playWithSaveUser() {
	var alice 	= User(100, "Alice", "London, Palace Street")
	var martin 	= User(101, "Martin", "Bangalore, M G Road")

	saveUser(alice)
	saveUser(martin)
}

//_______________________________________________________________
// Experiment Following Code, MOMENT DONE >>> RAISE YOUR HANDS!!!

// class User(val id: Int, val name: String, val address: String) 

// class saveUserAgain( user: User ) {  
fun saveUserAgain( user: User ) { // Enclosing Context
	// Very Specific Validation Logic 
	// Local Functions
	//		Function Defined Inside Function
	val somethingLocalValue = 1000

	fun validate(user: User, value: String, fieldName: String ) { // Enclosed Context
		// Enclosed Context Can Access Enclosing Context Data
		// Local Function Can Access Data From Enclosing Function
		println( somethingLocalValue )

		if ( value.isEmpty() ) {
			throw IllegalArgumentException("Can't Save User: ${user.id} - Empty $fieldName...")
		}
	}

	validate( user, user.name, "Name" )
	validate( user, user.address, "Address" )

	// Save User To The Database...
		// Logic To Save The User Data...
	println("Saving User: ${user.id}, ${user.name}")
}

fun playWithSaveUserAgain() {
	var alice 	= User(100, "Alice", "London, Palace Street")
	var martin 	= User(101, "Martin", "Bangalore, M G Road")

	saveUserAgain(alice)
	saveUserAgain(martin)
}

//_______________________________________________________________
// Experiment Following Code, MOMENT DONE >>> RAISE YOUR HANDS!!!

// class User(val id: Int, val name: String, val address: String) 

fun User.save( ) {
	// Very Specific Validation Logic 
	// Local Functions
	//		Function Defined Inside Function
	fun validate( value: String, fieldName: String ) {
		if ( value.isEmpty() ) {
			throw IllegalArgumentException("Can't Save User: ${ this.id } - Empty $fieldName...")
		}
	}

	validate( this.name, "Name" )
	validate( this.address, "Address" )

	// Save User To The Database...
		// Logic To Save The User Data...
	println("Saving User: ${ this.id }, ${ this.name }")
}

fun playWithSaveUserExtension() {
	var alice 	= User(100, "Alice", "London, Palace Street")
	var martin 	= User(101, "Martin", "Bangalore, M G Road")

	alice.save()
	martin.save()
}

//_______________________________________________________________
//_______________________________________________________________
//_______________________________________________________________
//_______________________________________________________________
// Experiment Following Code, MOMENT DONE >>> RAISE YOUR HANDS!!!

fun main() {
	println("\nFunction : playWithKotlinCollections")
	playWithKotlinCollections()

	println("\nFunction : playWithJoinToString")
	playWithJoinToString()

	println("\nFunction : playWithLastCharacter")
	playWithLastCharacter()

	println("\nFunction : playWithJoinToStringExtension")
	playWithJoinToStringExtension()

	println("\nFunction : playWithJoinToStringFinal")
	playWithJoinToStringFinal()

	println("\nFunction : playWithJoinAPI")
	playWithJoinAPI()

	println("\nFunction : playWithSaveUser")
	playWithSaveUser()

	println("\nFunction : playWithSaveUserAgain")
	playWithSaveUserAgain()

	println("\nFunction : playWithSaveUserExtension")
	playWithSaveUserExtension()

	println("\nFunction : playWithLastCharacterProperties")
	playWithLastCharacterProperties()

	// println("\nFunction : ")	
	// println("\nFunction : ")	
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")	
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")	
}

/*
kotlinc KotlinFunctions.kt -include-runtime -d functions.jar
java -jar functions.jar 
*/
