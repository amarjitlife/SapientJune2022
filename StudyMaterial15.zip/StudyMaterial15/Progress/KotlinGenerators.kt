
package learnKotlin

fun vowelsGenerators() = sequence {
    // Continuation 01
    println("Continuation 01")
    yield("a")

    // Continuation 02
    println("Continuation 02 : Hello!")    
    println("Continuation 02 : Good Morning!!!")
    yield("e")

    // Continuation 03
    println("Continuation 03 : A")
    println("Continuation 03 : B")
    println("Continuation 03 : C")
    println("Continuation 03 : D")
    yield("i")

    // Continuation 04
    println("Continuation 04")
    yield("o")

    // Continuation 05
    println("Continuation 05 : A")
    println("Continuation 05 : B")
    println("Continuation 05 : C")
    yield("u")
}

fun playWithVowelsGenerators() {
    // Generator Object
    val vowelsGen = vowelsGenerators()

    // val client = Yield();
    // val vowelIterator = client.vowels().iterator()
    
    val vowelIterator = vowelsGen.iterator()

    // Generating Values On Demand
    while (vowelIterator.hasNext()) {
        println(vowelIterator.next())
    }    
}

fun fibonacciGenerator() = sequence {
    var terms = Pair(0, 1)
    while (true) {
        yield(terms.first)
        terms = Pair(terms.second, terms.first + terms.second)
    }
}

fun playWithFibonacciGenerator() {
    val fibonacciGen = fibonacciGenerator()
    val fibonacciIterator = fibonacciGen.iterator()

    var count = 0 
    while( count <= 10 ) {
        // val fib = fibonacciIterator.next()
        println( fibonacciIterator.next() )
        count++
    }
}

fun main() {

    println("\nFunction : playWithVowelsGenerator")
    playWithVowelsGenerator()

    println("\nFunction : playWithFibonacciGenerator") 
    playWithFibonacciGenerator()

    // println("\nFunction : ")
    // println("\nFunction : ")
    // println("\nFunction : ")
    // println("\nFunction : ")
    // println("\nFunction : ") 
}


/*
kotlinc KotlinGenerators.kt -include-runtime -d generators.jar
java -jar generators.jar 
*/
