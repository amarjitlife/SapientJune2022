
package learnKotlin;

import java.util.Random

//_______________________________________________________________


// Polymorphic Function
// 		Function With Default Arguments
fun <T> Collection<T>.joinToStringFinal(
	separator: String = ", ",
	prefix: String = "",
	postfix: String = ""
) : String {

	val result = StringBuilder( prefix ) // Java StringBuilder
	// collections.withIndex() Will Generate List Of Tuples
	//		Where Tuple (index, Value), index belongs to [ 0, length( collection ) - 1 ]
	for( (index, element) in this.withIndex() ) {
		if ( index > 0 ) result.append( separator )
		result.append( element )
	}

	result.append( postfix )
	return result.toString()
}

fun playWithJoinToStringFinal() {
	// Type Inferencing and Binding Happening
	val list = listOf( 10, 20, 30, 40, 50 ) // ArrayList<Integer>
	println( list.joinToStringFinal( " ; ", "( ", " )" ) )
	println( list.joinToStringFinal( ) )
	println( list.joinToStringFinal( " : ") )
	println( list.joinToStringFinal( " : ", "[ " ) )
	println( list.joinToStringFinal( " : ", "[ ", " ]" ) )

	// Type Inferencing and Binding Happening
	val names = listOf("Alice", "Martin", "Chandan", "Ashish" ) // ArrayList<String>
	println( names.joinToStringFinal( " ; ", "( ", " )" ) )
	println( names.joinToStringFinal(  ) )	
	println( names.joinToStringFinal( " : " ) )	
	println( names.joinToStringFinal( " : ", "[ " ) )	
	println( names.joinToStringFinal( " : ", "[ ", " ]" ) )	
}

//_______________________________________________________________


fun <T> T.applyThenReturn( lambdaExprn : (T) -> Unit ) : T {
    lambdaExprn( this )
    return this
}

// Lambda With Receiver 
// 										// T Place Holder Act As Receiver For Lambda
fun <T> T.applyThenReturnAgain( lambdaExprnWithReceier : T.() -> Unit ): T {
    lambdaExprnWithReceier() // or this.lambdaExprnWithReceier()
    return this
}

fun playWithExtensionFunction() {
	var name: String

	name = "Baeldung".applyThenReturn { n -> println(n.uppercase()) }
	println( name )

	name = "Baeldung".applyThenReturn { println( it.uppercase() ) }
	println( name )

	var nameAgain = "Baeldung".applyThenReturnAgain { 
		println( uppercase() ) 
	}
	println( nameAgain )
}

//_______________________________________________________________


// E Is Type Place Holder
// MutableStack Is Generic Type i.e. Template

//	Generics Are Templates Programming
//		In Mathematics It's Callled Parameterised Types
//		Write Code To Generate Code
//		Compile Time Polymorphism

class MutableStack<E>( vararg items: E ) {              // 1
  private val elements = items.toMutableList()
  fun push(element: E) = elements.add(element)        // 2
  fun peek(): E = elements.last()                     // 3
  fun pop(): E = elements.removeAt(elements.size - 1)
  fun isEmpty() = elements.isEmpty()
  fun size() = elements.size
  override fun toString() = "MutableStack(${elements.joinToString()})"
}

// // Compiler Generatged Code On Demand Basis
// //		Based On The Usage
// class MutableStack<Int>( vararg items: Int ) {              // 1
//   private val elements = items.toMutableList()
//   fun push(element: Int) = elements.add(element)        // 2
//   fun peek(): Int = elements.last()                     // 3
//   fun pop(): Int = elements.removeAt(elements.size - 1)
//   fun isEmpty() = elements.isEmpty()
//   fun size() = elements.size
//   override fun toString() = "MutableStack(${elements.joinToString()})"
// }

// // Compiler Generatged Code On Demand Basis
// //		Based On The Usage
// class MutableStack<String>( vararg items: String ) {              // 1
//   private val elements = items.toMutableList()
//   fun push(element: String) = elements.add(element)        // 2
//   fun peek(): String = elements.last()                     // 3
//   fun pop(): String = elements.removeAt(elements.size - 1)
//   fun isEmpty() = elements.isEmpty()
//   fun size() = elements.size
//   override fun toString() = "MutableStack(${elements.joinToString()})"
// }

fun playWithMutableStack() {
	// Type Inferred and Substitued At Type Place Holder <E> At Compile Time
	val stackInts = MutableStack<Int>( 10, 20, 30 )
	println( stackInts.size() ) 
	stackInts.push( 100 )
	stackInts.push( 200 )
	println( stackInts.size() ) 
	println( stackInts.pop() )	

	val stackStrings = MutableStack<String>( "Ding", "Dong" )
	println( stackStrings.size() ) 
	stackStrings.push( "Ting" )
	stackStrings.push( "Tong" )
	println( stackStrings.size() ) 
	println( stackStrings.pop() )	
}

//_______________________________________________________________
// Experiment Following Code, MOMENT DONE >>> RAISE YOUR HANDS!!!

class Temperature(var tempInCelsius: Float)

// Extension Properties 

var Temperature.tempInFahrenheit: Float
    get() = (tempInCelsius * 9 / 5) + 32
    set(value) {
        tempInCelsius = (value - 32) * 5 / 9
    }

fun playWithExtensionProperties() {
    val temp = Temperature(32f)
	println(temp.tempInFahrenheit)

	temp.tempInFahrenheit = 90f
	println(temp.tempInCelsius)
}

//_______________________________________________________________
// Experiment Following Code, MOMENT DONE >>> RAISE YOUR HANDS!!!

val String.lastChar : Char 
	get() = get( length - 1 ) 


var StringBuilder.lastChar : Char 
	get() = get( length - 1 ) 
	set( value : Char ) {
		this.setCharAt( length -1 , value )
	}

fun playWithLastCharacterProperties() {
	println( "Hello World".lastChar )
	println( "Good Morning!".lastChar )

	val sb = StringBuilder("Good Afternoon!")
	println( sb )
	println( sb.lastChar )
	
	sb.lastChar = '#'
	println( sb )
	println( sb.lastChar )
}

//_______________________________________________________________
// Experiment Following Code, MOMENT DONE >>> RAISE YOUR HANDS!!!

// Generic Extention Property

val <T> List<T> .penultimate: T
	get() = this[ size - 2 ]


fun playWithGenericProperty() {
	val list = listOf( 10, 20, 30, 40)
	println( "Value : ${ list.penultimate }")

	val listAgain = listOf( "Ding", "Dong", "Ting", "Tong")
	println( "Value : ${ listAgain.penultimate }")
}

//_______________________________________________________________

// fun <T : Number> oneHalf( value: T ) : Double {
// 	return ( value / 2.0 )
// }

// fun playWithOneHalf() {
// 	val something = 90.0

// 	println( oneHalf( something ) )
// 	println( oneHalf( 150.0 ) )
// }

//_______________________________________________________________
// Experiment Following Code, MOMENT DONE >>> RAISE YOUR HANDS!!!

open class Animal( val type : String  ) 
open class Pet( val name : String, type: String ) : Animal( type )

class Cat( name : String, type: String ) : Pet( name, type ) 
open class Dog( name : String, type: String ) : Pet( name, type ) 

open class Human( val name: String )
class Owner( name : String ) : Human( name )

// Type Constraints
//		T Is Place Holder With Constraint Where Type Will Be Substituded
//			T Type Which Are Pet Or Subtypes of Pet
fun <T : Pet> chooseFavorite(pets: List<T> ): T {
	val random = Random()
    val favorite = pets[ random.nextInt( pets.size ) ]
    println("${favorite.name} is the favorite")
    return favorite
}

// fun <T> chooseFavoriteAgain( animals: List<T> ): T {
// 	val random = Random()
//     val favorite : Animal = animals[ random.nextInt( animals.size ) ]
//     println("${favorite.name} is the favorite")
//     return favorite
// }

// open class Pet( val name : String, type: String ) : Animal( type )
// class Cat( name : String, type: String ) : Pet( name, type ) 

fun chooseFavoriteNonGeneric( pets: List<Pet> ) : Pet {
	val random = Random()
    val favorite = pets[ random.nextInt( pets.size ) ]
    println("${favorite.name} is the favorite")
    return favorite
}

fun playWithChooseFavorite() {
	val cats: List<Cat> = listOf( Cat("Whiskers", "Cat"), Cat("Rosie", "Cat") )
	val favorite = chooseFavorite( cats )
	println( "Favorite Name : ${ favorite.name }" )

// In Kotlin
// 		Cat is Subtype Of Pet
//			Then List<Cat> Is Covariant To List<Pet> ????

// In Java
// 		Cat is Subtype Of Pet
//			Then List<Cat> Is _________________ To List<Pet> ????

	val catsAgain: List<Cat> = listOf( Cat("Whiskers", "Cat"), Cat("Rosie", "Cat") )
	val favoriteAgain = chooseFavoriteNonGeneric( catsAgain )
	println( "Favorite Name : ${ favoriteAgain.name }" )

	// val animals: List<Animal> = listOf( Animal("Fish"), Animal("Bird"), Animal("Mammal") )
 // 	for (animal in animals) println( animal.type )
 	// error: type mismatch: inferred type is Animal but Pet was expected
	// val favoriteAgain = chooseFavorite( animals )
	// print( favoriteAgain )
}

//_______________________________________________________________
// Experiment Following Code, MOMENT DONE >>> RAISE YOUR HANDS!!!

// Boundless Generic Function
//		i.e. T Place Holder Can Be Substited With Any Type T
fun <T> equalsResult( first: T, second : T ) : Boolean  {
	return first == second
}

fun playWithEqualResults() {
	val first0 = 10
	val second0 = 100

	println( equalsResult( first0, second0 ) )

	val first1 = 10.90
	val second1 = 100.90

	println( equalsResult( first1, second1 ) )

	val first2 = Cat("Catie", "Cat")
	val second2 = Cat("Batie", "Cat")

	println( equalsResult( first2, second2 ) )
}

//_______________________________________________________________
// Experiment Following Code, MOMENT DONE >>> RAISE YOUR HANDS!!!


fun < T : Comparable<T> > max( first: T, second : T ) : T {
	return if ( first > second ) first else second
}

fun playWithGenericMax() {
	val maxValue0 = max( "Kotlin", "Java" )
	println( maxValue0 )

	val maxValue1 = max( 900, 100 )
	println( maxValue1 )

	val maxValue2 = max( 90.90, 100.100 )
	println( maxValue2 )
}

//_______________________________________________________________
// Experiment Following Code, MOMENT DONE >>> RAISE YOUR HANDS!!!

// Mutiple Type Parameters viz. T and U
fun < T : Pet, U : Human > chooseFavoriteMultiples( pets: List<T>, owners : List<U> ) : T {
	val random = Random()
	val owner = owners[ random.nextInt( owners.size ) ]
    val favorite = pets[ random.nextInt( pets.size ) ]

    println("${ favorite.name } is ${ owner.name } Favorite")
    return favorite
}

fun playWithChooseFavoriteMultiples() {
	val cats: List<Cat> = listOf( Cat("Whiskers", "Cat"), Cat("Rosie", "Cat") )
	val owners: List<Owner> = listOf( Owner("Himnanshu"), Owner("Shubra") )

	val favorite = chooseFavoriteMultiples( cats, owners )
	println( "Favorite Name : ${ favorite.name }" )
}

//_______________________________________________________________
// Experiment Following Code, MOMENT DONE >>> RAISE YOUR HANDS!!!

// fun <T : Pet> chooseFavorite(pets: List<T> ): T {
// 	val random = Random()
//     val favorite = pets[ random.nextInt( pets.size ) ]
//     println("${favorite.name} is the favorite")
//     return favorite
// }

// Following Code Is Same As Above Commented Code
fun <T> chooseFavoriteWhere(pets: List<T> ) : T  where T : Pet {
	val random = Random()
    val favorite = pets[ random.nextInt( pets.size ) ]
    println("${favorite.name} is the favorite")
    return favorite
}

// fun < T : Pet, U : Human > chooseFavoriteMultiples( pets: List<T>, owners : List<U> ) : T {
// 	val random = Random()
// 	val owner = owners[ random.nextInt( owners.size ) ]
//     val favorite = pets[ random.nextInt( pets.size ) ]

//     println("${ favorite.name } is ${ owner.name } Favorite")
//     return favorite
// }

// Following Code Is Same As Above Commented Code
fun <T, U> chooseFavoriteMultiplesWhere( pets: List<T>, owners : List<U> ) : T 
					where T : Pet, U : Human {
	val random = Random()
	val owner = owners[ random.nextInt( owners.size ) ]
    val favorite = pets[ random.nextInt( pets.size ) ]

    println("${ favorite.name } is ${ owner.name } Favorite")
    return favorite
}

fun playWithChooseFavoriteWhere() {
	val cats: List<Cat> = listOf( Cat("Whiskers", "Cat"), Cat("Rosie", "Cat") )
	val favorite = chooseFavoriteWhere( cats )
	println( "Favorite Name : ${ favorite.name }" )

	val catsAgain: List<Cat> = listOf( Cat("Whiskers", "Cat"), Cat("Rosie", "Cat") )
	val owners: List<Owner> = listOf( Owner("Himnanshu"), Owner("Shubra") )
	val favoriteAgain = chooseFavoriteMultiplesWhere( catsAgain, owners )
	println( "Favorite Name : ${ favoriteAgain.name }" )

}

// Mixing Is Possible With Where Clause
fun <T : Pet, U> chooseFavoriteMultiplesWhereMixing( pets: List<T>, owners : List<U> ) : T 
					where  U : Human {
	val random = Random()
	val owner = owners[ random.nextInt( owners.size ) ]
    val favorite = pets[ random.nextInt( pets.size ) ]

    println("${ favorite.name } is ${ owner.name } Favorite")
    return favorite
}

//_______________________________________________________________
// Experiment Following Code, MOMENT DONE >>> RAISE YOUR HANDS!!!

// Following Both Generic Function Definitions Are Same
// Default Upper Constraints For T Parameter is Any?
// fun <T> chooseFavoriteDefault( pets : List<T> ) : T {  

// }

// fun < T : Any? > chooseFavoriteDefaultExplicit( pets : List<T> ) : T {   

// }

// fun < T : Any > chooseFavoriteWithAny( pets : List<T> ) : T {   

// }

// fun playWithChooseFavoriteOptionals() {
// 	var mayBeCats : List<Cat?> = listOf( Cat("Whiskers", "Cat"), null, Cat("Rosie", "Cat") )
// 	val favorite: Cat? = chooseFavoriteDefault( mayBeCats )
// }

//_______________________________________________________________

// interface List<T> {
// 	operator fun get( index : Int ) : T 
// 	/*Here Goes  More Code... */

// }

// class StringList : List<String> {
// 	operator fun get( index : Int ) : T  = /// Code Here....

// 	/*Here Goes  More Code... */
// }


// class ArrayList<T> : List<T> {
// // 	operator fun get( index : Int ) : T  = /// Code Here....
// // 	/*Here Goes  More Code... */

// }


// interface Comparable<T> {
// 	fun comapreTo( other : T ) : Int 
// }

// class String : Comparable<String> {
// 	fun comapreTo( other : String ) : Int 	
// }


//_______________________________________________________________
// Experiment Following Code, MOMENT DONE >>> RAISE YOUR HANDS!!!


// Multiple Constraints On One Type Parameter T 
fun <T> appendTrailingDot( sequence : T ) where T : CharSequence, T : Appendable {
	if ( !sequence.endsWith('.') ) {
		sequence.append( '.' )
	}
}

fun playWithAppendTrailingDot() {
	val helloWorld = StringBuilder("Hello World!")
	appendTrailingDot( helloWorld )
	println( helloWorld )

	val helloWorldAgain = "Hello World Again!"
	// error: type mismatch: inferred type is String but kotlin.text.Appendable 
	// /* = java.lang.Appendable */ was expected
	// appendTrailingDot( helloWorldAgain )
	println( helloWorldAgain )
}

//_______________________________________________________________
// Experiment Following Code, MOMENT DONE >>> RAISE YOUR HANDS!!!

// Here Default Type Parameter Upper Bound is Any?

// Here Processor Is Parameterised Type With Type Parameter T
class Processor< T > {
	fun process( value : T ) {
		println( value?.hashCode() )
	}
}

class ProcessorAgain< T : Any > {
	fun process( value : T ) {
		println( value.hashCode() )
	}
}

fun playWithProcessor() {
	val stringProcessor = Processor<String?>()
	stringProcessor.process( null )

	// error: type argument is not within its bounds: should be subtype of 'Any'
	// val stringProcessorAgain = ProcessorAgain<String?>()
	// stringProcessorAgain.process( null )
}

//_______________________________________________________________

fun playWithListOfs() {
	// Explicitly Annotating Types To List<Int> and List<String>
	//		Just To Draw Attention

	// Note : List<Int> and List<String> Types Are Compile Time Information
	// 		In Exectuable/Runtime Time Both The Just List
	//		i.e. List Of Object
	val list1 : List<Int> 		= listOf( 10, 20, 30, 40, 50 )
	val list2 : List<String>    = listOf( "Ding", "Dong", "Ting", "Tong" )

	println( list1 )
	println( list2 )

	// Earlier Kotlin Compilers Will Give Errors
	//		Cann't Check for Instance Of The Erased Types

 	// warning: check for instance is always 'true'
	if ( list1 is List<Int> ) {
		println(" It's List<Int> Type ")
	} 

 	// warning: check for instance is always 'true'
	if ( list2 is List<String> ) {
		println(" It's List<String> Type ")
	} 

	if ( list2 is List<*> ) {
		println(" It's List Type ")
	} 
}

//_______________________________________________________________
// Experiment Following Code, MOMENT DONE >>> RAISE YOUR HANDS!!!

fun printSum( collection: Collection<*> )  {
	// Code Smell : BAD CODE Examples
	// warning: unchecked cast: Collection<*> to List<Int>
	val intList = collection as? List<Int> ?: throw IllegalArgumentException("List Is Expected")

	println( intList.sum() ) 
}

fun playWithPrintSum() {
	val list1 : List<Int> 		= listOf( 10, 20, 30, 40, 50 )
	val set1 = setOf( 10, 20, 30, 40, 50 )

	printSum( list1 )
	// printSum( set1 )
}

//_______________________________________________________________


fun printSumInt( collection: Collection<Int> )  {
	// Code Smell : BAD CODE Examples
	// warning: unchecked cast: Collection<*> to List<Int>
	if ( collection is List<Int> ) {
		println( collection.sum() ) 
	}
}

fun playWithPrintSumInt() {
	val list1 : List<Int> 		= listOf( 10, 20, 30, 40, 50 )
	val set1 = setOf( 10, 20, 30, 40, 50 )

	printSum( list1 )
	// printSum( set1 )
}

//_______________________________________________________________
// Experiment Following Code, MOMENT DONE >>> RAISE YOUR HANDS!!!


// Reified Type Parameters Can Do
//		In Type Checks and Cast (is, !is as, as?)
//		Can Use In Kotlin Reflection APIs
//		Can Use To Get Corresponding java.lang.Class ( ::class.java )
//		As A Type Aguemnt To Call Other Functions

// Reified Type Parameters CANNOT Do
//		Create New Instance Of The Class Spefified As Type Parameter

inline fun <reified T> isA( value: Any ) = value is T

// error: only type parameters of inline functions can be reified
// fun <reified T> isA( value: Any ) = value is T

fun playWithReifiedInlineFunction() {
	val value1 = isA<String>("Good Morning!")

	//Compiler Will Generate Following Code For You After Function Inlining and Reified Type
	//		Reified Types Information Get Imbedded In Inline Function
	// val value1 = "Good Morning" is String

	val value2 = isA<String>( 123 )

	//Compiler Will Generate Following Code For You After Function Inlining and Reified Type
	//		Reified Types Information Get Imbedded In Inline Function
	// val value2 = 123 is String
	
	println( value1 ) 
	println( value2 ) 
}

//_______________________________________________________________
// Experiment Following Code, MOMENT DONE >>> RAISE YOUR HANDS!!!


fun printContents( list: List<Any> ) {
	println( list.joinToString( ) )
}

fun addContent( list : MutableList<Any> ) {
	list.add( 100 )
}

fun printListStringContent( list: List<String?> ) {
	println( list.joinToString( ) )
}

fun printListAnyContent( list: List<Any?> ) {
	println( list.joinToString( ) )
}

fun playWithContentFunctions() {
	var list1 : List<String> = listOf( "Ding", "Dong", "Ting", "Tong" )
	var list2 : MutableList<String> = mutableListOf( "Ding", "Dong", "Ting", "Tong" )

	printContents( list1 )

	// error: type mismatch: inferred type is List<String> but MutableList<Any> was expected
	// addContent( list1 )

// String Is Subtype Of Any
// Covariance Relationship
// 		List<String> Is Subtype Of List<Any> 
// Invariant Relationship
// 		MutableList<String>  Is NOT Subtype Of MutableList<Any> 

// 	MutableList<String>  Is NOT Subtype Of MutableList<Any> 
	// i.e. Invariant Types Because Of Following Reason
	
	// It’s not safe to pass a MutableList<String> as an argument when a MutableList<Any> is expected; 
	// the Kotlin compiler correctly forbids that
	// In Kotlin, this can be easily controlled by choosing the right interface, 
	// depending on whether the list is mutable. 
	// If a function accepts a read-only list, you can pass a List with a more specific element type. 
	// If the list is mutable, you can’t do that.

	// error: type mismatch: inferred type is MutableList<String> but MutableList<Any> was expected
	// addContent( list2 )

	var list3 : List<String?> 	= listOf( "Ding", "Dong", null, "Tong" )
	var list4 : List<String> 	= listOf( "Ding", "Dong", "Ting", "Tong" )

// String Is Subtype Of String?
// Covariance Relationship
// 		List<String> Is Subtype Of List<String?> 
	printListStringContent( list3 )
	printListStringContent( list4 )

	var list5 : List<Any?> 	= listOf( "Ding", "Dong", null, "Tong" )
	var list6 : List<Any> 	= listOf( "Ding", "Dong", "Ting", "Tong" )

// Any Is Subtype Of Any?
// Covariance Relationship
// 		List<Any> Is Subtype Of List<Any?> 
	printListAnyContent( list5 )
	printListAnyContent( list6 )
}

//_______________________________________________________________

// open class AnimalAgain( val type : String  ) {
// 	fun feed() = println("Feeding Animal")  
// }

// class CatAgain( val name : String, type: String ) 	: AnimalAgain( type ) 
// class DogAgain( val name : String, type: String ) 	: AnimalAgain( type ) 

// // CatAgain Is Subtype Of AnimalAgain
// // Producer<CatAgain> Is Invariant To Producer<AnimalAgain>

// // interface Producer< T > {
// // 	fun produce() : T

// // 	// error: type parameter T is declared as 'out' but occurs in 'in' position in type T
// // 	// fun consume( data : T )
// // }

// // CatAgain Is Subtype Of AnimalAgain
// // Producer<CatAgain> Is Covariant To Producer<AnimalAgain>
// interface Producer< out T > {
// 	fun produce() : T

// 	// error: type parameter T is declared as 'out' but occurs in 'in' position in type T
// 	// fun consume( data : T )
// }

// // CatAgain Is Subtype Of AnimalAgain
// // Herd<CatAgain> Is InvariantTo Herd<AnimalAgain>
// // class Herd< T : AnimalAgain >  {
// // 	//  Collection Of T You Create It

// // 	val size : Int = 10
// // 		// get() =  // Calcualate Size Of Collections 

// // 	operator fun get( index: Int ) : T = { /* ...... */ }
// // }

// // CatAgain Is Subtype Of AnimalAgain
// // Herd<CatAgain> Is Convariant To Herd<AnimalAgain>
// class Herd< out T : AnimalAgain >  {
// 	//  Collection Of T You Create It

// 	val size : Int = 10
// 		// get() =  // Calcualate Size Of Collections 

// 	operator fun get( index: Int ) : T = { /* ...... */ }
// }

// fun feedAll( animals : Herd<AnimalAgain> ) {
// 	for ( index in 0 until animals.size ) {
// 		animals[ i ].feed()
// 	}
// }


// fun playWithTypeRelationships() {
// 	// val herds: Herd<Cat>(                  ) 
// 	// feedAll( herds )
// }


// //_______________________________________________________________

// interface Transformer< T > {
// 				// in Place   // out Place
// 	fun transform( data : T ) : T  
// }	


// // Exmaple For List Implementation In Kotlin
// interface List< out T > : Collection<T> {
// 	operator fun get( index: Int) : T 
// }


// interface MutableList<T> : List<T>, MutableCollections<T> {
// 	override fun add( element : T ) : Boolean 
// }

// //_______________________________________________________________


// interface Comparator< in T > {
// 	fun compare( elemnet1 : T, element2 : T ) : Int {
// 		/*,........ */
// 	}
// }

// // String Is Subtype Of Any
// //		Comarator<Any> 	In Contravariance Relationship To	Comaprator<String>
// //		i.e. Comarator<Any> Is Subtype Of Comaprator<String>

// fun playWithComarator() {

// 	val anyComparator = Comparator<Any> {
// 		element1, element2  -> elemnet1.hashCode() - element2.hashCode()
// 	}

// 	val strings : List<String> = /* Code Here */ 
// 	strings.sortedWith( anyComparator )
// }


//_______________________________________________________________

// Assumptions

// 		Cat Is Subtype Of Animal

// Convariant Relationship
// 		e.g Producer< out T > 
//		Subtying Relationship Is Preserved
//		Producer<Cat> Is Subtype Of Producer<Animal>
//		T Only In 'out' Position

// Cotranvariant Relationship
// 		e.g Consumer< in T > 
//		Subtying Relationship Is Reversed
//		Consumer<Animal> Is Subtype Of Consumer<Cat>
//		T Only In 'in' Position

// Invariant Relationship
// 		e.g MutableList< T > 
//		T Only In 'Any Position


//_______________________________________________________________


interface Function1< in P, out R> {
	operator fun invoke( p : P ) : R
}

//_______________________________________________________________
//_______________________________________________________________
//_______________________________________________________________
//_______________________________________________________________
// Experiment Following Code, MOMENT DONE >>> RAISE YOUR HANDS!!!

fun main() {
	println("\nFunction : playWithMutableStack")
	playWithMutableStack()

	println("\nFunction : playWithExtensionProperties")
	playWithExtensionProperties()

	println("\nFunction : playWithGenericProperty")
	playWithGenericProperty()

	println("\nFunction : playWithLastCharacterProperties")
	playWithLastCharacterProperties()

	// println("\nFunction : playWithOneHalf")
	// playWithOneHalf()

	println("\nFunction : playWithChooseFavorite")
	playWithChooseFavorite()

	println("\nFunction : playWithEqualResults")
	playWithEqualResults()

	println("\nFunction : playWithGenericMax")
	playWithGenericMax()

	println("\nFunction : playWithChooseFavoriteMultiples")
	playWithChooseFavoriteMultiples()

	println("\nFunction : playWithChooseFavoriteWhere")
	playWithChooseFavoriteWhere()

	println("\nFunction : playWithAppendTrailingDot")
	playWithAppendTrailingDot()

	println("\nFunction : playWithProcessor")
	playWithProcessor()

	println("\nFunction : playWithListOfs")
	playWithListOfs()

	println("\nFunction : playWithPrintSum")
	playWithPrintSum()

	println("\nFunction : playWithPrintSumInt")
	playWithPrintSumInt()

	println("\nFunction : playWithReifiedInlineFunction")
	playWithReifiedInlineFunction()

	println("\nFunction : playWithPrintContent")
	playWithContentFunctions()

	// println("\nFunction : playWithTypeRelationships")
	// playWithTypeRelationships()

	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
}

/*
kotlinc KotlinGenerics.kt -include-runtime -d generics.jar
java -jar generics.jar 
*/

