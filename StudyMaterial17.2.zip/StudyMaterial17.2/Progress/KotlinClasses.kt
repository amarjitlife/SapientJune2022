
/*
kotlinc KotlinClasses.kt -include-runtime -d classes.jar
java -jar classes.jar 
*/

package learnKotlin;

//_______________________________________________________________


// class Person( name: String, isMarried: Boolean ) {

class Person( val name: String, var isMarried: Boolean ) {
	// Method
	// 	Member Function
	fun dance( danceForm: String ) {
		println( "Doing Dance : $danceForm ..." )
	}

	fun singing( danceForm: String ) {
		println( "Doing Dance : $danceForm ..." )
	}
}

fun playWithPerson() {
	var person0 = Person( "Alice", false )

	println( person0.name ) 		// 	person0.getName() 
	println( person0.isMarried )	// 	person0.getIsMarried() 

	// Sending Message To Object person0
	person0.dance("Bharatnatyam!") 	// Is It Function Call???

	var person1 = Person( "Chandan", false )
	println( person1.name )			// 	person1.getName() 
	println( person1.isMarried ) 	// 	person1.getIsMarried() 

	person1.dance("Bhangraa!")

	person1.isMarried = true  		// 	person0.setIsMarried( true ) 
	println( person1.isMarried )    // 	person1.getIsMarried() 	
}

//_______________________________________________________________
// Experiment Following Code, MOMENT DONE >>> RAISE YOUR HANDS!!!

// BEST PRACTICE
//		Classes Which Are Not Meant To Be Inherited Must Be Final

// In Kotlin
//		Classes Are Final By Default
//		Member Functions Are Also Final By Default

// In Kotlin
//		Classes Are Open By Default
//		Member Functions Are Also Open By Default

open class View {
	 // error: 'click' in 'View' is final and cannot be overridden
	open fun click() = println("View Clicked!...")
}

// error: this type is final, so it cannot be inherited from
class Button : View() {
	// error: 'click' hides member of supertype 'View' and needs 'override' modifier

	override fun click() = println("Button Clicked!...") 
	fun doMagic() = println("Button Magic!...")
}

fun View.showOff() 		= println("View Showoff...")
fun Button.showOff() 	= println("Button Showoff...")

fun View.beHappening()  = println("View Happening...")
// fun Button.beHappening()  = println("View Happening...")

fun playWithInheritance() {
	val viewObject = View()
	viewObject.click()
	viewObject.showOff()

	val buttonObject = Button()
	buttonObject.click()
	buttonObject.doMagic()

	buttonObject.showOff()	
	buttonObject.beHappening()

	//Button Object Is Button Type As Well As View Type 
	val viewObjectAgain : View = Button()
	viewObjectAgain.click() 				// Button Clicked!...
	// viewObjectAgain.doMagic() 			//  error: unresolved reference: doMagic

	viewObjectAgain.showOff() 			// View Showoff...
	// error: unresolved reference: beHappening
	viewObjectAgain.beHappening()
}


//_______________________________________________________________

// In Kotlin
//		Interfaces Are Open By Default
//		Interfaces Member Functions Are Open By Default


// BEST PRACTICE
//		Design Towards Abstract Types Rather Than Concrete Types
//		{ Operations, Phi }

//	Corollary
//		Design Towards Interfaces Rather Than Concrete Classes

// Abstract Type
//		Operation = { click }

// What It Will Do!
interface Clickable1 {
	fun click()
}

// error: 'click' hides member of supertype 'Clickable1' and needs 'override' modifier

// Concrete Types Or Concrete Classes

// How, Why, When, Which Way, Where...
// Implementing Interface Clickable
class Button1 : Clickable1 {
	override fun click() = println("Button1 Clicked!...")
}

fun playWithInterfaces() {
	val buttonObject = Button1()
	buttonObject.click()
}

//_______________________________________________________________
// Experiment Following Code, MOMENT DONE >>> RAISE YOUR HANDS!!!

interface Clickable2 {
	fun click()
	fun showOff() = println("Clickable2 Showoff!..")
}

interface Focusable2 {
	fun setFocus() = println("Focuable2 setFocus!...")
	fun showOff()  = println("Focusable2 Showoff!..")
}

// error: 'click' hides member of supertype 'Clickable1' and needs 'override' modifier
// Implementing Interface Clickable

// error: class 'Button2' must override public open fun showOff(): Unit 
//		defined in learnKotlin.Clickable2 because it inherits multiple interface methods of it
class Button2 : Clickable2, Focusable2 {
	override fun click() = println("Button1 Clicked!...")

	override fun showOff() {
		//error: many supertypes available, please specify the one you mean 
		//in angle brackets, e.g. 'super<Foo>'
		// super.showOff()
		super<Clickable2>.showOff()
		super<Focusable2>.showOff()
	}
}

fun playWithInterfacesAgain() {
	val buttonObject = Button2()
	buttonObject.click()
	buttonObject.setFocus()

	buttonObject.showOff()
}



//_______________________________________________________________

interface Clickable3 {
	fun click()
	fun showOff() = println("Clickable3 Showoff!..")
}

interface Focusable3 {
	fun setFocus() = println("Focusable3 setFocus!...")
	fun showOff()  = println("Focusable3 Showoff!..")
}

interface Blinkable3 {
	fun blinking() = println("Blinkable3 Blinking!...")
}

// error: 'click' hides member of supertype 'Clickable1' and needs 'override' modifier
// Implementing Interface Clickable

// error: class 'Button2' must override public open fun showOff(): Unit 
//		defined in learnKotlin.Clickable2 because it inherits multiple interface methods of it
open class Button3 : Clickable3, Focusable3 {
	final override fun click() = println("Button3 Clicked!...")

	override fun showOff() {
		//error: many supertypes available, please specify the one you mean 
		//in angle brackets, e.g. 'super<Foo>'
		// super.showOff()
		super<Clickable3>.showOff()
		super<Focusable3>.showOff()
	}
}

class RichButton3 : Button3(), Blinkable3 {
	override fun blinking()  	= println("RichButton3 Blinking!...")
	override fun setFocus()		= println("RichButton3 Blinking setFocus!...")

	// error: 'click' in 'Button3' is final and cannot be overridden
	// override fun click() 		= println("RichButton3 Clicked!...")
	// error: 'click' hides member of supertype 'Button3' and needs 'override' modifier
	// fun click() 				= println("RichButton3 Clicked!...")
}

fun playWithInterfacesAndInheritance() {
	val buttonObject = RichButton3()
	buttonObject.click()
	buttonObject.setFocus()

	buttonObject.showOff()
	buttonObject.blinking()
}


//_______________________________________________________________
// Experiment Following Code, MOMENT DONE >>> RAISE YOUR HANDS!!!

// Using Interface To Create Type
interface Expr
class Num( val value: Int ) : Expr
class Sum( val left: Expr, val right: Expr ) : Expr

fun eval( e : Expr ) : Int {
	// What Is The Type e 
	// Type Of e Is Expr
	if ( e is Num ) {
		// Smart Cast
		// if e is Num Type True Than Type Cast e To Num Type
		// What Is The Type e 
		// Type Of e Is Num
		return e.value
	}

	if ( e is Sum ) {
		// Smart Cast
		// if e is Sum Type True Than Type Cast e To Sum Type
		// What Is The Type e 
		// Type Of e Is Sum
		return eval( e.left ) + eval( e.right )
	}

	throw IllegalArgumentException("Unknown Arguments")
}

fun playWithEval() {
	// 100 + 200

	println( "Expression : 100 + 200" )
	println( eval( Sum( Num(100), Num(200) ) ) )  

	println( "Expression : (100 + 200) + 11 " )
	println( eval( Sum( (Sum( Num(100), Num(200) )), Num(11) ) ) )  
}


//_______________________________________________________________
// Experiment Following Code, MOMENT DONE >>> RAISE YOUR HANDS!!!

// interface Expr
// class Num( val value: Int ) : Expr
// class Sum( val left: Expr, val right: Expr ) : Expr

//error: type checking has run into a recursive problem. 
// 		Easiest workaround: specify types of your declarations explicitly
fun evalIf( e : Expr ) : Int = if ( e is Num ) {
		e.value
	} else if ( e is Sum ) {
		evalIf( e.left ) + evalIf( e.right )
	} else {
		throw IllegalArgumentException("Unknown Arguments")
	}

fun playWithEvalIf() {
	// 100 + 200

	println( "Expression : 100 + 200" )
	println( evalIf( Sum( Num(100), Num(200) ) ) )  

	println( "Expression : (100 + 200) + 11 " )
	println( evalIf( Sum( (Sum( Num(100), Num(200) )), Num(11) ) ) )  
}

//_______________________________________________________________

// interface Expr
// class Num( val value: Int ) : Expr
// class Sum( val left: Expr, val right: Expr ) : Expr

// error: type checking has run into a recursive problem. 
//Easiest workaround: specify types of your declarations explicitly
fun evalWhen( e : Expr ) : Int = when (e) {
	 is Num  ->  e.value
	 is Sum  ->  evalWhen( e.left ) + evalWhen( e.right )
	 else 	 ->  throw IllegalArgumentException("Unknown Arguments")
}

fun playWithEvalWhen() {
	// 100 + 200

	println( "Expression : 100 + 200" )
	println( evalWhen( Sum( Num(100), Num(200) ) ) )  

	println( "Expression : (100 + 200) + 11 " )
	println( evalWhen( Sum( (Sum( Num(100), Num(200) )), Num(11) ) ) )  
}

//_______________________________________________________________
// Experiment Following Code, MOMENT DONE >>> RAISE YOUR HANDS!!!

enum class Colour(val r: Int, val g: Int, val b: Int) {
	RED(255, 0, 0), GREEN(0, 255, 0), BLUE(0, 0, 255), 
	YELLOW(200, 200, 0), ORANGE(150, 150, 10) ;

	fun rgb() = ( r * 255 + g ) * 255 + b
}

// interface Expr
// class Num( val value: Int ) : Expr
// class Sum( val left: Expr, val right: Expr ) : Expr
// enum class Expr() {
// 	NUM(), SUM()
// }

sealed class Exprn {
	class Num(val value: Int) : Exprn() 
	class Sum(val left: Exprn, val right: Exprn) : Exprn() 
}

fun evaluateExpression( e : Exprn ) : Int = when (e) {
	 is Exprn.Num  ->  e.value
	 is Exprn.Sum  ->  evaluateExpression( e.left ) + evaluateExpression( e.right )
	 // else 	   ->  throw IllegalArgumentException("Unknown Arguments")
}

fun playWithEvaluateExpression() {
	// 100 + 200

	println( "Expression : 100 + 200" )
	println( evaluateExpression( Exprn.Sum( Exprn.Num(100), Exprn.Num(200) ) ) )  

	println( "Expression : (100 + 200) + 11 " )
	println( evaluateExpression( Exprn.Sum( (Exprn.Sum( Exprn.Num(100), Exprn.Num(200) )), 
		Exprn.Num(11) ) ) )  
}

//_______________________________________________________________
// Experiment Following Code, MOMENT DONE >>> RAISE YOUR HANDS!!!


// What Is The Best Practices For Writing
//		equals And hashCode Method
//

// EQUAL CONTRACT

// Indicates whether some other object is "equal to" this one.

// The equals method implements an equivalence relation on non-null object references:

// It is reflexive: for any non-null reference value x, x.equals(x) should return true.

// It is symmetric: for any non-null reference values x and y, x.equals(y) 
//	should return true if and only if y.equals(x) returns true.

// It is transitive: for any non-null reference values x, y, and z, 
	//if x.equals(y) returns true and y.equals(z) returns true, 
	//then x.equals(z) should return true.

// It is consistent: for any non-null reference values x and y, 
// 	multiple invocations of x.equals(y) consistently return true 
//	or consistently return false, provided no information used in 
//	equals comparisons on the objects is modified.

// For any non-null reference value x, x.equals(null) should return false.
// The equals method for class Object implements the most discriminating possible equivalence relation on objects; that is, for any non-null reference values x and y, this method returns true if and only if x and y refer to the same object (x == y has the value true).

// Note that it is generally necessary to override the hashCode method whenever this method is overridden, so as to maintain the general contract for the hashCode method, which states that equal objects must have equal hash codes.

// HASH CODE CONTRACT

// public int hashCode()
// Returns a hash code value for the object. This method is supported for the benefit of hash tables such as those provided by HashMap.

// The general contract of hashCode is:

// Whenever it is invoked on the same object more than once during an execution of a Java application, the hashCode method must consistently return the same integer, provided no information used in equals comparisons on the object is modified. This integer need not remain consistent from one execution of an application to another execution of the same application.

// If two objects are equal according to the equals(Object) method, then calling the hashCode method on each of the two objects must produce the same integer result.

// It is not required that if two objects are unequal according to the equals(java.lang.Object) method, then calling the hashCode method on each of the two objects must produce distinct integer results. However, the programmer should be aware that producing distinct integer results for unequal objects may improve the performance of hash tables.

// As much as is reasonably practical, the hashCode method defined by class Object does return distinct integers for distinct objects. (This is typically implemented by converting the internal address of the object into an integer, but this implementation technique is not required by the JavaTM programming language.)

class Client( val name: String, val postalCode: Int ) {
	// override fun toString() String {
	// 	return "Client(name=$name, postalCode=$postalCode)"
	// }
	override fun toString() = "Client(name=$name, postalCode=$postalCode)"
	
	override fun equals( other : Any? ) : Boolean {
		if ( other == null || other  !is  Client ) return false
		return name == other.name && postalCode == other.postalCode
	}
	// Good Practice: Must Implemnent hasCode Method Also
}

fun playWithClient() {
	val alice = Client( "Alice", 44444 )
	println( alice.name )
	println( alice.postalCode )

	println( alice )

	val alice1 = Client( "Alice", 44444 )
	val martin = Client( "Martin", 88888 )
	println( alice1 ) 		// alice1.toString()
	println( martin )		// matrin.toString()

	println( alice == alice1 ) 		// alice.equals( alice1 )
	println( alice == martin )		// alice.equals( martin )
	println( alice1 == martin )		// alice1.equals( martin )
}

//_______________________________________________________________

// DATA CLASSES
//		Compiler Will Generate Following Methods
//		1. toString Method With String Representaion Of All Properties
//		2. equals Method With Compariion Based On All Properties
//		3. hashCode Method With Hash Code Calculated On All Properties
//		4. copy Method For Immutable Properties

data class Client1( val name: String, val postalCode: Int )

fun playWithClient1() {
	val alice = Client1( "Alice", 44444 )
	println( alice.name )
	println( alice.postalCode )

	println( alice )

	val alice1 = Client1( "Alice", 44444 )
	val martin = Client1( "Martin", 88888 )
	println( alice1 ) 		// alice1.toString()
	println( martin )		// matrin.toString()

	println( alice == alice1 ) 		// alice.equals( alice1 )
	println( alice == martin )		// alice.equals( martin )
	println( alice1 == martin )		// alice1.equals( martin )
}

//_______________________________________________________________

// Singleton Class In Java
//		1. Cosnstructor Private
//		2. static Method To getInstance
//		3. Private static Member To Track Single Instance

// Object Classes
//		Singleton Classes In Kotlin
//		Object Name Is Type Name Itself

object India {
	fun name() : String {
		return "Hindustan!!!"
	}
}

fun playWithSingleton() {
	val name = India.name()
	println("India Name : $name" )
}

//_______________________________________________________________
//_______________________________________________________________
//_______________________________________________________________
//_______________________________________________________________
//_______________________________________________________________
//_______________________________________________________________
// Experiment Following Code, MOMENT DONE >>> RAISE YOUR HANDS!!!

fun main() {
	println("\nFunction : playWithPerson")
	playWithPerson()

	println("\nFunction : playWithInheritance")
	playWithInheritance()

	println("\nFunction : playWithInterfaces")
	playWithInterfaces()

	println("\nFunction : playWithInterfacesAgain")
	playWithInterfacesAgain()

	println("\nFunction : playWithInterfacesAndInheritance")
	playWithInterfacesAndInheritance()

	println("\nFunction : playWithEval")
	playWithEval()

	println("\nFunction : playWithEvalIf")
	playWithEvalIf()

	println("\nFunction : playWithEvalWhen")
	playWithEvalWhen()

	println("\nFunction : playWithEvaluateExpression")
	playWithEvaluateExpression()

	println("\nFunction : playWithClient")
	playWithClient()

	println("\nFunction : playWithClient1")
	playWithClient1()

	println("\nFunction : playWithSingleton")
	playWithSingleton()

	// println("\nFunction : ")	
	// println("\nFunction : ")
	// println("\nFunction : ")	
	// println("\nFunction : ")	
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")	
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")	
}
