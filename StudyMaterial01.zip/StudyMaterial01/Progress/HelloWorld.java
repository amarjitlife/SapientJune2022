
/*
javac HelloWorld.java -d ClassFiles
java -cp ClassFiles/ learnJava.HelloWorld
*/

package learnJava;

class HelloWorld {
	public static void main(String[] args ) {
		System.out.print("Hello World!\n");	
	}
}


// Your First Program

// class HelloWorld {
//     public static void main(String[] args) {
//         System.out.println("Hello, World!"); 
//     }
// }


//________________________________________________________


class Person(
	val name: String,
	var isMarried: Boolean
)

fun playWithPerson() {
	var person0 = Person( "Alice", false )
	println( person0.name )
	println( person0.isMarried )

	var person1 = Person( "Chandan", true )
	println( person1.name )
	println( person1.isMarried )
}


//________________________________________________________

class Person {
	String name;
	Boolean isMarried;

	Person(String name, Boolean isMarried) {
		this.name = name;
		this.isMarried = isMarried;
	}

	public String getName() {
		return name;
	}

	public setName(String name) {
		this.name = name;
	}

	public Boolean getIsMarried() {
		return isMarried;
	}

	public setIsMarried(Boolean isMarried) {
		this.isMarried = isMarried;
	}
}



