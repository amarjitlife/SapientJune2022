#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

static int staticData = 111;

int main() {
	int stackData = 222;
	char processName[10] = "";

	printf("Before Forking...\n");

	int childPID = fork();
	
	printf("After Forking Return Value: %d\n", childPID );

	switch( childPID ) {
		case -1:
			printf("\nForking Error Happened...");
			exit( EXIT_FAILURE );

		case 0: // Child Process
			stackData 	= staticData * 3;
			staticData 	= staticData * 3;

			 char * argv_list[] = {"ls","-lart","/home",NULL};
		      // the execv() only return if error occurred.
		      // The return value is -1
		      execv("ls",argv_list);

			break;

		default: // Parent Process
			sleep( 3 );
			break;
	}

	if ( childPID == 0 ) strcpy( processName, "Child : ");
	else 				 strcpy( processName, "Parent: ");

	printf("Process : %s", processName );
	printf("\t PID = %u, PPID = %u, stackData = %d, staticData = %d\n",
		getpid(), getppid(), stackData, staticData);

	getchar();
	return 0;
}

// Before Forking...
// After Forking Return Value: 12175
// After Forking Return Value: 0
// Process : Parent: 	 PID = 12174, PPID = 4737, stackData = 222, staticData = 111
// Process : Child : 	 PID = 12175, PPID = 12174, stackData = 333, staticData = 333
