
__________________________________________________________________________

DAY 05
__________________________________________________________________________

	ASSSIGNMENT A1 : READING ASSIGNMENTS
	
		Java Serialisation Pitfalls
			https://github.com/pmd/pmd/issues/2992
			https://docs.oracle.com/javase/tutorial/java/javaOO/nested.html#Serialization

	ASSSIGNMENT A2 : READING ASSIGNMENTS

		The C Programming Language, 2nd Edition
			By Kernigham and Dennis Ritchie

		1. Arrays and Pointers Chapter [ MUST READ ]
		2. Rest All Chapters Depends On Your Interest


	ASSSIGNMENT A3 : KOTLIN CODE REVISION AND EXPERIMENTATION

		Revise and Experiment Kotlin Code Done Till Now


__________________________________________________________________________

DAY 07
__________________________________________________________________________

	ASSSIGNMENT A1 : READING ASSIGNMENTS
	
		Java Functional Interfaces
		https://www.baeldung.com/java-8-functional-interfaces
		https://www.baeldung.com/kotlin/lambda-receiver

	ASSSIGNMENT A2 : EXPLORATION ASSIGNMENT
		Extention Function On Nullable Type


__________________________________________________________________________

DAY 08
__________________________________________________________________________

	ASSSIGNMENT A1 : READING ASSIGNMENTS

		Infix, PostFix, and Prefix Exresssion Notation 
		https://panda.ime.usp.br/panda/static/pythonds_pt/02-EDBasicos/InfixPrefixandPostfixExpressions.html
		https://runestone.academy/ns/books/published/pythonds/BasicDS/InfixPrefixandPostfixExpressions.html


__________________________________________________________________________

DAY 09
__________________________________________________________________________

	ASSSIGNMENT A1 : READING ASSIGNMENTS

		Covariant, Invariant And Contravariant In Java
		https://medium.com/@yuhuan/covariance-and-contravariance-in-java-6d9bfb7f6b8e

		JVM Architecture And Concepts
		https://medium.com/platform-engineer/understanding-java-memory-model-1d0863f6d973

	ASSSIGNMENT A2 : ANNOTATION CODE EXPLORATION ASSIGNMENT
		
		https://github.com/yole/jkid


__________________________________________________________________________

DAY 10
__________________________________________________________________________


	ASSSIGNMENT A1 : READING ASSIGNMENTS
		UML Notation
		https://www.visual-paradigm.com/guide/uml-unified-modeling-language/uml-class-diagram-tutorial/
		https://developer.ibm.com/articles/the-class-diagram/

	ASSSIGNMENT A2 : READING ASSIGNMENTS
		DESIGN PATTERNS
		https://b-ok.asia/s/Dive%20Into%20Design%20Patterns

	ASSSIGNMENT A3 : CODING ASSIGNMENTS
		CODE DESIGN PATTERNS IN KOTLIN
		https://b-ok.asia/s/Dive%20Into%20Design%20Patterns

__________________________________________________________________________

DAY 11
__________________________________________________________________________


__________________________________________________________________________

DAY 12
__________________________________________________________________________


	ASSSIGNMENT A1 : READING AND EXPERIMENT ASSIGNMENT
		Coroutine Exception Handling
		https://kotlinlang.org/docs/exception-handling.html

	ASSSIGNMENT A3 : CODING ASSIGNMENTS [ CONTINUES... ]
		CODE DESIGN PATTERNS IN KOTLIN
		https://b-ok.asia/s/Dive%20Into%20Design%20Patterns

	QUERIES: POST IN GOOGLE DOCUMENT
		Google Document Link
		https://tinyurl.com/3xm3xu4t


__________________________________________________________________________

DAY 13
__________________________________________________________________________

	ASSSIGNMENT A1 : READING AND EXPERIMENT ASSIGNMENT
		Coroutine Exception Handling
		https://kotlinlang.org/docs/exception-handling.html

		Coroutine Channels
		https://kotlinlang.org/docs/channels.html

	ASSSIGNMENT A2 : CODING ASSIGNMENTS [ CONTINUES... ]
		CODE DESIGN PATTERNS IN KOTLIN
		https://b-ok.asia/s/Dive%20Into%20Design%20Patterns

	QUERIES: POST IN GOOGLE DOCUMENT
		Google Document Link
		https://tinyurl.com/3xm3xu4t


__________________________________________________________________________

DAY 14
__________________________________________________________________________

	ASSSIGNMENT A1 : READING AND EXPERIMENT ASSIGNMENT

		Activity Lifecycle
		https://developer.android.com/guide/components/activities/activity-lifecycle
		
		Handling Config Changes
		https://developer.android.com/guide/topics/resources/runtime-changes

		Activity Attributes [ Read Selectives ]
		https://developer.android.com/guide/topics/manifest/activity-element

__________________________________________________________________________

DAY 15
__________________________________________________________________________

	ASSSIGNMENT A1 : READING AND SIMULATE IN KOTLIN CODE ASSIGNMENT
		MVC, MVP, MVVM, VIPER etc..
		https://medium.com/ios-os-x-development/ios-architecture-patterns-ecba4c38de52

	ASSSIGNMENT A2 : ANDROID CONCEPTS READING AND THINKING ASSIGNMENT
		https://developer.android.com/guide/components/activities/process-lifecycle
		https://developer.android.com/guide/components/activities/activity-lifecycle
		https://developer.android.com/guide/components/activities/tasks-and-back-stack
		https://developer.android.com/guide/components/activities/state-changes
		https://developer.android.com/guide/components/services
		https://developer.android.com/guide/components/intents-filters

	ASSSIGNMENT A3 : ANDROID APPLICATION MODERN ARCHITECHURE AND THINKING ASSIGNMENT
		https://developer.android.com/guide/components/fundamentals
		https://developer.android.com/topic/architecture/intro
		https://developer.android.com/topic/architecture
		https://developer.android.com/topic/architecture/ui-layer
		https://developer.android.com/topic/architecture/ui-layer/events

	ASSSIGNMENT A4 : ANDROID CONCEPTS [ PHASE II ]
		https://developer.android.com/guide/components/foreground-services
		https://developer.android.com/guide/components/bound-services
		
__________________________________________________________________________

DAY 16
__________________________________________________________________________


	ASSSIGNMENT A1 : READING AND SIMULATE IN KOTLIN CODE ASSIGNMENT
		
		Liskov Substition Principle
		https://en.wikipedia.org/wiki/Liskov_substitution_principle
		https://www.baeldung.com/java-liskov-substitution-principle

	ASSSIGNMENT A2 : ANDROID APPLICATION MODERN ARCHITECTURE READING AND THINKING
		https://developer.android.com/topic/architecture/domain-layer
		https://developer.android.com/topic/architecture/data-layer

__________________________________________________________________________



__________________________________________________________________________

FUTURE REFERENCES
__________________________________________________________________________


		Mythical Man-Month, The: Essays on Software Engineering, 
		Anniversary Edition Anniversary Edition, by Frederick Brooks Jr. 

		Structure And Interpretation Of Computer Program [ SICP BOOK ]
		Link : https://mitpress.mit.edu/sites/default/files/sicp/full-text/book/book.html


		Communicating Sequential Processes
		https://www.cs.cmu.edu/~crary/819-f09/Hoare78.pdf

		Continuation Concept
		https://jorgecastillo.dev/digging-into-kotlin-continuations

		Algorithms and Data Structure
		Books?????

__________________________________________________________________________
__________________________________________________________________________
