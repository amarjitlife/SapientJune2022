
Called to retrieve per-instance state from an activity before being killed so that the state can be restored in onCreate or onRestoreInstanceState (the Bundle populated by this method will be passed to both).


This method is called before an activity may be killed so that when it comes back some time in the future it can restore its state. 

For example, if activity B is launched in front of activity A, and at some point activity A is killed to reclaim resources, 

activity A will have a chance to save the current state of its user interface via this method so that when the user returns to activity A, the state of the user interface can be restored via onCreate or onRestoreInstanceState.

Do not confuse this method with activity lifecycle callbacks such as onPause, which is always called when the user no longer actively interacts with an activity, or onStop which is called when activity becomes invisible. 

One example of when onPause and onStop is called and not this method is when a user navigates back from activity B to activity A: there is no need to call onSaveInstanceState on B because that particular instance will never be restored, so the system avoids calling it. 

An example when onPause is called and not onSaveInstanceState is when activity B is launched in front of activity A: the system may avoid calling onSaveInstanceState on activity A if it isn't killed during the lifetime of B since the state of the user interface of A will stay intact.


The default implementation takes care of most of the UI per-instance state for you by calling View.onSaveInstanceState() on each view in the hierarchy that has an id, and by saving the id of the currently focused view (all of which is restored by the default implementation of onRestoreInstanceState). 

If you override this method to save additional information not captured by each individual view, you will likely want to call through to the default implementation, otherwise be prepared to save all of the state of each view yourself.

If called, this method will occur after onStop for applications targeting platforms starting with Build.VERSION_CODES.P. For applications targeting earlier platform versions this method will occur before onStop and there are no guarantees about whether it will occur before or after onPause.

Params:
outState – Bundle in which to place your saved state.
See Also:
onCreate, onRestoreInstanceState, onPause

//______________________________________________________________

Law Of Elimination

What Is a Game????

interface Playable {
	fun play()
}

interface GamePlayability() {
	fun start()
	fun progress()
	fun end()
}

abstract Class Game : Playable {
	fun play() {
	
	}
}

class Cricket : Game {
	val game: GamePlayability?

	fun play() {
		game.start()
		game.progress()
		game.end()
	}
}

What Is Cricket????

Cricket Is Game

an open-air game played on a large grass field with ball, bats, and two wickets, between teams of eleven players, the object of the game being to score more runs than the opposition.


Cricket is a bat-and-ball game played between two teams of eleven players each on a field at the centre of which is a 22-yard (20-metre) pitch with a wicket at each end, each comprising two bails balanced on three stumps. The game proceeds when a player on the fielding team, called the bowler, "bowls" (propels) the ball from one end of the pitch towards the wicket at the other end, with an "over" being completed once they have legally done so six times. The batting side has one player at each end of the pitch, with the player at the opposite end of the pitch from the bowler aiming to strike the ball with a bat. The batting side scores runs when either the bowler unfairly bowls the ball to the batter, the ball reaches the boundary of the field, or the two batters swap ends of the pitch, which results in one run. The fielding side's aim is to prevent run-scoring and dismiss each


// Minimum Viable Product


