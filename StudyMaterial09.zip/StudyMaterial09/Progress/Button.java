

import java.io.Serializable

interface View {
	public State getCurrentState()
	public void restoreState( State state )
}

interface State : Serializable {

}

class Button implements View {
	// Button Is Very Large Class
	// Having Lot Many Properties

	@Override
	public State getCurrentState() {
		return new ButtonState();
	}

	@Override
	public void saveState( State state ) {
		// 1. Serialise Object state Object
		// 2. Save The Serialised state Object In Persistent Store/Print Seralised Object
	}

	@Override
	public void restoreState( State state ) {

	}

	// INNER CLASS
	// Simple Class To Track Importanc State
	public class ButtonState implements State {
		// Only Important Button State
		// 		Which We Want To Persist
		// Is Part Of This Class 

		// Two Or Three Members
	}
}


//Business Logic

Button button = new Button()
ButtonState minimumState = new Button.ButtonState()

button.saveState( minimumState )
button.restoretate( minimumState )


	// @Override
	// public void saveState( State state ) {
	// 	// 1. Serialise Object state Object
	// 	// 2. Save The Serialised state Object In Persistent Store 		
	// 	// 					OR
	// 	// 1. Access Object States Through Property Getters 
	// 	// 2. And Save It With Key/Value Pairs In Persistent Store
		
	// }

