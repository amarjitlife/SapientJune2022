
package learnKotlin;


//_______________________________________________________________


class Person( val name: String, var isMarried: Boolean ) {
	// Method
	// 	Member Function
	fun dance( danceForm: String ) {
		println( "Doing Dance : $danceForm ..." )
	}

	fun singing( danceForm: String ) {
		println( "Doing Dance : $danceForm ..." )
	}
}

fun playWithPerson() {
	var person0 = Person( "Alice", false )

	println( person0.name ) 		// 	person0.getName() 
	println( person0.isMarried )	// 	person0.getIsMarried() 

	// Sending Message To Object person0
	person0.dance("Bharatnatyam!") 	// Is It Function Call???

	var person1 = Person( "Chandan", false )
	println( person1.name )			// 	person1.getName() 
	println( person1.isMarried ) 	// 	person1.getIsMarried() 

	person1.dance("Bhangraa!")

	person1.isMarried = true  		// 	person0.setIsMarried( true ) 
	println( person1.isMarried )    // 	person1.getIsMarried() 	
}


//_______________________________________________________________


//_______________________________________________________________
//_______________________________________________________________
//_______________________________________________________________
//_______________________________________________________________
//_______________________________________________________________
//_______________________________________________________________
// Experiment Following Code, MOMENT DONE >>> RAISE YOUR HANDS!!!

fun main() {
	// println("\nFunction : ")
	// println("\nFunction : ")	
	// println("\nFunction : ")	
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")	
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")	
	// println("\nFunction : ")
	// println("\nFunction : ")	
	// println("\nFunction : ")	
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")	
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")	
}
