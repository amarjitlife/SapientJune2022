
/*
kotlinc Hello.kt -include-runtime -d hello.jar
java -jar hello.jar 
*/


package learnKotlin

fun main() {
	println("Hello World!\n")
}


// Kotlin Compiler Will Generate Following Java Code
// package learnJava;

// class HelloKt {
// 	public static void main( String[] args ) {
// 		System.out.println("Hello World!\n");	
// 	}
// }


