
/*
kotlinc KotlinLambdasAndHoFs.kt -include-runtime -d lambdas.jar
java -jar lambdas.jar 
*/

package learnKotlin

//_______________________________________________________________

data class Person( val name: String, val age : Int )

fun findTheOldest( persons : List<Person> ) : Person {
	var maxAge = 0
	var theOldest: Person? = null

	for ( person in persons ) {
		if ( person.age > maxAge ) {
			maxAge = person.age
			theOldest = person
		}
	}
	
	return if ( theOldest != null ) theOldest else Person(name = "Unspecified", age = 0 )
}

fun playWithTheOldest() {
	val persons = listOf( Person("Alice", 20), Person( "Martin", 60), Person("Bon", 40) )

	println( findTheOldest( persons ) )
}

//_______________________________________________________________

fun playWithLocalScopesUsingLambdas() {
	var something = 10
	println( something )

	val ding = { // Lambda Expression
		@Suppress("NAME_SHADOWING")
		var something = 22 ;
		println( something ) ;
	
		something = 222 ;
		println( something ) ;
	}
	ding()	
}

//_______________________________________________________________
// Experiment Following Code, MOMENT DONE >>> RAISE YOUR HANDS!!!

fun playWithLambdaExpressions() {
	val sum = { x : Int, y : Int -> x + y }

	println( sum(10, 30) )
	println( sum(100, 2000) )

	var simpleLambda = { println(44) }
	simpleLambda()

	val persons = listOf( Person("Alice", 20), Person( "Martin", 60), Person("Bon", 40),
						Person("Chandan", 30), Person("Shubhra", 28) )

	val names = persons.joinToString( separator = " ", 
										transform = { person: Person -> person.name } )
	val ages = persons.joinToString( separator = " ", 
										transform = { person: Person -> person.age.toString() } )
	println("Names : $names")
	println("Ages  : $ages")

	// maxBy Function Taking One Argument i.e. Lambda
	var maxAge = persons.maxBy( { person: Person -> person.age } )
	println("Max Age  : $maxAge")

	// maxBy Function Taking One Argument i.e. Lambda. It's Called Trailing Lambda
	maxAge = persons.maxBy { person: Person -> person.age } 
	println("Max Age  : $maxAge")

	maxAge = persons.maxBy { 
		person: Person -> person.age 
	} 
	println("Max Age  : $maxAge")

	// maxBy Function Taking One Argument i.e. Lambda. It's Called Trailing Lambda
	// Type Of The Lambda Arguemnt Can Be Inferred From Collections
	maxAge = persons.maxBy { person -> person.age } 
	println("Max Age  : $maxAge")

	// maxBy Function Taking One Argument i.e. Lambda. It's Shortcut Syntax
	// Lamdba Taking One Argument Can Be Accessed Using Predefined Term i.e. it
	maxAge = persons.maxBy { it.age } 
	println("Max Age  : $maxAge")

	val getAge = { person: Person -> person.age }
	maxAge = persons.maxBy( getAge ) 
	println("Max Age  : $maxAge")

	val nameToAge = listOf("Alice" to 42, "Bob" to 28, "Carol" to 51)
	val oldestPerson = nameToAge.maxByOrNull { it.second }
	println(oldestPerson) // (Carol, 51)

	val emptyList = emptyList<Pair<String, Int>>()
	val emptyMax  = emptyList.maxByOrNull { it.second }
	println(emptyMax) // null
}

//_______________________________________________________________
// Experiment Following Code, MOMENT DONE >>> RAISE YOUR HANDS!!!

fun sum(x : Int, y : Int ) : Int  { return  x + y }
fun sub(x : Int, y : Int ) : Int  { return  x - y }
fun mul(x : Int, y : Int ) : Int  { return  x * y }
fun div(x : Int, y : Int ) : Int  { return  x / y }

// Polymorphism
// Polymorphic Function

// Higer Order Functions
//		HoF Are Functions Which Can Take Functions As Arguments
//				AND/OR
//		Can Return Functions From Function
fun calculator(x : Int, y : Int, operation: (Int, Int) -> Int ) : Int {
	return operation( x, y )
}

fun playWithCalculator() {
	val xx = 40
	val yy = 10
	var result: Int 

	result = calculator( xx, yy, ::sum )
	println( "Result : $result" )

	result = calculator( xx, yy, ::sub )
	println( "Result : $result" )

	result = calculator( xx, yy, ::mul )
	println( "Result : $result" )

	result = calculator( xx, yy, ::div )
	println( "Result : $result" )

	// What Is The Type Of something
	val something = ::sum 	// Type Inferred From RHS Is (Int, Int)-> Int 
	result = something( 900, 90 )
	println( "Result : $result" )

	// What Is The Type Of somethingMore
	// 	Type Inferred From RHS Is (Int, Int, (Int, Int)-> Int ) -> Int
	val somethingMore: (Int, Int, (Int, Int)-> Int ) -> Int = ::calculator
	result = somethingMore( 900, 90, ::sum )
	println( "Result : $result" )
}

//_______________________________________________________________
// Experiment Following Code, MOMENT DONE >>> RAISE YOUR HANDS!!!

// Higer Order Functions
//		HoF Are Functions Which Can Take Functions As Arguments
//				AND/OR
//		Can Return Functions From Function
// Function Type (Int) -> Int
fun moveForward( start : Int ) : Int {
	return start + 1 
}
// Function Type (Int) -> Int
fun moveBackward( start : Int ) : Int {
	return start - 1 
}

// Higher Order Function : Function Returning Function
// Function Type : (Boolean) -> (Int) -> Int
fun chooseSteps( forwards : Boolean ) : (Int) -> Int  {
	return if ( forwards ) ::moveForward else ::moveBackward
} 

fun playWithChooseSteps() {
	var start = 100

	// What Is Type Of move???
	//			RHS Return Type Is (Int) -> Int 
	var move: (Int) -> Int = chooseSteps( forwards = true )
	start = move( start )
	println( start ) 

	start = move( start )
	println( start ) 

	start = move( start )
	println( start ) 

	start = 100

	move = chooseSteps( forwards = false )
	start = move( start )
	println( start ) 

	start = move( start )
	println( start ) 

	start = move( start )
	println( start ) 

	val something : (Int) -> Int = ::moveForward
	println(something)

	// What Is Type Of somethingAgain???
	val somethingAgain: (Boolean) -> (Int) -> Int = ::chooseSteps
	println(somethingAgain)
}


//_______________________________________________________________
// Experiment Following Code, MOMENT DONE >>> RAISE YOUR HANDS!!!

// Higher Order Function : Function Returning Function
// Function Type : (Boolean) -> (Int) -> Int

fun chooseStepsAgain( forwards : Boolean ) : (Int) -> Int  {
	fun moveForward( start : Int )  : Int {  return start + 1  }
	fun moveBackward( start : Int ) : Int {  return start - 1  }

	return if ( forwards ) ::moveForward else ::moveBackward
} 

fun playWithChooseStepsAgain() {
	var start = 100

	// What Is Type Of move???
	//			RHS Return Type Is (Int) -> Int 
	var move: (Int) -> Int = chooseStepsAgain( forwards = true )
	start = move( start )
	println( start ) 

	start = move( start )
	println( start ) 

	start = move( start )
	println( start ) 

	start = 100

	move = chooseStepsAgain( forwards = false )
	start = move( start )
	println( start ) 

	start = move( start )
	println( start ) 

	start = move( start )
	println( start ) 

	// What Is Type Of somethingAgain???
	val somethingAgain: (Boolean) -> (Int) -> Int = ::chooseStepsAgain
	println(somethingAgain)
}

//_______________________________________________________________
// Experiment Following Code, MOMENT DONE >>> RAISE YOUR HANDS!!!

fun chooseStepsOnceAgain( forwards : Boolean ) : (Int) -> Int  {
	val moveForward  = {  start : Int -> start + 1  }
	val moveBackward = {  start : Int -> start - 1  }

	return if ( forwards ) ::moveForward else ::moveBackward
} 

fun playWithChooseStepsOnceAgain() {
	var start = 100

	// What Is Type Of move???
	//			RHS Return Type Is (Int) -> Int 
	var move: (Int) -> Int = chooseStepsOnceAgain( forwards = true )
	start = move( start )
	println( start ) 

	start = move( start )
	println( start ) 

	start = move( start )
	println( start ) 

	start = 100

	move = chooseStepsOnceAgain( forwards = false )
	start = move( start )
	println( start ) 

	start = move( start )
	println( start ) 

	start = move( start )
	println( start ) 

	// What Is Type Of somethingAgain???
	val somethingAgain: (Boolean) -> (Int) -> Int = ::chooseStepsOnceAgain
	println(somethingAgain)
}

//_______________________________________________________________
//_______________________________________________________________
//_______________________________________________________________
//_______________________________________________________________
//_______________________________________________________________
//_______________________________________________________________
// Experiment Following Code, MOMENT DONE >>> RAISE YOUR HANDS!!!

fun main() {	
	println("\nFunction : playWithTheOldest")
	playWithTheOldest()

	println("\nFunction : playWithLocalScopesUsingLambdas")
	playWithLocalScopesUsingLambdas()

	println("\nFunction : playWithLambdaExpressions")
	playWithLambdaExpressions()

	println("\nFunction : playWithCalculator")
	playWithCalculator()

	println("\nFunction : playWithChooseSteps")
	playWithChooseSteps()

	println("\nFunction : playWithChooseStepsAgain")
	playWithChooseStepsAgain()

	println("\nFunction : playWithChooseStepsOnceAgain")
	playWithChooseStepsOnceAgain()

	// println("\nFunction : ")	
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")	
	// println("\nFunction : ")
	// println("\nFunction : ")
}

/*
kotlinc KotlinLambdasAndHoFs.kt -include-runtime -d lambdas.jar
java -jar lambdas.jar 
*/