/*
kotlinc KotlinClassesMore.kt -include-runtime -d classesMore.jar
java -jar classesMore.jar 
*/

package learnKotlin;

					// Primary Constructor
data class Subject( val name: String, val grade: Char,  val points: Double, var credits: Double )

				// Primary Constructor
data class Game( val name : String, var grade : Char, var points: Double )

			// Primary Constructor
// class Person( var firstName: String, var lastName: String ) {
open class Person constructor( var firstName: String, var lastName: String ) {
	fun fullName(): String {
		return "$firstName $lastName"
	}
}

fun playWithPerson() {
	val alice = Person("Alice", "Carol")
	println( alice.fullName() ) 

	val martin = Person("Matrin", "Gupta")
	println( martin.fullName() ) 
}

//_______________________________________________________________

// New Things...
// 		1. Parent Constructor Called With Arguments
//		2. MutableList<Subject>
//		3. Student Constructor Defines Constructor Signature Only
//				Doesn't Define New Properies
//				Doesn't Redefine Properies Form Parent Type i.e. Person
//				Resuing Person Properties
//				Propeties Initialiation Is Delegated To Parent Constructor

// error: 'firstName' hides member of supertype 'Person' and needs 'override' modifier
// error: 'lastName' hides member of supertype 'Person' and needs 'override' modifier
// class Student( val firstName : String, val lastName: String ) : Person( firstName, lastName ) {

open class Student( firstName : String, lastName: String ) : Person( firstName, lastName ) {
 	val passedSubjects: MutableList<Subject> = mutableListOf<Subject>()
 	val failedSubjects: MutableList<Subject> = mutableListOf<Subject>()

 	fun recordGrades( subject : Subject ) {
 		if ( subject.grade == 'F' ) {
 			failedSubjects.add( subject )
 		} else {
 			passedSubjects.add( subject )
 		}
 	}

 	open fun printGrades() {
 		for ( subject in passedSubjects ) {
 			println("\t $subject")
 		}

 		for ( subject in failedSubjects ) {
 			println("\t $subject")
 		}
 	}	
}


// data class Subject( val name: String, val grade: Char,  val points: Double, var credits: Double )

fun playWithStudent() {

	val martin 	= Student("Martin", "Gupta")
	val pravin 	= Student("Pravin", "Bhole")

	println( martin )
	println( pravin )

	val alice 	= Student("Alice", "Carols")
	val gabbar  = Student("Gabbar", "Singh")

	val aliceEnglish = Subject( name = "English", grade = 'A', points = 9.0, credits = 3.0 )
	val aliceDance 	= Subject( name = "Dance", grade = 'B', points = 7.0, credits = 2.0 )
	val aliceKotlin = Subject( name = "Koltin", grade = 'C', points = 6.0, credits = 3.0 )

	alice.recordGrades( aliceEnglish )
	alice.recordGrades( aliceDance )
	alice.recordGrades( aliceKotlin )

	val gabbarDecoit = Subject( name = "Decoit", grade = 'A', points = 9.0, credits = 3.0 )
	val gabbarShooting 	= Subject( name = "Shooting", grade = 'B', points = 8.0, credits = 3.0 )
	val gabbarLooting = Subject( name = "Looting", grade = 'D', points = 5.0, credits = 0.0 )
	
	gabbar.recordGrades( gabbarDecoit )
	gabbar.recordGrades( gabbarShooting )
	gabbar.recordGrades( gabbarLooting )

	alice.printGrades()
	gabbar.printGrades()
}


//_______________________________________________________________

// data class Game( val name : String, var grade : Char, var points: Double )

class StudentAthlete( firstName: String, lastName: String ) : Student( firstName, lastName ) {
	val gamesPlayed = mutableListOf<Game>()

	fun recordGames( game: Game ) {
		gamesPlayed.add( game )
	}

	override fun printGrades() {
		super.printGrades()

		for ( game in gamesPlayed ) {
			println("\t $game")
		}
	}
}

fun playWithStudentAtheletes() {
	val martin 	= StudentAthlete("Martin", "Gupta")
	val pravin 	= StudentAthlete("Pravin", "Bhole")

	// data class Game( val name : String, var grade : Char, var points: Double )
	val martinChess 	= Game( name = "Chess", grade = 'A', points = 9.0 )
	val martinBadminton = Game( name = "Badminton", grade = 'D', points = 5.0 )

	martin.recordGames( martinChess )
	martin.recordGames( martinBadminton )

	val pravinChess 	= Game( name = "Chess", grade = 'B', points = 8.0 )
	val pravinKabbadi 	= Game( name = "Kabbadi", grade = 'A', points = 10.0 )
	
	pravin.recordGames( pravinChess )
	pravin.recordGames( pravinKabbadi )

	martin.printGrades()
	pravin.printGrades()
}

//_______________________________________________________________

// error: modifier 'open' is incompatible with 'data'
open class BandMember( firstName : String, lastName: String, val instrument: String = "" ) : Student( firstName, lastName ) {
	// Overriding Property From Parent Type
	// Compiler Will Generate Getter With Body get() { return 2 }
	open val minimumPracticeTime: Int = 2

	// open val minimumPracticeTime: Int 
	// 	get() { return 2 } 		// Custom Getter Written By Programmer

	// Getter Will Get Called Whenever You Access Property
}

// error: data class primary constructor must only have property (val / var) parameters
class GuitarPlayer( firstName: String, lastName: String, instrument: String = "Guitar" ) : BandMember( firstName, lastName, instrument ) {
	// Overriding Property From Parent Type
	override val minimumPracticeTime: Int
		get() = super.minimumPracticeTime * 2	//Custom Getter With Custom Logic
}

fun playWithBandMembers() {
	val alice = BandMember(firstName = "Alice", lastName = "Carols", instrument = "Not Decided" )
	val martin = BandMember(firstName = "Martin", lastName = "Gupta", instrument = "Not Decided" )

	println( alice.fullName() )
	println( martin.fullName() )

	val chandan = GuitarPlayer(firstName ="Chandan", lastName = "Yadav")
	val subhara = GuitarPlayer(firstName ="Subhara", lastName = "Swain")

	println( chandan.fullName() )
	println( subhara.fullName() )
}

//_______________________________________________________________
// Experiment Following Code, MOMENT DONE >>> RAISE YOUR HANDS!!!

fun playWithRuntimeTypeCheck() {

	val guitarPlayer = GuitarPlayer(firstName ="Chandan", lastName = "Yadav")
	var hallMonitor: Student =  Student(firstName = "Thakur", lastName = "Boss" )

	var personMonitor: Person

	println( guitarPlayer.fullName() )
	println( hallMonitor.fullName() )

	//
	hallMonitor 	= guitarPlayer
	personMonitor 	= guitarPlayer

	var result: Boolean 
	result = hallMonitor is GuitarPlayer
	println( result )

	result = hallMonitor is BandMember
	println( result )

	result = hallMonitor is Student
	println( result )

	result = hallMonitor is Person
	println( result )

	result = hallMonitor is StudentAthlete
	println( result )

	result = hallMonitor !is StudentAthlete
	println( result )

	// as And as? Can Be Used To Type Casting
	var minimumPracticeTime : Int?

	// minimumPracticeTime = (guitarPlayer as Student).minimumPracticeTime

	// RECHECK FOLLOWING LINE CODE
	minimumPracticeTime = hallMonitor.minimumPracticeTime
	println( minimumPracticeTime )

	minimumPracticeTime = ( hallMonitor as? GuitarPlayer )?.minimumPracticeTime
	println( minimumPracticeTime )
}

//_______________________________________________________________
// Experiment Following Code, MOMENT DONE >>> RAISE YOUR HANDS!!!

// FUNCTION OVERLOADING
fun afterClassActivity( student : Student ) {
	val fullName = student.fullName()
	println( "$fullName Goes Home!" )
}

fun afterClassActivity( student : BandMember ) {
	val fullName = student.fullName()
	println( "$fullName Goes To Practice!" )
}

fun Student.afterClassActivityExtension() {
	val fullName = this.fullName()
	println( "$fullName Goes Home!" )
}

fun BandMember.afterClassActivityExtension() {
	val fullName = this.fullName()
	println( "$fullName Goes To Practice!" )
}

fun playWithAfterClassActivity() {
	val alice = BandMember(firstName = "Alice", lastName = "Carols", instrument = "Not Decided" )
	val martin = BandMember(firstName = "Martin", lastName = "Gupta", instrument = "Not Decided" )

	afterClassActivity( alice )
	afterClassActivity( martin )

	alice.afterClassActivityExtension()
	martin.afterClassActivityExtension()

	val chandan = GuitarPlayer(firstName ="Chandan", lastName = "Yadav")
	val subhara = GuitarPlayer(firstName ="Subhara", lastName = "Swain")

	afterClassActivity( chandan )
	afterClassActivity( subhara )
	chandan.afterClassActivityExtension()
	subhara.afterClassActivityExtension()

	val pravin 	= Student("Pravin", "Bhole")
	afterClassActivity( pravin )
	pravin.afterClassActivityExtension()
}

//_______________________________________________________________
// Experiment Following Code, MOMENT DONE >>> RAISE YOUR HANDS!!!

//					// Declaration Of birthPlace Property
abstract class Mammal( val birthPlace : String ) {
	abstract fun consumeFood() 
}

class Human( birthPlace : String ) : Mammal( birthPlace ) {
	override fun consumeFood() {
		println("Human Consuming Food! ")
	}

	fun createBiirthCertificate() {
		println( "Birth Certificate Having Birth At $birthPlace" )
	}
}

fun playWithAbstractClasses() {
	val human = Human( birthPlace = "Bangalore" )

	human.consumeFood()
	human.createBiirthCertificate()
}

//_______________________________________________________________

// DESIGN PRICIPLES
//		YOU SHOULD NOT PAY FOR IT IF YOU ARE NOT USING IT

//		e.g. C/C++ Language Design -> Design Towards Perforance

// Constructor Purpose
//		To Initialise Object To A Legal/Usable State [ As Per Domain/Model ]
//				Constructors Must Initialise Object To Legal State
//					Minimum Number Of Properties To Be Initiatlised
//									To
//					All Properties To Be Initialised Best Case
//				1. Allocation
//				2. Initialiation
//				3. Deinitialisation
//				4. Deallocation			
//				Business Logic In Constructor Is Bad Design
//					Refactor Code -> Move Business Logic Out Of Constructor
//		Always Prefer Constructors With Default Arugments
//			Rather Than Overloading Constuctors
//				Overloading Constructors Can Create Semantic Mess

//	Most Common Myth : Constructor Creates The Object

// Object Creation Is Two Step Process
//		1. Obejct Get Allcated In Memory 		( Happens Before Cosntructor Call With new ) 
//		2. Obejct Properties Get Initialised 	( Happens On Constructor Call ) 
//			Default Values Getting Initialised  [ Langauge Defaults For Specific Types ]
//		    Model/Domain Initialation

// Object Deallocation Is Two Step Process
//		1. Obejct Get Deinitialised In Memory  	( Happens On Distrutructor Call [ Optional Language Specific ] )
//		2. Obejct Get Deallocated 				( Happens After Destructor ) 

// Constructors In Inheritance
//		Child Class Properties Coming From Mutiple Classes Initialised In Following Order
//			Must Be Intialised By There Correspoing Parent Classes First
//				First Line In Child Class Constructor Should Be super.ParentConstrctor(.....)
//			Than Child Class Can Customise Some Of The Properties Coming From Parent Class
//				Means Assigns Some Of The Properties You Want To Change/Customised

// Object Creation With Policy Design
//		Want To Apply Some Policy
//			e.g. Only One Instance Going To Be Existing and Reused
//				Singleton Design Pattern
//				Pool Design Pattern
//		1. Make Cosntructor Private
//		2. Provide Type Level Method (static) To Create Objects
//				Objects Created Under Specific Policy  

// val personObject = Person( firstName = "Tom", lastName = "Moody")

//_______________________________________________________________

// DRY PRACTICE
//		Don't Repeat Yourself

// SECONDARY CONSTRCUTORS

enum class Color {
	RED, GREEN, BLUE, YELLOW, ORANGE, UNKONWN
}

open class Shape {
	var size : Int 
	var color : Color 

	// Seondary Constructors
	constructor( size : Int ) {
		this.size 	= size
		// error: property must be initialized or be abstract
		// this.color 	= Color.BLUE
		this.color 	= Color.UNKONWN		
		println("Shape : Secondary Constructor 1 Called")
	}

	// Seondary Constructors Design Choice 1
	constructor( size : Int, color: Color ) : this( size ) {
		this.color = color 
		println("Shape : Secondary Constructor 2 Called")
	}

	// Seondary Constructors Design Choice 2
	// constructor( size : Int, color: Color ) {
	// 	this.size = size
	// 	this.color = color 
	// 	println("Shape : Secondary Constructor 2 Called")
	// }

	// override fun toString() = "Shape(size=$size, color=$color") + color
	override fun toString() = "Shape(size=$size, color=" + color + ")"
}

class Circle : Shape {
	var centerX : Int 
	var centerY : Int 

	constructor( size : Int ) : super( size ) {
		// Intitialse Parent Properties super()...

		// Child Properties Initialisation
		this.centerX = 0
		this.centerY = 0
		println("Circle : Secondary Constructor 1 Called")
	
		//Customisation Of Parent Properties At Child Class
		this.size = 99
	}

	constructor( size : Int, color: Color ) : super( size, color ) {
		this.centerX = 0
		this.centerY = 0
		println("Circle : Secondary Constructor 2 Called")
	}

	override fun toString() = "Circle(size=$size, color=$color, center=($centerX, $centerY))"
}

fun playWithSecondaryConstructors() {
	val shape1 = Shape( size = 10 )
	val shape2 = Shape( size = 10, color = Color.RED  )

	println( shape1 )
	println( shape2 )

	val circle1 = Circle( size = 10 )
	val circle2 = Circle( size = 10, color = Color.RED  )

	println( circle1 )
	println( circle2 )
}


//_______________________________________________________________


// enum class Color {
// 		RED, GREEN, BLUE, YELLOW, ORANGE, UNKONWN
// }

// CONSTRUCTORS CALL FLOW DESIGN
//		0. Construct Consistent Objects Through All Constructors Call Flows 
//		1. Desginate One Constructor In Class As MAIN Constructor
//				MAIN Constructor Will Instialiase All Properties Of The Class
//		2. All Other Constructors In Same Class Should Call MAIN Constructor Same Class
//		3. MAIN Constructor From Child Class Should Call MAIN Constrcutor From Parent Class

class Point(var centerX: Int = 0, var centerY: Int = 0 ) {
	override fun toString() = "Point(centerX=$centerX, centerY=$centerY"
}

open class ShapeAgain {
	var size : Int 
	var color : Color 

	// MAIN COSNTRUCTOR - Constructor Initialising Maximumm Number Of Properties
	// Seondary Constructors Design Choice 1
	constructor( size : Int, color: Color ) {
		this.size 	= size
		this.color 	= color 
		println("ShapeAgain : MAIN Secondary Constructor 1 Called")
	}

	// For Programmer/User's Convenience 
	// Seondary Constructors
	constructor( size : Int ) : this( size, color = Color.UNKONWN ) {
		// this.size 	= size
		// this.color 	= Color.UNKONWN		
		println("ShapeAgain : Secondary Constructor 2 Called")
	}

	// override fun toString() = "Shape(size=$size, color=$color") + color
	override fun toString() = "ShapeAgain(size=$size, color=" + color + ")"
}

class CircleAgain : ShapeAgain {
	var center : Point
	// MAIN COSNTRUCTOR - Constructor Initialising Maximumm Number Of Properties
	constructor( size : Int, color: Color, center: Point ) : super( size, color ) {
		this.center = center
		println("CircleAgain : MAIN Secondary Constructor 1 Called")
	}

	constructor( size : Int ) : this( size, color = Color.UNKONWN, center = Point(0, 0) ) {
		println("CircleAgain : Secondary Constructor 2 Called")
	}

	constructor( size : Int, color: Color ) : this( size, color, center = Point(0, 0) ) {
		println("CircleAgain : Secondary Constructor 3 Called")
	}

	override fun toString() = "CircleAgain(size=$size, color=$color, center=$center)"
}

fun playWithSecondaryConstructorsDelegationDesign() {
	val shape1 = ShapeAgain( size = 10 )
	val shape2 = ShapeAgain( size = 10, color = Color.RED  )

	println( shape1 )
	println( shape2 )

	val circle1 = CircleAgain( size = 80  )
	val circle2 = CircleAgain( size = 90, color = Color.RED  )
	val circle3 = CircleAgain( size = 99, color = Color.RED, center = Point( 88, 99) )

	println( circle1 )
	println( circle2 )
	println( circle3 )
}

// CODE BUNK LINK

//_______________________________________________________________

// NESTED And INNER CLASSES IN KOTLIN

// In Java Inner Classes
// 		Class Defined Inside Class Are Inner Classes By Default

// In Java Nested Classes
// 		Class Defined Inside Class Are Explicity Made Nested By Using static Keyoword
//		static Classes Defined Inside Class In Java Are Nested Classes

class Car( val carName: String ) {	 // Enclosing Context
	val carType : String
		get() { return "Unknown Type!" }

	// In Kotlin 
	// 		Class Defined Inside Class Are Nested Classes By Default
	// NESTED CLASS
	// 		Class Defined Inside Class
	//		It CANNOT Capture Enclosing Context
	// 			Enclosed Context CANNOT Access Enclosing Context Data
	//			i.e. Classed Defined Inside Enclosing Class Cann't Access Data From Enclosing Class
	class Engine( val engineName: String ) { // Enclosed Context
		override fun toString() : String {
			// error: unresolved reference: carName
			// error: unresolved reference: carType
			// return "$carName Have $engineName And Car Type Is $carType"	
			return "$engineName"	
		}

		val engineRPM: Int 
			get() { return 1000 }
		
		fun startEngine() = println("Starting Engine")
		fun stopEngine()  = println("Stoping  Engine")
	}

	fun playWithInsideClass() {
		val marutiEngine = Car.Engine( engineName = "Fiat Engine 1200 cc")
		println( marutiEngine )
		println( marutiEngine.engineRPM )
	}

	override fun toString() = "Car(carName=$carName, carType=$carType)"
}

class CarAgain( val carName: String ) { // Enclosing Context
	val carType : String
		get() { return "Unknown Type!" }

	// In Kotlin 
	// 		Class Defined Inside Class Are MADE EXPLICITY INNER Classes
	//		By Using inner Keyowrk
	// INNER CLASS
	// 		Class Defined Inside Class
	//		It CAN Capture Enclosing Context
	// 			Enclosed Context CAN Access Enclosing Context Data
	//			i.e. Classed Defined Inside Enclosing Class CAN Access Data From Enclosing Class
	inner class Engine( val engineName: String ) { // Enclosed Context
		override fun toString() : String {
			// return "$engineName"	
			// error: unresolved reference: carName
			return "$carName Have $engineName And Car Type Is $carType"	
		}

		val engineRPM: Int 
			get() { return 1000 }

		fun startEngine() = println("Starting Engine")
		fun stopEngine()  = println("Stoping  Engine")
	}

	override fun toString() = "Car(carName=$carName, carType=$carType)"
}

fun playWithClassesDefinedInsideClasses() {
	val marutiCar	 = Car( carName = "Maruti Swift" )
	val marutiEngine = Car.Engine( engineName = "Fiat Engine 1200 cc")

	println( marutiCar )
	println( marutiEngine )
	println( marutiEngine.engineRPM )

	marutiEngine.startEngine()
	marutiEngine.stopEngine()

	val toyotaCar 	 = CarAgain( carName = "Toyota Fortuner" )
	// error: constructor of inner class Engine can be called only with receiver of containing class
	// val toyotaEngine = CarAgain.Engine( engineName = "Toyata Engine 3000 cc")
	val toyotaEngine = toyotaCar.Engine( engineName = "Toyata Engine 3000 cc")

	println( toyotaCar )
	println( toyotaEngine )

	println( toyotaEngine.engineRPM )
	toyotaEngine.startEngine()
	toyotaEngine.stopEngine()
}

//_______________________________________________________________


// WHAT IS PURPOSE OF THIS HELL ABOUT NESTED/INNER CLASSES???
// 		Bhasavaraj Kotagond

// HOW OUTER CLASS ACCESS INNER/NESTED CLASS this
//		Arvindhan Ahokan

//_______________________________________________________________
//_______________________________________________________________
//_______________________________________________________________
//_______________________________________________________________
// Experiment Following Code, MOMENT DONE >>> RAISE YOUR HANDS!!!

fun main() {	
	println("\nFunction : playWithPerson")
	playWithPerson()

	println("\nFunction : playWithStudent")
	playWithStudent()

	println("\nFunction : playWithStudentAtheletes")
	playWithStudentAtheletes()

	println("\nFunction : playWithBandMembers")
	playWithBandMembers()

	println("\nFunction : playWithRuntimeTypeCheck")
	playWithRuntimeTypeCheck()

	println("\nFunction : playWithAfterClassActivity")
	playWithAfterClassActivity()

	println("\nFunction : playWithAbstractClasses")
	playWithAbstractClasses()

	println("\nFunction : playWithSecondaryConstructors")
	playWithSecondaryConstructors()

	println("\nFunction : playWithSecondaryConstructorsDelegationDesign")
	playWithSecondaryConstructorsDelegationDesign()

	println("\nFunction : playWithClassesDefinedInsideClasses")
	playWithClassesDefinedInsideClasses()

	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")	
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")	
}
