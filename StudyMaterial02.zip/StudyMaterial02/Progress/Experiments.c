#include <stdio.h>
#include <stdlib.h>
#include <limits.h>

//_______________________________________________________________

int playWithIfElseConstruct() {
	int a = 10;
	int b = 20;
	int x = 0;

	// if-else Is A Statement
	// Code 1
	// x = if ( a == 10 ) {
	if ( a == 10 ) {
		a;
	} else {
		b;
	}

	// Ternary Operator
	// ( ) ? : ;
	// Code 2
	// Expression
	x = ( a == 10 ) ? a : b ;
}

//_______________________________________________________________

// BAD CODE - BAD DESIGN
int sumOld(int x, int y) {
	return x + y;
}

// BAD CODE
// int factorial( int n ) {
// 	int result = 1;

// 	if ( n < 0 ) {
// 		printf("\nFactorial Doesn't Exists For Negative Integers!");
// 		return;
// 	}
	
// 	if ( n == 0 or n == 1 ) return 1;
// 	else n * factorial( n - 1 );
// }

//_______________________________________________________________
// Experiment Following Code, MOMENT DONE >>> RAISE YOUR HANDS!!!

// VALID ARITHEMATIC SUM
// #include <limits.h>

// Platform Indepent Code
// Type Safe Code  
signed int sum( signed int a, signed int b ) {
	signed int result = 0;
	
	// Respecting Type Definition
	if (((b > 0) && (a > (INT_MAX - b))) ||
	  	((b < 0) && (a < (INT_MIN - b)))) {
	
		/* Handle error */
  		printf("\nCan't Calcualate Arithmatic Sum Of Given Values");
  		exit( 1 );
  	} else {  // Result Is Closed In int Type Range
		result = a + b;
  	}

	return result;
  	/* ... */
}


//_______________________________________________________________
//_______________________________________________________________
//_______________________________________________________________
//_______________________________________________________________
//_______________________________________________________________
// Experiment Following Code, MOMENT DONE >>> RAISE YOUR HANDS!!!


int main() {
	int result;

	result = sumOld(100, 200);
	printf("\nResult : %d", result );

	result = sumOld( 30000, 30000 );
	printf("\nResult : %d", result );

	result = sumOld( 2147483647, 2 );
	printf("\nResult : %d", result );

	result = sumOld( -2147483647, -2 );
	printf("\nResult : %d", result );

	result = sumOld(  2147000000, 2147000000 );
	printf("\nResult : %d", result );

	result = sum( 2147483647, 2147483647);
	printf("\nResult : %d", result );

	// Result : 300
	// Result : 60000
	// Result : -2147483647
	// Result : 2147483647
}

