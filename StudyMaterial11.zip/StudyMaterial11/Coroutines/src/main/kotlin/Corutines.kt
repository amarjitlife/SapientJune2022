package learnCoroutines

import kotlinx.coroutines.*
import java.lang.Thread.sleep

// DESIGN PRINCIPLE
//      DESIGN TOWARDS CONCURRENCY RATHER THAN PARALLELISM
//      i.e. Model System At Abstract Level
//      As A Set Of Concurrent Tasks i.e Coroutines
/*

> A _coroutine_ is an instance of suspendable computation.

It is conceptually similar to a thread, in the sense that it
takes a block of code to run that works concurrently with
the rest of the code.

However, a coroutine is not bound to any particular thread.
It may suspend its execution in one thread and resume in another one.

Coroutines can be thought of as light-weight threads,
but there is a number of important differences that make
their real-life usage very different from threads.

# COROUTINE BUILDER

[launch] is a _coroutine builder_.
It launches a new coroutine concurrently with
the rest of the code, which continues to work independently

[runBlocking] is also a coroutine builder
that bridges the non-coroutine world of a regular `fun main()` and
the code with coroutines inside of `runBlocking { ... }` curly braces.

[delay] is a special _suspending function_.
It _suspends_ the coroutine for a specific time.

>   Suspending a coroutine does not _block_ the underlying thread, but allows
>   other coroutines to run and use the underlying thread for their code.

The name of `runBlocking` means that the thread that runs it
(in this case the main thread) gets _blocked_ for
the duration of the call, until all the
coroutines inside `runBlocking { ... }` complete their execution.

// BEST PRACTICE
`runBlocking` used like that at the very top-level of the application
 and quite rarely inside the real code, as threads are expensive resources
 and blocking them is inefficient and is often not desired.

// STRUCTURED CONCURRENCY

Coroutines follow a principle of **structured concurrency** which
means that new coroutines can be only launched in a specific
[CoroutineScope] which delimits the lifetime of the coroutine.

In a real application, you will be launching a lot of coroutines.
Structured concurrency ensures that they are not lost and do not leak.

>   An outer scope cannot complete until all its children coroutines complete.

Structured concurrency also ensures that
any errors in the code are properly reported and
are never lost.

// RESOURCES Managed By Operating System
//      Files, Threads, Processes, Sockets, Pipes, Semaphores, Mutexes etc...
    FILE fileDescriptor = fopen("FileName.txt", "r");
    // In Finally Block You Must Free Up Resources
    fclose();
    Thread thread = new Thread()

*/

//-------------------------------------------------------------------------
//-------------------------------------------------------------------------

// Created Two Concurrent Coroutines
// In this case main Is Just Function Call
//fun main() {

// main Assigned A Coroutine Returned By runBlocking Coroutine Builder
//     Hence main itself becomes Coroutine
//fun main() = runBlocking {
//    // launch Will Create A New Coroutine
//    println("runBlocking Created Coroutine!")
//
//    // launch Coroutine Builder Is An Extension Function On CoroutineScope
//    launch {
//        println("launch Created Coroutine!")
//        delay( 1000L )
//        println( "World!" )
//    }
//
////    delay( 1000L )
//    println("Hello!")
//    // It Will Be Blocked Till Other Coroutine Completes It!
//    //       Because That Is The Nature Of Coroutine
//    //       Created By runBlocking Coroutine Builder
//}

//-------------------------------------------------------------------------
//-------------------------------------------------------------------------

/*
When you perform "Extract function" refactoring on this code,
you get a new function with the `suspend` modifier.
Suspending functions can be used inside coroutines
just like regular functions, but their additional feature
is that they can, in turn, use other suspending functions
*/

//fun main() = runBlocking {
//    println("runBlocking Created Coroutine!")
//    launch {
//        doWorld()
//    }
//    println("Hello!")
//}
//
//suspend fun doWorld() {
//    println("launch Created Coroutine!")
//    delay(1000L)
//    println("World!")
//}

//-------------------------------------------------------------------------
//-------------------------------------------------------------------------

/*
// SCOPE BUILDER

In addition to the coroutine scope provided by different builders,
it is possible to declare your own scope using the [coroutineScope]
builder.

It creates a coroutine scope and does not complete until
all launched children complete.

[runBlocking] and coroutineScope builders may look similar
because they both wait for their body and all its children to complete.

The main difference is that the [runBlocking] method _blocks_ the
current thread for waiting, while [coroutineScope][_coroutineScope]
just suspends, releasing the underlying thread for other usages.

Because of that difference, [runBlocking] is a regular function and
[coroutineScope][_coroutineScope] is a suspending function.

You can use `coroutineScope` from any suspending function.
*/

//fun main() = runBlocking {
//    doWorld()
//}
//
//suspend fun doWorld() = coroutineScope {
//    launch {
//        delay(1000L )
//        println( "World!")
//    }
//    println("Hello")
//}


//-------------------------------------------------------------------------
//-------------------------------------------------------------------------

/*
A [coroutineScope] builder can be used inside any
suspending function to perform multiple concurrent operations.
*/
//
//fun main() = runBlocking {
//    doWorld()
//    println("Done...")
//}
//
//suspend fun doWorld() = coroutineScope {
//    launch {
//        delay( 2000L )
//        println( "World 2...")
//    }
//    launch {
//        delay( 3000L )
//        println( "World 1...")
//    }
//    println("World")
//}

/*
A coroutineScope in doWorld completes only after both coroutines completes
and so doWorld() returns.
*/

//-------------------------------------------------------------------------
//-------------------------------------------------------------------------

// Job Using Coroutine
/*
A [launch] coroutine builder returns a [Job] object
that is a handle to the launched coroutine and can be
used to explicitly wait for its completion.
*/

//fun main() = runBlocking {
//    val job = launch {
//        delay( 1000L )
//        println("World!")
//    }
//
//    println("Hello")
//    job.join() // Wait Until Child Coroutine Completes
//    println("Done")
//}

//fun main() {
//    val job = GlobalScope.launch {
//        delay( 1000L )
//        println("World!")
//    }
//
//    println("Hello")
////    job.join() // Wait Until Child Coroutine Completes
//    println("Done")
////    sleep( 2000L )
//}

//-------------------------------------------------------------------------
//-------------------------------------------------------------------------

//Coroutines are less resource-intensive than JVM threads. Code that exhausts the
//JVM's available memory when using threads can be expressed using coroutines
//without hitting resource limits

// Coroutines Are Cheap!
//fun main() = runBlocking {
//    repeat(1000_000 ) {
//        launch {
////            delay(1000L)
//            print(".")
//        }
//    }
//    println("Done With One Million Coroutines...")
//}

//fun main() = runBlocking {
//    repeat(1000_000 ) {
//        doSomething()
//    }
//    println("Done With One Million Coroutines...")
//}
//
//fun doSomething() {
////   delay(1000L)
//    val thread = Thread {
//        println("${Thread.currentThread()} has run.")
//        print(".")
//    }
//    thread.start()
//}

//-------------------------------------------------------------------------
//-------------------------------------------------------------------------

/*
// CANCELLING COROUTINES EXECUTION

In a long-running application you might need fine-grained control
on your background coroutines.
*/

//fun main() = runBlocking {
//    val job = launch {
//        repeat( 1000 ) { i ->
//            delay( 500L )
//            println("Job : Going To Sleep $i...")
//        }
//    }
//    delay( 1300L )
//    println("Main Coroutine Tired Of Waiting...")
//    job.cancel()
//    println("Main Waiting Coroutine To Join...")
//    job.join()
//    println("Main Coroutine Completing...")
//}

//-------------------------------------------------------------------------
//-------------------------------------------------------------------------

/*
## Cancellation is cooperative

Coroutine cancellation is _cooperative_.
A coroutine code has to cooperate to be cancellable.
All the suspending functions in `kotlinx.coroutines` are _cancellable_.

They check for cancellation of  coroutine and throw [CancellationException]
when cancelled. However, if a coroutine is working in
a computation and does not check for cancellation, then it cannot be cancelled
*/

//fun main() = runBlocking {
//    val startTime = System.currentTimeMillis()
//
//    val job = launch( Dispatchers.Default ) {
//        var nextPrintTime = startTime
//        var i = 0
//        while ( i < 5 ) {
//            if ( System.currentTimeMillis() >= nextPrintTime ) {
//                println("Job: Going For Sleep ${i++} ...")
//                nextPrintTime += 500L
//            }
//        }
//    }
//    println("Main: Tired Of Waiting...")
//    job.cancelAndJoin()
//    println("Main Coroutine Completing...")
//    delay( 500L )
//}


//-------------------------------------------------------------------------
//-------------------------------------------------------------------------

// isActive Is An Extension Property Of coroutineScope

fun main() = runBlocking {
    val startTime = System.currentTimeMillis()

    val job = launch( Dispatchers.Default ) {
        var nextPrintTime = startTime
        var i = 0
//        while ( i < 5 ) {
        while( isActive ) {
            if ( System.currentTimeMillis() >= nextPrintTime ) {
                println("Job: Going For Sleep ${i++} ...")
                nextPrintTime += 500L
            }
        }
    }
    println("Main: Tired Of Waiting...")
    job.cancelAndJoin()
    println("Main Coroutine Completing...")
    delay( 500L )
}

//-------------------------------------------------------------------------
//-------------------------------------------------------------------------


//-------------------------------------------------------------------------
//-------------------------------------------------------------------------


//-------------------------------------------------------------------------
//-------------------------------------------------------------------------


//-------------------------------------------------------------------------
//-------------------------------------------------------------------------


//-------------------------------------------------------------------------
//-------------------------------------------------------------------------


//-------------------------------------------------------------------------
//-------------------------------------------------------------------------


//-------------------------------------------------------------------------
//-------------------------------------------------------------------------


//-------------------------------------------------------------------------
//-------------------------------------------------------------------------


//-------------------------------------------------------------------------
//-------------------------------------------------------------------------


//-------------------------------------------------------------------------
//-------------------------------------------------------------------------


//-------------------------------------------------------------------------
//-------------------------------------------------------------------------


//-------------------------------------------------------------------------
//-------------------------------------------------------------------------


//-------------------------------------------------------------------------
//-------------------------------------------------------------------------

