
/*
javac HelloWorld.java -d ClassFiles
java -cp ClassFiles/ learnJava.HelloWorld
*/

package learnJava;

public class HelloWorld {
	public static void main(String[] args ) {
		System.out.print("Hello World!\n");	
	}
}
