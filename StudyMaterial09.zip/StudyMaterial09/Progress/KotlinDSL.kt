
package learnKotlin

//_______________________________________________________________
// Experiment Following Code, MOMENT DONE >>> RAISE YOUR HANDS!!!


fun buildString( builderAction: (StringBuilder) -> Unit ) : String {
	val stringBuild = StringBuilder()
	builderAction( stringBuild )

	return stringBuild.toString()
}

fun playWithBuildString() {
	val string = buildString {
		it.append("Hello")
		it.append(", ")
		it.append("World!")
	}

	println( string )
}

//_______________________________________________________________
// Experiment Following Code, MOMENT DONE >>> RAISE YOUR HANDS!!!

fun createString( builderAction: StringBuilder.() -> Unit ) : String {
	val stringBuild = StringBuilder()
	stringBuild.builderAction()

	return stringBuild.toString()
}

fun playWithCreateString() {	
	val string = createString {
		append("Hello")
		append(", ")
		append("World!")
	}

	println( string )
}

//_______________________________________________________________
// Experiment Following Code, MOMENT DONE >>> RAISE YOUR HANDS!!!

// Domain Specific Langauge

// table {
// 		tr {
// 			td {

// 			}
// 		}
// }

open class Tag( val name : String ) {
	private val children = mutableListOf<Tag>() 

	protected fun < T : Tag  > doInit( child : T, init :  T.() -> Unit ) {
		child.init()
		children.add( child )
	} 

	override fun toString() = "<$name>${children.joinToString("")}</$name>}"
}

fun table( init : TABLE.() -> Unit ) = TABLE().apply( init )

class TABLE : Tag("table") {
	fun tr( init : TR.() -> Unit )  = doInit( TR(), init )
}

class TR : Tag("tr") {
	fun td( init : TD.() -> Unit ) = doInit( TD(), init )
}

class TD : Tag("td")


fun createTable() = 
	table {
		tr {
			td {

			}
		}
	}
	
fun playWithHtmlDSL() {
	val generatedHtml = createTable() 

	println( generatedHtml )
}	

// Function : playWithHtmlDSL
// <table><tr><td></td>}</tr>}</table>}

//_______________________________________________________________
//_______________________________________________________________
//_______________________________________________________________
// Experiment Following Code, MOMENT DONE >>> RAISE YOUR HANDS!!!

fun main() {
	println("\nFunction : playWithBuildString")
	playWithBuildString()

	println("\nFunction : playWithCreateString")
	playWithCreateString()

	println("\nFunction : playWithHtmlDSL")
	playWithHtmlDSL()

	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
}

/*
kotlinc KotlinDSL.kt -include-runtime -d dsl.jar
java -jar dsl.jar 
*/

