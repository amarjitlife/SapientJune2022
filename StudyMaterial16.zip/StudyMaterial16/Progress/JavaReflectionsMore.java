
package learnJava;

import java.lang.reflect.Method;
import java.lang.reflect.ParameterizedType;
import java.lang.reflect.Type;
import java.lang.reflect.TypeVariable;
import java.lang.reflect.WildcardType;
import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Arrays;

// import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
// import java.util.Arrays;
import java.util.Scanner;



// Types In Java Have A Type
//      i.e. All Types In Java Are of Class Type

// class A {

// }

// class ClassA {
//   public static void playWithClassA() {
//      try {
       
//         Class cls = Class.forName("A");
       
//         boolean b1 = cls.isInstance( new Integer(37) );
//         System.out.println(b1);
        
//         boolean b2 = cls.isInstance(new A());
//         System.out.println(b2);

//      } catch (Throwable e) {
//         System.err.println(e);
//      }
//   }
// }

class Person {
    private String name;
    private int age;
}

class PersonDemo {

    public static void playWithFieldNamesAtRuntime() {
        Object person = new Person();

        Class cls = person.getClass();

        Field[] fields = cls.getDeclaredFields();

        // Field[] fields = person.getClass().getDeclaredFields();

        List<String> actualFieldNames = getFieldNames(fields);

        System.out.println( actualFieldNames );

        // assertTrue( Arrays.asList("name", "age").containsAll(actualFieldNames));
    }

// private java.lang.String learnJava.Person.name
// private int learnJava.Person.age

// [name, age]

    private static List<String> getFieldNames(Field[] fields) {

        List<String> fieldNames = new ArrayList<>();
        
        for (Field field : fields) {
            fieldNames.add(field.getName());
            System.out.println( field );        
        }
    
        return fieldNames;
    }
}


class MethodPrinter {

    public static void playWithClassMethods() throws ReflectiveOperationException {
        System.out.print("Class Name: ");
        Scanner in = new Scanner(System.in);
        String className = in.nextLine();
        Class<?> cl = Class.forName(className);

        while (cl != null) {
            for (Method m : cl.getDeclaredMethods()) { 
                System.out.println(
                    Modifier.toString(m.getModifiers()) + " " +
                    m.getReturnType().getCanonicalName() + " " +
                    m.getName() +
                    Arrays.toString(m.getParameters()));                    
            }
            cl = cl.getSuperclass();
        }
    }
}


class JavaReflectionsAPIs {

    public static void playWithJavaRefelectionsAPIs() throws ReflectiveOperationException {
    
        TypeVariable<Class<ArrayList>>[] vars = ArrayList.class.getTypeParameters();
        String name = vars[0].getName(); // "E"
        System.out.println(name);
        
        Method m = Collections.class.getMethod("sort", List.class);

        TypeVariable<Method>[] vars2 = m.getTypeParameters();
        name = vars2[0].getName(); // "T"
        System.out.println(name);

        Type[] bounds = vars2[0].getBounds();
        
        if (bounds[0] instanceof ParameterizedType) { // Comparable<? super T>
            ParameterizedType p = (ParameterizedType) bounds[0];
            Type[] typeArguments = p.getActualTypeArguments();
            if (typeArguments[0] instanceof WildcardType) { // ? super T
                WildcardType t = (WildcardType) typeArguments[0];
                Type[] upper = t.getUpperBounds(); // ? extends ... & ...
                Type[] lower = t.getLowerBounds(); // ? super ... & ...
                if (lower.length > 0) {        
                    String description = lower[0].getTypeName(); // "T"
                    System.out.println(description);
                }
            }
        }
    }
}


class JavaReflections {
    public static void main( String[] args ) {
        // ClassA.playWithClassA();

        PersonDemo.playWithFieldNamesAtRuntime();
        try {  MethodPrinter.playWithClassMethods(); } catch( Exception e) { }
        // 
        // try {
        //     JavaReflectionsAPIs.playWithJavaRefelectionsAPIs(); 
        // } catch( Exception e) {

        // }
    }
}


/*
javac JavaReflections.java -d ClassFiles/
java -cp ClassFiles/ learnJava.JavaReflections
*/
