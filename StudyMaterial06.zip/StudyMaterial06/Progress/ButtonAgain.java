

import java.io.*;

interface View {
    public State getCurrentState();

    public void restoreState(State state) throws IOException, ClassNotFoundException;

    public void saveState(State state) throws IOException;
}

interface State {

}

class ButtonAgain implements View {

    String filePath = "src/button.txt";
    ButtonState buttonState;

    @Override
    public State getCurrentState() {
        return buttonState;
    }

    @Override
    public void saveState(State state) throws IOException {
        FileOutputStream fileOutputStream = new FileOutputStream(filePath);
        ObjectOutputStream objectOutputStream = new ObjectOutputStream(fileOutputStream);
        objectOutputStream.writeObject(state);
    }

    @Override
    public void restoreState(State state) throws IOException, ClassNotFoundException {
        FileInputStream fileInputStream = new FileInputStream(filePath);
        ObjectInputStream objectInputStream = new ObjectInputStream(fileInputStream);
        buttonState = (ButtonState) objectInputStream.readObject();
    }

    public static class ButtonState implements State, Serializable {
        String value;

        public ButtonState(String value) {
            this.value = value;
        }

        @Override
        public String toString() {
            return "ButtonState{" +
                    "value='" + value + '\'' +
                    '}';
        }
    }
}

class Main {
    public static void main(String[] args) throws IOException {

        ButtonAgain button = new ButtonAgain();
        ButtonAgain.ButtonState minimumState = new ButtonAgain.ButtonState("Hello");

        button.saveState(minimumState);

        try {
            button.restoreState(minimumState);
            System.out.println((button.getCurrentState()));

        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }

    }
}



