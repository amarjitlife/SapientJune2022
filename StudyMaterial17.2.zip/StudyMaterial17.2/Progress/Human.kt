
package learnKotlin

// Design Principle
//		Design Towards Abstract Type Rather Than Types

//	Corollary
//		Design Towards Interfaces Rather Than Concrete Classes

// Abstract Type
//		Operation = { fly(), saveWorld() }
interface Superpower {
	fun fly()
	fun saveWorld()
}

// Define Zero Of Type
// 		Null Object Design Pattern
class SuperpowerZero : Superpower { // Defininng Nothingness Or Zero Of Type
	override fun fly() 		 		{ /* Define Nothingness */ }
	override fun saveWorld() 		{ /* Define Nothingness */ }	
}

// Creating Set Of Types

// Classes Which Are Not Meant To Be Inherited Must Be Final
// Type Of Type Relationship
class Spiderman : Superpower {
	override fun fly() 		 	{ println("Fly Like Spiderman!") 		}
	override fun saveWorld() 	{ println("SaveWorld Like Spiderman!") }	
}

class BadSuperman : Superpower {
	override fun fly() 		 { println("Fly Like Superman!") 		}
	override fun saveWorld() { println("SaveWorld Like Superman!") 	}	
}

class Superman : Superpower {
	override fun fly() 		 { println("Fly Like Superman!") 		}
	override fun saveWorld() { println("SaveWorld Like Superman!") 	}	
}

class HanumanJi : Superpower {
	override fun fly() 		 { println("Fly Like HanumanJi!") 		}
	override fun saveWorld() { println("SaveWorld Like HanumanJi!") 	}	
}

open class Heman {
	open fun fly() 		 { println("Fly Like Heman!") 			}
	open fun saveWorld() { println("SaveWorld Like Heman!") 	}	
}


// Writing Code For Change
// Design Choice 1: Using Inheritance
// SOLID 
// S : Single Responisbility Design
// O : Open-Close Design Violated

class Human : Heman() {
	override fun fly() 		 { super.fly() 			}
	override fun saveWorld() { super.saveWorld() 	}
}

// Design Choice 2 : Composition
//		HumanAgain Is Composed Of Spiderman

// Design Principle
//		Design Towards Abstract Type Rather Than Types

// Corollary : Deducing Best Practices From Fundamental Principle
	// SOLID 
	// S : Single Responisbility Design
	// O : Open-Close Design

// HumanAgain Polymorphic
class HumanAgain {
	// HumanAgain Delegating fly And saveWorld To Delegate
	// power Is Delegate
	var power : Superpower? = null  			// Zero Of HumanAgain
	fun fly() 		 { power?.fly() 		}
	fun saveWorld()  { power?.saveWorld() 	}
}

class HumanMore(power: Superpower) : Superpower by power 
// {
// 	// HumanAgain Delegating fly And saveWorld To Delegate
// 	// power Is Delegate
// 	// var power : Superpower? = null  			// Zero Of HumanAgain
// 	// fun fly() 		 { power?.fly() 		}
// 	// fun saveWorld()  { power?.saveWorld() 	}
// }

// class HumanMore(val _power) {
// 	val power = _power
// 	fun fly() 		 { power.fly() 		}
// 	fun saveWorld()  { power.saveWorld() 	}	
// } 

fun main() {
	val human = Human()
	human.fly()
	human.saveWorld()

	val humanAgain 	= HumanAgain()	
	humanAgain.fly()
	humanAgain.saveWorld()

	// error: type mismatch: inferred type is Spiderman but Superpower? was expected
	humanAgain.power = Spiderman() // Configuring Human
	humanAgain.fly()
	humanAgain.saveWorld()

	// error: type mismatch: inferred type is Superman but Superpower? was expected
	// humanAgain.power = BadSuperman()  // Configuring Human
	humanAgain.power = null 			 // Configuring Human - Applying Inverse
	humanAgain.power = Superman()  // Configuring Human
	humanAgain.fly()
	humanAgain.saveWorld()

	humanAgain.power = HanumanJi() // Configuring Human
	humanAgain.fly()
	humanAgain.saveWorld()

	val humanMore = HumanMore( Spiderman() )
	humanMore.fly()
	humanMore.saveWorld()

	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
}

/*
kotlinc Human.kt -include-runtime -d human.jar
java -jar human.jar 
*/

